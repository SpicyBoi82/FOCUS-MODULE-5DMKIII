#!/usr/bin/env bash
# =====================================================================================================
# test.sh - runs the host simulators of all three modules and compares with the golden results.
#
#   ./test.sh            simulate the 5D3 build (default)
#   ./test.sh 70D        simulate the 70D build (results are identical: only texts differ)
#
# Needs only gcc (no camera, no ARM compiler). Takes about 4 minutes.
# REPLAY metrics use REAL sharpness curves from the user's camera logs (tests/curves) - trust those most.
# Output: tests/out/*.txt (full results) and a table  metric | golden | now | verdict.
# Exit code 1 if any metric got WORSE than golden. "better" or "same" = fine.
#
# IMPORTANT: the simulators model a lens (blur curve, backlash, lag, motor timing). They prove the CONTROL
# LOGIC, not that it works on a real camera. Real camera logs (CSV files) always win over the simulator.
# After a deliberate improvement, refresh the golden files with:  ./test.sh --update-golden
# =====================================================================================================
set -uo pipefail
cd "$(dirname "$0")"
CAM=5D3; UPDATE=0
for a in "$@"; do case "$a" in 70D) CAM=70D;; 5D3) CAM=5D3;; --update-golden) UPDATE=1;; *) echo "usage: ./test.sh [5D3|70D] [--update-golden]"; exit 2;; esac; done
DEF=""; [ "$CAM" = 5D3 ] && DEF="-DCAM_5D3"
command -v gcc >/dev/null || { echo "ERROR: gcc not found"; exit 1; }
OUT=tests/out; GOLD=tests/golden; BIN=tests/bin; mkdir -p "$OUT" "$GOLD" "$BIN"

echo "== building simulators ($CAM) =="
( cd src/CAMCAL && gcc -O2 -w $DEF -I SDK_COMPAT SIM_CAMCAL.c -o ../../$BIN/sim_camcal ) || exit 1
( cd src/FZ17C  && gcc -O2 -w $DEF -I SDK_COMPAT -DSRC='"FZ17C.c"' -DRUN=search_v17c SIM_AF.c -o ../../$BIN/sim_v17c ) || exit 1
( cd src/CAMF   && gcc -O2 -w $DEF -I SDK_COMPAT SIM_CAMF.c -o ../../$BIN/sim_camf ) || exit 1

echo "== running (about 3 minutes) =="
for s in grid lens asym edge retry frozen gate c912; do
  if [ $s = grid ]; then $BIN/sim_camcal > $OUT/camcal_$s.txt; else $BIN/sim_camcal $s > $OUT/camcal_$s.txt; fi
  echo "  CAMCAL $s done"
done
$BIN/sim_v17c > $OUT/v17c.txt; echo "  V17C done"
for s in main stable shift pan comp limit fps halfpress; do
  if [ $s = main ]; then $BIN/sim_camf > $OUT/camf_$s.txt; else $BIN/sim_camf $s > $OUT/camf_$s.txt; fi
  echo "  CAMF $s done"
done

# ---- REPLAY: real sharpness curves from camera logs (tests/curves/*.txt, made with tests/make_curve.py) ----
# Pipeline per curve, like on the camera: CAMCAL calibrates and writes the lens profile to a simulated card,
# then V17C (Backlash Comp AUTO) and CAMF (AUTO) run with that profile. V17C also runs WITHOUT a profile
# (fixed comp 3 = the r3 behaviour) for comparison. Variants: the same curves with 0 and 4 units of backlash.
CARD=tests/card; rm -rf $CARD; mkdir -p $CARD
: > $OUT/replay_camcal.txt; : > $OUT/replay_v17c_profile.txt; : > $OUT/replay_v17c_noprofile.txt; : > $OUT/replay_camf.txt
: > $OUT/replay_variants.txt
for c in tests/curves/*.txt; do [ "$(basename $c)" = README.txt ] && continue
  n=$(basename $c .txt); mkdir -p $CARD/$n
  SIMCARD=$CARD/$n $BIN/sim_camcal replay $c >> $OUT/replay_camcal.txt
  SIMCARD=$CARD/$n COMP=6 $BIN/sim_v17c replay $c >> $OUT/replay_v17c_profile.txt
  COMP=3 $BIN/sim_v17c replay $c >> $OUT/replay_v17c_noprofile.txt
  SIMCARD=$CARD/$n COMPSET=3 $BIN/sim_camf replay $c >> $OUT/replay_camf.txt
  echo "  replay $n done"
done
for bl in 0 4; do for c in tests/curves/70D_18-135_50mm.txt tests/curves/70D_18-135_19mm.txt; do
  n=B${bl}_$(basename $c .txt); mkdir -p $CARD/$n
  RP_BACKLASH=$bl SIMCARD=$CARD/$n $BIN/sim_camcal replay $c > /dev/null
  echo "AUTO  $n $(RP_BACKLASH=$bl SIMCARD=$CARD/$n COMP=6 $BIN/sim_v17c replay $c | cut -d'|' -f2-)" >> $OUT/replay_variants.txt
  echo "FIXED $n $(RP_BACKLASH=$bl COMP=3 $BIN/sim_v17c replay $c | cut -d'|' -f2-)" >> $OUT/replay_variants.txt
done; done
echo "  replay variants done"

# ---- metrics: name|direction(+ = higher is better, - = lower is better)|value
metrics() {
  local d=$1
  c() { grep -c -- "$1" "$2" 2>/dev/null || true; }
  echo "camcal_grid_ok (294 runs, err=0)|+|$(c 'err=0 ' $d/camcal_grid.txt)"
  echo "camcal_grid_exact_landing|+|$(c 'final err 0$' $d/camcal_grid.txt)"
  echo "camcal_lens_ok (117 runs)|+|$(c 'err=0 ' $d/camcal_lens.txt)"
  echo "camcal_lens_exact_landing|+|$(c 'final err 0$' $d/camcal_lens.txt)"
  echo "camcal_asym_ok (10 runs)|+|$(c 'err=0 ' $d/camcal_asym.txt)"
  echo "camcal_edge_ok (6 runs, 1 flat target must fail)|+|$(c 'err=0 ' $d/camcal_edge.txt)"
  echo "camcal_retry_ok (6 runs)|+|$(c 'err=0 ' $d/camcal_retry.txt)"
  echo "camcal_frozen_detected (err=8)|+|$(c 'err=8 ' $d/camcal_frozen.txt)"
  echo "camcal_gate_blip_survived|+|$(c 'gate_blips=1' $d/camcal_gate.txt)"
  echo "camcal_gate_stop_reported (gate_bits=8)|+|$(c 'gate_bits=8' $d/camcal_gate.txt)"
  echo "camcal_broad_hill_ok (14 runs, 2 too wide)|+|$(c 'err=0 ' $d/camcal_c912.txt)"
  echo "v17c_failed_runs (all profiles)|-|$(awk -F'fail' '/\| runs/{split($2,a," ");s+=a[1]}END{print s+0}' $d/v17c.txt)"
  echo "v17c_runs_below_95pct_sharp|-|$(awk '/\| runs/{for(i=1;i<=NF;i++){if($i=="runs")n=$(i+1);if($i=="sharp>=95%:"){p=$(i+1);sub("%","",p)}};s+=n*(100-p)/100}END{printf "%d",s+0.5}' $d/v17c.txt)"
  echo "v17c_mean_ms (avg over profiles)|-|$(awk '/\| runs/{for(i=1;i<=NF;i++)if($i=="mean"&&$(i+2)=="ms"){s+=$(i+1);n++}}END{printf "%d",s/n}' $d/v17c.txt)"
  echo "camf_main_err_gt2 (297 runs)|-|$(sh src/CAMF/summarize.sh $d/camf_main.txt | head -1 | awk '{print $4}')"
  echo "camf_stable_single_search (12 runs)|+|$(c 'searches 1$' $d/camf_stable.txt)"
  echo "camf_shift_refocused_err0 (24 runs)|+|$(grep -c 'err   0 .*searches 2' $d/camf_shift.txt || true)"
  echo "camf_halfpress_no_cmds_while_held (4 runs)|+|$(c 'commands_while_held 0$' $d/camf_halfpress.txt)"
  echo "camf_halfpress_in_focus_after (4 runs)|+|$(c 'err   0 ' $d/camf_halfpress.txt)"
  sharp95() { awk '/runs/{for(i=1;i<=NF;i++){if($i=="runs")n=$(i+1);if($i=="sharp>=95%:"){p=$(i+1);sub("%","",p)}};s+=n*p/100}END{printf "%d",s+0.5}' "$@"; }
  echo "REPLAY camcal_ok (5 starts per real curve)|+|$(c 'err=0 ' $d/replay_camcal.txt)"
  echo "REPLAY camcal_backlash_right (true 2, +/-0.5)|+|$(grep -cE 'err=0 settle=[0-9]+ \| B= (1\.[5-9]|2\.[0-5]) ' $d/replay_camcal.txt || true)"
  echo "REPLAY v17c_sharp95_with_profile (72 per curve)|+|$(sharp95 $d/replay_v17c_profile.txt)"
  echo "REPLAY v17c_sharp95_without_profile|+|$(sharp95 $d/replay_v17c_noprofile.txt)"
  echo "REPLAY v17c_sharp95_AUTO_backlash_0_and_4|+|$(grep '^AUTO' $d/replay_variants.txt | sharp95)"
  echo "REPLAY v17c_sharp95_FIXED3_backlash_0_and_4|+|$(grep '^FIXED' $d/replay_variants.txt | sharp95)"
  echo "REPLAY camf_err_gt2 (9 starts per curve)|-|$(sh src/CAMF/summarize.sh $d/replay_camf.txt | head -1 | awk '{print $4+0}')"
}
if [ $UPDATE = 1 ]; then for f in $OUT/*.txt; do case $(basename $f) in table.txt|metrics.txt) ;; *) cp $f $GOLD/;; esac; done; metrics $GOLD > $GOLD/metrics.txt; echo "golden results updated"; exit 0; fi
[ -f $GOLD/metrics.txt ] || { echo "no golden metrics - run ./test.sh --update-golden once"; exit 1; }
metrics $OUT > $OUT/metrics.txt
echo; printf '%-50s %8s %8s  %s\n' "metric" "golden" "now" "verdict"
WORSE=0
awk -F'|' 'NR==FNR{g[$1]=$3;next}{n=$1;d=$2;v=$3;
  if(!(n in g)){verdict="NEW (no golden)";gv="-"}
  else{gv=g[n]; if(gv==v)verdict="same"; else if((d=="+"&&v+0>gv+0)||(d=="-"&&v+0<gv+0))verdict="better"; else verdict="WORSE"}
  printf "%-50s %8s %8s  %s\n",n,gv,v,verdict}' $GOLD/metrics.txt $OUT/metrics.txt | tee $OUT/table.txt
grep -q "WORSE" $OUT/table.txt && WORSE=1
echo
for f in $GOLD/*.txt; do b=$(basename $f); case $b in metrics.txt|table.txt) continue;; esac; cmp -s $f $OUT/$b || echo "changed vs golden: $b"; done
[ $WORSE = 0 ] && echo "TESTS OK (no metric worse than golden)" || { echo "TESTS: SOME METRICS WORSE - look at tests/out/ before shipping"; exit 1; }
