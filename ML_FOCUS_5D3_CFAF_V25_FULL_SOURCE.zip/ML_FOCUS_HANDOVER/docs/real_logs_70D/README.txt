Real logs from the user's Canon 70D (fw 1.1.2) with the EF-S 18-135 IS USM (lens id 36912).
All written by the modules in this package (older versions). Read the # header lines of each file.

FZ7C2B59 .. FZ7C2B5E   V17C r1 - 6 runs at 18-19, 50 and 135 mm, all accepted (user: "impressive result")
FZ7C34FD               V17C r2 - 18 mm, start at the close-focus stop (ghost-accepted +3, 37-unit crawl back)
FZ7C34FE, FZ7C34FF     V17C r2 - 85 mm; 34FF is a dark scene (luma 16, ~55% near-black) that focused fine
FZ7C3500               V17C r2 - 85 mm, slow 9.4 s run (noise dip on flat blur taken as "peak passed")
CAMCAL912F             CAMCAL v2 - 64 mm f/4.9 on a monitor target. FAILED with real error 4 (peak not crossed);
                       the file says "err 0" because of a bug fixed in C2. Sweep columns are pos,up1,down,up2
                       (old names; "up1" actually travelled DOWN in this run).
CAMCAL73E6             CAMCAL C2 - err 1 (a gate check failed before measuring; bit not logged in C2).
