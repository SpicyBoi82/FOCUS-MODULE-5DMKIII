Real logs from the user's 5D Mark III (fw 1.1.3). Lens reports lens_id 36912 at 24-29 mm.
CAUTION: in BOTH sessions CAMF was ON while V17C ran from the menu, so the two modules drove the lens at the same
time. Do not judge V17C accuracy from these (several "accepted" runs end less sharp than they started).
Session 1 (16 Oct 02:20-02:23, first 5D3 build = CAMF C1, V17C r3): CAMF6C9E-6CAC (15 searches, 3 image
  failures from the old >50% dark-frame rule, fixed in C2), FZ7C71B3-71BC (10 runs at 29 mm).
Session 2 (16 Oct 02:40-02:43, CAMF C2, V17C r4; no lens profile yet): CAMF232B-233A (16 searches),
  FZ7C2549-2551 (9 runs at 24 mm). Proves the r4/C2 builds (with FIO_OpenFile/FIO_ReadFile) load on the 5D3.
V17C r5 + CAMF C3 (half-shutter trigger, CAMF pauses while held) were made after these sessions.
