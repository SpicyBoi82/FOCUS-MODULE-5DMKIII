Real sharpness curves for the simulators' replay mode (made with ../make_curve.py from ../../docs/real_logs_70D).
Each file says in its # lines where it came from and which numbers are ASSUMPTIONS (given by hand, mirrored).
70D_18-135_64mm_monitor  CAMCAL912F up-sweep (monitor target, very broad hill); right half mirrored
70D_18-135_50mm          FZ7C2B5B exact phase (V17C r1); right tail mirrored
70D_18-135_85mm          FZ7C3500 exact phase (V17C r2), narrow peak ~2-3 units; left tail mirrored
70D_18-135_19mm          FZ7C2B5A exact phase (V17C r1); left side mirrored
70D_18-135_18mm          FZ7C2B5E exact phase (V17C r1); left side mirrored
Add 5D3 curves (e.g. 5D3_50STM_50mm.txt) from the first 5D3 CAMCAL logs, then ./test.sh --update-golden.
