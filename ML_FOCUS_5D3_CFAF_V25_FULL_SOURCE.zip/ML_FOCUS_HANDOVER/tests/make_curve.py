#!/usr/bin/env python3
"""make_curve.py - turn a REAL camera log into a replay curve for the simulators (tests/curves/*.txt).

  python3 tests/make_curve.py camcal ML_CAMCALxxxx.CSV tests/curves/NAME.txt [--up COLUMN] [--k3 N] [--mirror]
  python3 tests/make_curve.py v17c   ML_FZ7Cxxxx.CSV   tests/curves/NAME.txt [--backlash N] [--k3 N] [--mirror]

camcal: uses the sweeps that travelled UP (+) - the direction the modules' positions are defined in.
        CAMCAL C2 and later write which way sweep1 went; for an older file give the column with --up.
        Backlash, +/-3 size and noise are taken from its RESULT line when it measured them.
v17c:   uses the samples of the exact +/-1 phase (after the last +/-3 jump); positions there are exact.
--lo/--hi: end stops relative to the peak for the simulator (default +/-150 when not given).
--mirror: where one side of the peak was not measured, copy the other side (an ASSUMPTION, written into the
          file). Without it the curve stays flat beyond the last sample.
The output always has the peak at position 0. Never edit the numbers by hand: regenerate from the log.
"""
import csv, sys, argparse, collections

def read_rows(path):
    with open(path, newline='') as f:
        lines = f.readlines()
    head = [l for l in lines if l.startswith('#')]
    body = [l for l in lines if not l.startswith('#') and l.strip()]
    return head, list(csv.DictReader(body))

def field(head, key, name):
    for l in head:
        if l.startswith('# ' + key):
            parts = l.strip().split(',')
            for i, p in enumerate(parts[:-1]):
                if p == name:
                    try: return int(parts[i + 1])
                    except ValueError: return None
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('kind', choices=['camcal', 'v17c'])
    ap.add_argument('log'); ap.add_argument('out')
    ap.add_argument('--up'); ap.add_argument('--k3', type=int); ap.add_argument('--backlash', type=int)
    ap.add_argument('--noise', type=int); ap.add_argument('--mirror', action='store_true')
    ap.add_argument('--lo', type=int); ap.add_argument('--hi', type=int)   # end stops relative to the peak (simulator)
    a = ap.parse_args()
    head, rows = read_rows(a.log)
    pts = collections.defaultdict(list)
    params = {}
    notes = []
    if a.kind == 'camcal':
        if a.up: cols = [a.up]
        else:
            d = [l for l in head if l.startswith('# sweep1 = first sweep')]
            if not d: sys.exit('old CAMCAL file: say which column travelled up with --up')
            cols = ['sweep1', 'sweep3'] if 'UP' in d[0] else ['sweep2']
        for r in rows:
            for c in cols:
                v = r.get(c, '')
                if v: pts[int(r['pos'])].append(int(v))
        params['focal'] = field(head, 'lens', 'focal_mm')
        params['lens_id'] = field(head, 'lens', 'id')
        b = field(head, 'RESULT', 'backlash_x10'); s3 = field(head, 'RESULT', 'step3_units_x10')
        nz = field(head, 'RESULT', 'noise_bp'); err = field(head, 'RESULT', 'err')
        if err: notes.append('CAMCAL err %d in this log: only the sweep table is used' % err)
        if b and not err: params['backlash'] = (b + 5) // 10
        if s3 and not err: params['k3'] = (s3 + 5) // 10
        if nz and not err: params['noise'] = max(1, (nz + 50) // 100)
        notes.append('source: %s, columns %s (travelling up)' % (a.log.split('/')[-1], '+'.join(cols)))
    else:
        last = -1
        for i, r in enumerate(rows):
            if r['event'] in ('4', '34'): last = i
        for r in rows[last + 1:]:
            if r['event'] == '2': pts[int(r['off'])].append(int(r['fv']))
        for l in head:
            if 'focal_mm,' in l:
                params['focal'] = int(l.split('focal_mm,')[1].split(',')[0])
            if l.startswith('# lens_id,'):
                params['lens_id'] = int(l.split('lens_id,')[1].split(',')[0])
        notes.append('source: %s, exact +/-1 phase samples (mixed travel directions: backlash blurs ~1-2 units)'
                     % a.log.split('/')[-1])
    for k in ('k3', 'backlash', 'noise', 'lo', 'hi'):
        if getattr(a, k) is not None: params[k] = getattr(a, k); notes.append('%s=%d given by hand' % (k, getattr(a, k)))
    if len(pts) < 3: sys.exit('fewer than 3 positions in this log')
    pos = sorted(pts); val = {p: sum(pts[p]) // len(pts[p]) for p in pos}
    # peak = best 3-point mean (robust to one noisy sample)
    def sm(p):
        n = [val[q] for q in (p - 1, p, p + 1) if q in val]
        return sum(n) / len(n)
    pk = max(pos, key=sm) if a.kind == 'camcal' else max(pos, key=lambda p: val[p])   # sparse v17c samples: raw max
    curve = {p - pk: val[p] for p in pos}
    if a.mirror:
        lo, hi = min(curve), max(curve)
        added = 0
        for d in range(1, max(-lo, hi) + 1):
            if d not in curve and -d in curve and d > hi: curve[d] = curve[-d]; added += 1
            if -d not in curve and d in curve and -d < lo: curve[-d] = curve[d]; added += 1
        if added: notes.append('ASSUMPTION: %d points mirrored from the other side of the peak (not measured)' % added)
    with open(a.out, 'w') as f:
        for k, v in params.items():
            if v is not None: f.write('#! %s %d\n' % (k, v))
        for n in notes: f.write('# %s\n' % n)
        f.write('# peak of the log at position %d moved to 0\npos,fv\n' % pk)
        for p in sorted(curve): f.write('%d,%d\n' % (p, curve[p]))
    print('wrote %s: %d points, peak %d, params %s' % (a.out, len(curve), max(curve.values()), params))

main()
