# START HERE: Magic Lantern focus modules for the Canon 5D Mark III and 70D

This is a handover from a previous assistant. Read this file completely before changing anything.
Everything you need is in this folder. Nothing here needs internet access.

## 1. What is in here

There are three Magic Lantern (ML) modules. Each is a single C file that is built into a `.MO` file:

| Module | File | Version | What it does | Camera-tested? |
|---|---|---|---|---|
| **CAMCAL** | `src/CAMCAL/CAMCAL.c` | C5 | Calibration. Sweeps focus over a flat target (a monitor showing `CAMCAL_TARGET.png`). Measures backlash, peak width, noise, lag and the real size of a ±3. **Writes the lens profile** (section 2). C5: also logs Canon's own focus data (PROP_LV_FOCUS_DATA, 5D3 only) + a 20 s monitor (section 2c). | 70D: two runs, both failed early; both causes were fixed. 5D3: never run. |
| **V17C** | `src/FZ17C/FZ17C.c` (module name FZ17C) | r8 | One-shot fast contrast AF: ±3 approach, exact ±1 finish, verify. **Half-shutter trigger** (hold = focus, let go = stop). **Reads the lens profile.** | 70D: r1 6/6 and r2 4/4 accepted. 5D3: r3/r4 load and run (logs in docs/real_logs_5D3, but CAMF was fighting it). r5 untested. |
| **CAMF** | `src/CAMF/CAMF.c` | C3 | Continuous "camcorder style" AF that glides to the new peak. **Pauses while the half-shutter is held.** **Reads the lens profile.** | 5D3: C1/C2 ran (31 searches, docs/real_logs_5D3). C3 untested. |

**Cameras.** Default build = Canon **70D** fw 1.1.2. `-DCAM_5D3` = Canon **5D Mark III** fw 1.1.3 ("5D3.113").
Both are ML module API 8, DIGIC 5. The only camera-specific code is the `CAMERA PROFILE` block near the top
of each `.c` file: the `is_camera()` strings and a few on-screen words. The simulator results for the two
cameras are identical.

## 2. How the system tunes itself: lens profiles plus replay of real curves

**Lens profiles.** After every successful run, CAMCAL writes `ML/LPxxxx.TXT` on the card. `xxxx` is the
lens id in hex; the 18-135 IS USM is `LP9030.TXT`. The file has one line per focal length:
backlash, peak width, ±3 size, noise and lag. The format and the reader code are in
`src/common/LENS_PROFILE.h`, ONE file included by all three modules.

V17C and CAMF read the profile:
- **V17C Backlash Comp = AUTO** (the new default): measured backlash rounded up, +1 unit, minimum 2.
  Without a profile it uses 3, the old default.
- **V17C "narrow peak"** means stride cap 4 and a small ±4 first probe. With a profile within
  max(3 mm, focal/8) of the current focal length, it is decided by the measured FWHM ≤ 8 units. Without one,
  the old rule from the 70D and 18-135 applies (70 mm or longer).
- **CAMF Backlash Comp = AUTO** (default): CAMCAL's rule, B<1 → off, <3 → 2 units, else 4. Without a
  profile it uses 2.
- **No profile = exactly the old behaviour.** The tests prove this: all non-replay metrics are unchanged.

The user can open the profile in a text editor and delete a bad line. Lens id 0 (unknown lens) never gets
a profile.

**Replay curves.** `tests/curves/*.txt` are REAL sharpness-versus-position curves taken from the user's
camera logs with `tests/make_curve.py`. The simulators can use them instead of the invented lens model
(`replay` mode).

`test.sh` runs the camera pipeline on each curve: CAMCAL calibrates and writes a profile to a simulated
card (`tests/card/`), then V17C and CAMF run with it.

**What the replay tests already showed (simulated, from real 70D curves):**
- With a lens that has 4 units of backlash, the old fixed comp 3 gave 24-26% of runs at ≥95% peak
  sharpness. AUTO from the profile gave 92-100%.
- Exactly as much comp as backlash (2) landed one unit short more often. That is why AUTO adds 1.
- **V17C r4 on the real 85 mm curve reaches ≥95% sharpness in only 25% of runs**, with or without a
  profile. On the invented 85 mm lens model it was 100%. This is the most important open problem (task T2).

**Every new camera log with a sweep can become a curve:**
```
python3 tests/make_curve.py camcal ML_CAMCALxxxx.CSV tests/curves/5D3_50STM_50mm.txt --lo -80 --hi 80
python3 tests/make_curve.py v17c   ML_FZ7Cxxxx.CSV   tests/curves/5D3_xxx.txt --backlash 2 --k3 3 --mirror
./test.sh --update-golden    # once, after adding curves; say so in your reply
```
CAMCAL C2 and later logs say which sweep travelled up, and the RESULT line gives backlash, the ±3 size and
noise. Old V17C logs need `--backlash` and `--k3` by hand; these are assumptions, so say so.

## 2b. Half-shutter workflow (V17C r5 + CAMF C3) - what the user asked for
- **V17C Trigger = HALF-SHUTTER** (the default): press and hold the shutter half-way = one fast AF run; let go =
  V17C stops at once and leaves the lens where it is (the CSV header says `trigger,halfshutter`,
  `released_early,1`). One run per press. While this mode is on, V17C moves Canon's own AF to the * button
  (`assign_af_button_to_star_button()`, restored when the mode is switched off or the module unloads; ML also
  restores it at the next start-up). MENU ONLY = the old menu-triggered behaviour.
- **CAMF** pauses whenever the half-shutter is held: no lens commands at all (a search in progress is cut
  short and logged as result 7). 1.2 s after release it re-measures the scene WITHOUT searching (V17C just set
  focus) and goes back to watching. Simulator: `./sim_camf halfpress` (0 commands while held, in focus after).
- CAMF cannot see a MENU-triggered V17C run or CAMCAL: with those, CAMF must be switched OFF (rule 10).
- Modules cannot share variables; the half-shutter state (`get_halfshutter_pressed()`) is the shared signal.

## 2c. Canon focus data (CAMCAL C5, 18 Oct 2026) - the next big lever for task T2
- On the 5D3 Canon sends `PROP_LV_FOCUS_DATA` (0x80050026, 8 ints) in LiveView, also in MF. ML core sums
  buf[2]+buf[3] into Magic Zoom's focus value; the green border = current value near the recent maximum.
  The 70D never sends it (ML focus.c compiles that code out for the 70D; our 70D V28 probe saw 0 events).
- Canon computes it in hardware on the full sensor in the AF area; our metric uses the 720x480 preview.
  If its curve is narrower / less noisy, V17C and CAMF should use it as their sharpness source when events
  arrive, and keep the YUV metric as the fallback (70D: always the fallback).
- A module receives a property through a table `module_prophandler_t *__module_prophandlers_<modname>[]`
  (NULL-terminated; type in CAMCAL's SDK_COMPAT/module.h). The handler runs in PropMgrTask: copy, return.
- Open until real data: update rate (every frame?), lag vs the picture, behaviour while our module drives the
  lens, in movie mode / while recording, value range (CAMCAL scales by a per-run shift to stay 32-bit).
- **Result (CFD39301, 5D3, 74 mm, 18 Oct):** every frame; Canon's peak 4 frames (~170 ms) before the preview
  metric (cross-correlation 0.969 at lag 4); ~0.5x FWHM; 11-14x sharp/blur vs 5.5-7.5x; noise similar. Its scale
  jumps when Canon's own AF / exposure state changes (watch v1).
- **V17C r6 uses it** (menu "V17C Sharpness", default CANON AF DATA): see src/FZ17C/README_V17C.txt. YUV path
  unchanged (golden metrics identical). Simulator: CFD=1, CFDLAG, LAG, CFDJUMP, CFDSTOP env variables.
  Key sim result: YUV with the 5D3's ~170 ms preview lag (LAG=170) 46.7 pct >=95 pct sharp, 591 false accepts;
  Canon 98.0 pct, 8 false accepts (50 STM far starts). CAMF still YUV (next).

## 3. Folder map
```
START_HERE_CHATGPT.md   this file
5D3_QUICK_START.txt     the text to give the USER for the 5D3 tests
build.sh                builds bin/5D3/*.MO and bin/70D/*.MO (needs clang + llvm-objcopy) with safety checks
test.sh                 runs all host simulators + REAL-curve replays, compares with tests/golden (gcc only)
ALLOWED_IMPORTS.txt     the only ML functions/variables the modules may use (build checks it)
bin/5D3/  bin/70D/      ready-built modules + bin/SHA256SUMS.txt
src/<MODULE>/           <MODULE>.c (the module), SIM_*.c (host simulator), SDK_COMPAT/ (minimal ML headers),
                        README_* (user docs, 70D wording). CAMCAL also has CAMCAL_TARGET.png (the target).
src/common/             LENS_PROFILE.h (in the modules), SIM_CARD.h + REPLAY.h (simulators only)
tests/curves/           real sharpness curves (from docs/real_logs_70D)     tests/make_curve.py  log -> curve
tests/golden/           expected simulator output + metrics.txt
docs/FINDINGS.md        what real camera logs have proven (READ IT)
docs/real_logs_70D/     the user's real logs from these modules (+ index README)
docs/real_logs_5D3/     first 5D3 logs (CAMF ran together with menu-triggered V17C - see README there)
docs/sample_logs_SIMULATED/  one simulated CSV per module, to show the log formats (NOT camera data)
```

## 4. Build and test (do this before and after every change)
```
./build.sh          # or: CLANG=/path/clang OBJCOPY=/path/llvm-objcopy ./build.sh
./test.sh           # 5D3 simulation; ./test.sh 70D for the 70D build (identical results)
```

**What `build.sh` does:** it refuses to output a module if any of these is true:
1. It imports a symbol that is not in `ALLOWED_IMPORTS.txt`.
2. It has a relocation other than `R_ARM_ABS32`.
3. A format string contains `%%` or `%u`.
4. The is_camera strings are missing.

**Compilers:**
- The reference compiler is clang 17 from the user's `ML70D_Parfocal_V7_Complete_Dev_Environment/toolchain`.
- Any clang 14 or newer works (stock clang 18 was tested; it gives different bytes, equally valid).

**What `test.sh` does:** it prints `metric | golden | now | verdict`. **WORSE = you broke something.**
- The REPLAY rows come from real curves. Trust them more than the invented-lens rows.
- After a deliberate improvement, run `./test.sh --update-golden` and say what changed and why.
- If you cannot run clang: edit, run `./test.sh` (gcc only), and ask the user to run `./build.sh`.

## 5. HARD RULES: breaking these makes a module fail to load, or crash, on the camera
1. **No division or modulo by a variable.** Use `divu(a,b)` / `divs(a,b)`. The ARM946 has no divide
   instruction; `a/b` calls `__aeabi_idiv`, which doesn't exist in ML. Division by a constant is fine.
2. **No floats, doubles or 64-bit multiply/divide.** They need runtime helpers that don't exist.
3. **Only symbols in `ALLOWED_IMPORTS.txt`.** No libc (no memcpy, memset or strlen); use the helpers in the
   files.
   - Big local arrays and struct copies can emit memset or memcpy, and the build refuses them.
   - A new ML function is allowed only if it is a normal exported ML core function on BOTH cameras'
     builds. Tell the user.
4. **`bmp_printf` and `NotifyBox` formats: only `%d` and `%s`.** No `%%`, `%u`, `%f` or `%ld`. Write "pct".
5. **`CBR_VSYNC` handlers only bump counters.**
6. **Never touch the SD card while the lens moves.** Logs stay in RAM and are written at the end. The
   profile is read once before a run (V17C), or when idle and the focal length changed (CAMF).
7. **Every lens move goes through the gate check.** Every loop checks stop/cancel and `worker_exit`.
   Deinit waits for the worker.
8. **Module files stay `CAMCAL.MO`, `FZ17C.MO` and `CAMF.MO`.** Profiles stay `ML/LPxxxx.TXT` (8.3 names).
9. **The 70D strings in the CAMERA PROFILE stay as they are.** New camera text goes there as macros.
10. **One module on the lens at a time.** V17C via HALF-SHUTTER + CAMF is safe (CAMF pauses while held).
    V17C from the MENU, or CAMCAL, with CAMF ON is NOT: the 5D3 logs show exactly that fight.
11. **`LENS_PROFILE.h` is shared.** If you change its format, add columns at the END only, so old files
    still parse. Then change CAMCAL's writer, check `tests/card/*/LP*.TXT`, and keep the readers tolerant.

## 6. Facts from real logs: don't "fix" what is already proven (details in `docs/FINDINGS.md`)
- **±3 is NOT three ±1.** It is about 2 units at 135 mm and about 25 units at 18 mm. Never add ±3 moves into
  a ±1 position count.
- **±1 is the exact unit;** a waited ±1 takes about 45 ms.
- **A ±2 probe vanishes into backlash.** Use ±4.
- **At an end stop the lens may "accept" a ±3 without moving.** Only a refusal is a reliable stop.
- **The 85 mm peak is about 2-3 units wide**, with flat, uneven tails. At 64 mm on a monitor the hill was
  about 50 units on a 48% floor.
- **Dark-frame rule:** reject only >90% near-black (fixed everywhere as of CAMF C2).
- **The sharpness rounding bug is still in V17C and CAMF** (task T3).
- **Lens on AF, Canon continuous AF (70D: Movie Servo) OFF.** ML's `lens_focus()` refuses otherwise.
- **CAMCAL 70D runs:** run 1 had a hidden error and a hill too broad for the sweep (fixed C2). Run 2 was a
  gate failure, probably the lens switch on MF (C3 names the failed check and waits).
- **CAMCAL run 1 had about 157 ms between vsyncs** (normal 33); the cause is unknown. `vsync_ms` and
  `picture_ms` are logged now.

## 7. Unknown on the 5D3: measure these, don't assume them
- **Per-lens numbers.** CAMCAL measures them and writes the profile. Ask for CAMCAL at each focal length
  the user shoots, and keep a copy of `ML/LPxxxx.TXT`. The user's 5D3 lens so far is an EF 50mm f/1.8 STM
  (focus-by-wire).
- **Whether `lens_info.job_state` is non-zero while recording on the 5D3.** If it is, CAMF's gate stops it
  while recording.
- **HDMI:** the sampling box is fixed in pixels, so avoid HDMI in tests.
- **mlv_lite "Framing" preview freezes the picture.** CAMCAL detects this; V17C and CAMF don't yet.
- **The 5D3 builds might not load.** Get the exact "undefined symbol" message.
  - New imports this round: `FIO_OpenFile`, `FIO_ReadFile`. They are standard; 10 stock ML modules use
    them.
  - ML's `FIO_ReadFile` copies through DMA memory for buffers up to 8 KB; the profile buffer is 2 KB.

## 8. How to work with the user
1. **Ask for a log after every test:** `ML/CAMCALxxxx.CSV`, `ML/FZ7Cxxxx.CSV`, `ML/CAMFxxxx.CSV` and the
   profile `ML/LPxxxx.TXT`. Every CSV explains its columns in its `#` lines.
2. **Read these first:**
   - CAMCAL `# RESULT` (`err`, `gate_bits`, `fail_stage`, `vsync_ms`, `picture_ms`, `backlash_x10`, `fwhm_x10`,
     `step3_units_x10`);
   - V17C `# SUMMARY` (stop 0 = accepted) and its header (`profile` 0 none / 1 other focal / 2 used, `narrow`);
   - CAMF `# SUMMARY` (`result` 0 = accepted, `profile`).
3. **Turn every new sweep log into a curve** (section 2), add it to `tests/curves/`, and update the golden
   results.
4. **One change at a time.**
   - Bump the version in the banner, the CSV header, `MODULE_LONGNAME`, `MODULE_STRING("Name")` and the
     menu help.
   - Run `./build.sh` and `./test.sh`.
   - Give the user only the changed `.MO` from `bin/5D3/`, with 3-5 lines of test instructions.
5. **Say "simulated only"** until a camera log shows it working. Never invent lens numbers.

## 9. Ranked task list for you
**T0 (first): get 5D3 data.** Give the user `5D3_QUICK_START.txt`: CAMCAL first, at each focal length they
use, so the profile exists. Then V17C Measure, V17C Run, CAMF. Make curves from the CAMCAL logs. Change no
code before the first logs unless a module fails to load.

**T1 (done in this round):** the CAMF dark-frame fix (C2), profiles, and replay. Nothing to do.

**T2: V17C on narrow peaks (the real 85 mm curve: 25% of runs at ≥95%).**
- Use `tests/curves/70D_18-135_85mm.txt`, and 5D3 long-lens curves when they exist.
- Ideas, untested:
  - a final ±1 polish around the landing that compares both neighbours;
  - landing from the side CAMCAL measured as sharper;
  - using `fwhm_x10` from the profile to choose the stride.
- Success = the REPLAY `v17c_sharp95_*` metrics rise and nothing else gets WORSE.

**T3: full-precision sharpness in V17C and CAMF.** This is the change CAMCAL got in C2.
- **Where:** in `src/FZ17C/FZ17C.c` and `src/CAMF/CAMF.c`, inside `sample_frame`.
- **Replace:**
  `rscore=count[k]?divu(raw[k],count[k])*TIGHT_SAMPLES:0` and `wscore=pairs[k]?divu(wg[k],pairs[k])*TIGHT_PAIRS:0`
- **With:**
  `divu(divu(raw[k]<<8,count[k])*(TIGHT_SAMPLES/16u),16u)` and `divu(divu(wg[k]<<8,pairs[k])*(TIGHT_PAIRS/16u),16u)`.
- **Note:** the replay curves were measured WITH the rounding, so judge mostly on the invented-lens tests
  and on camera logs.

**T4: frozen-picture detection in V17C and CAMF.** Copy CAMCAL's raw-sum signature and the
unchanged-picture counter.

**T5: more profile use**, only with evidence from logs. Candidates:
- the CAMF speed cap from `frame_ms` and `lag_x10`;
- V17C settle frames from `lag_x10`;
- the noise floor from `noise_bp`.

Add each one with a replay test that shows the gain.

**T6 (research): Canon's own LiveView focus value on the 5D3** (`CONFIG_LV_FOCUS_INFO`). It needs new
imports; only with the user's agreement.
