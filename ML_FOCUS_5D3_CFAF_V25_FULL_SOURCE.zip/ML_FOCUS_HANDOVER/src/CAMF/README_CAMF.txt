[Handover note: this is the 70D user guide of this module. The same module is built for the 5D Mark III 1.1.3
 (see ../../5D3_QUICK_START.txt). Build everything with ../../build.sh - the per-module BUILD_*.sh scripts were
 replaced by it. On the 5D3 read "Movie Servo AF" as Canon continuous AF and "mode dial" as the Live View switch.
 Versions now: CAMCAL C4 (writes the lens profile ML/LPxxxx.TXT), V17C r5 (half-shutter trigger) and CAMF C3
 (pauses while half-pressed); Backlash Comp AUTO reads the profile. See ../../START_HERE_CHATGPT.md section 2.]

CAMF - Camcorder AF (C1) for Canon EOS 70D firmware 1.1.2, ML module ABI 8
===========================================================================
What it does
  Continuous autofocus in the style of 90s/2000s camcorders: it watches the sharpness of the picture and, when
  it goes soft and stays soft while the shot is calm, it SLIDES focus to the new peak at a set speed - eased in,
  eased out, no jump-and-snap. If the result is not clearly sharper than where it started, it slides back to
  where it started (it never leaves focus worse than it found it).

Install
  Copy CAMF.MO to ML/MODULES on the card and enable it. Menu tab "Focus", eight "CAMF ..." entries.
  Movie Servo must be OFF (the gate refuses to run with Canon continuous AF on). Lens in AF mode, Movie mode, LiveView.
  Do not run it together with the V17/V18 focus modules (they share the lens motor).

Menu
  CAMF Camcorder AF   OFF/ON. ON runs a start-up focus (about 0.3 s measuring, then a glide) and then watches.
  CAMF Refocus Now    start a glide immediately.
  CAMF Glide Speed    CINEMATIC / SLOW / MEDIUM / FAST = about 6 / 10 / 16 / 26 focus units per second
                      (never more than one unit per frame). MEDIUM is the default.
  CAMF Sensitivity    how far sharpness must fall (LOW 20%, MEDIUM 12%, HIGH 7%) and stay down for 0.25 s while
                      the shot is calm. A pan or heavy shake is not "calm", so it does not trigger a search.
  CAMF Range          farthest it may travel from where a search began, each way: 40 / 80 / 160 units.
  CAMF Backlash Comp  OFF / 2 / 4 units. Glides past the peak and returns so the lens arrives from the same side.
                      Default 2. Set it to OFF if the lens has no play (focus-by-wire STM), 4 if landings are short.
  CAMF Focus Region   CENTRE 55% or BALANCED 25% (same weights as FZ17A).
  CAMF Log            writes ML/CAMFxxxx.CSV after every search (about 60 KB) - please send me these.

How a search works (state machine, one step per VSYNC)
  WATCH   sharpness reference follows the scene slowly; a calm drop beyond the sensitivity for 0.25 s starts a search.
  CLIMB   ONE non-blocking unit lens_focus per paced VSYNC (the same invariant V18V uses), speed ramped in over
          about 5 frames. First direction = where the last good focus was; if sharpness falls it reverses once
          (3-frame pause, no jerk). If both sides fall, the start was the peak: it returns to the start.
          Speed eases off as the climb flattens.
  BRAKE   two confirmed declines past the peak stop the commands.
  RETURN  a per-unit sharpness table gives the peak (3-point parabola); it glides back with distance-based
          deceleration, finishing in the opposite direction past the peak by the backlash setting.
  VERIFY  3 settled frames; must beat the starting sharpness by max(3%, 3 x measured noise) to be accepted,
          otherwise it glides back to the start. A failed search backs off 4 s (10 s after three in a row).

Honest limits
  * NOT camera tested. The simulation uses an assumed lens model (see HOST_TEST_RESULTS.txt).
  * The V18V invariant (one NON-WAITED unit command per frame works on the calibrated 18-135 Nano USM) is assumed
    to hold for your lens. If lens_focus rejects commands the search gives up at once ("motor reject", result 6).
  * lens_info.job_state is part of the gate (as in V17/V18). If it is non-zero while recording on your camera,
    the module will stop acting during recording - the log will show result 4 / state OFF. Tell me and I will relax it.
  * The first search cannot know which side of its play the lens rests on, so it can land up to the backlash
    amount off; after that the side is tracked.
  * Command units are not encoder counts and the sharpness metric is the YUV preview, as in FZ17A.
  * Where the scene has no visible blur gradient (very far out of focus, very low contrast) it reports
    NO HILL and returns to the start rather than guessing.

Log columns (ML/CAMFxxxx.CSV)
  header SUMMARY: result (0 ok, 1 already at peak, 2 no gain/went home, 3 no hill, 4 gate/image, 5 timeout,
  6 motor reject), origin/peak/target/final positions, fv0/best/fin/ref sharpness, cmds, ms, noise_bp.
  rows (every VSYNC): ms, state, pos (commands issued), eff (position the frame is attributed to), fv, fvs
  (3-frame mean), vq8 (speed in 1/256 unit per frame), cmd (1 = a unit was issued), valid, rel_bp (fvs vs reference).

Build
  CLANG=<..>/clang-17 OBJCOPY=<..>/llvm-objcopy ./BUILD_CAMF.sh   (fails if any __* or mem* import appears)
  CAMF.MO sha256 78d604744ae444e528863d5e18b7e3af82850c7c48aa77c9c388048822325dd4
