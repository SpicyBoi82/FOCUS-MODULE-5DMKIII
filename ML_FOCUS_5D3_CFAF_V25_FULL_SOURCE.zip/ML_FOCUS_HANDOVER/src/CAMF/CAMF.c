/*
 * CAMF - Canon EOS 70D 1.1.2 and 5D Mark III 1.1.3 (-DCAM_5D3) - "Camcorder AF" (C3).
 * C3 (16 Oct 2026): pauses while the shutter is held half-way (V17C r5 half-shutter AF, or Canon AF); 1.2 s
 * after release it re-measures the scene without searching and watches again.
 * C2 (16 Oct 2026): Backlash Comp AUTO (default) from the CAMCAL lens profile ML/LPxxxx.TXT (2 units without
 * one, = C1 default); dark-frame check >90% near-black (C1 rejected in-focus frames on dark backgrounds).
 * Continuous, glide-style contrast autofocus in the manner of 1990s/2000s
 * camcorders: it watches sharpness, and when the picture goes soft it
 * SLIDES the focus to the new peak at a controlled speed, with a soft start,
 * a soft landing and no snap/hunt that shows in footage.
 *
 *   WATCH   - sharpness tracked per VSYNC; a persistent calm drop (not a pan)
 *             starts a search.
 *   CLIMB   - ONE non-blocking unit lens_focus per paced VSYNC (the V18V
 *             invariant), velocity ramped up; direction decided from the first
 *             frames, reversed once if wrong; speed eased near the top.
 *   BRAKE   - first confirmed decline past the peak: stop commanding.
 *   RETURN  - parabola through the per-unit sharpness table gives the peak;
 *             glide back with distance-based deceleration, overshooting by the
 *             backlash compensation so we arrive in the return direction.
 *   VERIFY  - settled 3-frame median must beat the starting sharpness; if it
 *             does not, glide back to where we started (never leave it worse).
 *
 * Command units are NOT lens encoder counts. Sharpness is the YUV preview.
 * Not camera tested. Every state is driven by camf_step(), one call per VSYNC.
 */
#define MODULE
#define MODULE_NAME camf
#include <stdint.h>
#include "module.h"
#include "dryos.h"
#include "menu.h"
#include "config.h"


/* ===================== CAMERA PROFILE (the ONLY camera-specific part of this file) =====================
 * Default build = Canon EOS 70D fw 1.1.2.   Build with -DCAM_5D3 = Canon EOS 5D Mark III fw 1.1.3.
 * Both: Magic Lantern module API 8, DIGIC 5, LiveView YUV422 preview, CBR_VSYNC once per LiveView frame.
 * Only text and the is_camera() check differ. Keep the 70D strings byte-identical (proves 70D unchanged). */
#if defined(CAM_5D3)
#define CAM_MODEL        "5D3"
#define CAM_FW           "1.1.3"
#define CAM_CSV_TAG      " [5D3 1.1.3]"
#define CAM_SERVO        "continuous AF"          /* 5D3 has no Movie Servo AF; ML reports none in movie mode */
#define CAM_SERVO_MUST   "Canon continuous AF must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (Live View switch to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, lens on AF, continuous AF OFF"
#else   /* default: 70D */
#define CAM_MODEL        "70D"
#define CAM_FW           "1.1.2"
#define CAM_CSV_TAG      ""
#define CAM_SERVO        "Movie Servo AF"
#define CAM_SERVO_MUST   "Movie Servo must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (mode dial to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, AF lens, Movie Servo OFF"
#endif
/* ======================================================================================================== */
extern int is_camera(const char*,const char*);
extern int get_halfshutter_pressed(void);              /* C3: pause while the shutter is held half-way (V17C r5) */
extern int is_movie_mode(void);
extern uint32_t get_ms_clock(void);
extern void msleep(int);
extern int task_create(const char*,int,int,void(*)(void*),void*);
extern int FIO_CreateFile(const char*);
extern int FIO_WriteFile(int,const void*,unsigned);
extern int FIO_CloseFile(int);
extern void menu_remove(const char*,struct menu_entry*,int);
extern int lv;
extern int is_manual_focus(void);
extern int is_continuous_af(void);
extern int lens_focus(int,int,int,int);
struct vram_info_probe { uint8_t *vram; int width,pitch,height; };
extern struct vram_info_probe *get_yuv422_vram(void);
struct lens_info_probe
{
    void *token;
    char name[32];
    unsigned focal_len;
    unsigned focus_dist;
    unsigned IS;
    unsigned aperture;
    int ae;
    unsigned shutter;
    unsigned iso;
    unsigned iso_auto;
    unsigned iso_analog_raw;
    int iso_digital_ev;
    unsigned iso_equiv_raw;
    unsigned hyperfocal;
    unsigned dof_near;
    unsigned dof_far;
    unsigned job_state;
    unsigned wb_mode;
    unsigned kelvin;
    unsigned WBGain_R;
    unsigned WBGain_G;
    unsigned WBGain_B;
    int8_t wbs_gm;
    int8_t wbs_ba;
    unsigned picstyle;
    uint8_t raw_aperture;
    uint8_t raw_shutter;
    uint8_t raw_iso;
    uint8_t raw_iso_auto;
    uint8_t raw_picstyle;
    uint8_t raw_aperture_min;
    uint8_t raw_aperture_max;
    int flash_ae;
    uint16_t lens_id;
    uint16_t dof_flags;
    int dof_diffraction_blur;
    int focus_pos;
    uint8_t lens_exists;
};
extern struct lens_info_probe lens_info;
#include "../common/LENS_PROFILE.h"      /* C2: per-lens numbers measured by CAMCAL (ML/LPxxxx.TXT) */
#define TIGHT_W 80
#define TIGHT_H 60
#define MED_W 120
#define MED_H 80
#define WIDE_W 180
#define WIDE_H 120
#define TIGHT_SAMPLES 1200u
#define TIGHT_PAIRS 2400u
struct score {
    uint32_t raw,wide,luma,raw_t,raw_m,raw_w,wide_t,wide_m,wide_w;
    uint32_t raw_noise,wide_noise;
    uint32_t clipped,dark,samples;
};
static struct score current;
static int absi(int v) { return v<0?-v:v; }
static uint32_t maxu(uint32_t a,uint32_t b) { return a>b?a:b; }
static uint32_t divu(uint32_t n,uint32_t d)
{
    uint32_t q=0,b=1;
    if (!d) return 0;
    while (d<n && !(d&0x80000000u)) {d<<=1;b<<=1;}
    while (b) {if(n>=d){n-=d;q|=b;}d>>=1;b>>=1;}
    return q;
}
#ifdef UNIT_TEST
static int valid_addr(uint32_t a){return a!=0;}
#else
static int valid_addr(uint32_t a){return a>=0x1000u && a<0x80000000u && !(a&3u);}
#endif

static int image_reason=0;
static int last_buf_w,last_buf_h,last_buf_pitch;
static uint32_t last_buf_addr;
enum { I_OK=0,I_NO_DESC=1,I_NULL_PTR=2,I_BAD_ADDR=3,I_BAD_GEOM=4,I_EMPTY=5,I_TOO_DARK=6,I_TOO_BRIGHT=7,I_NO_CONTRAST=9 };

static CONFIG_INT("camf.on",af_on,0);
static CONFIG_INT("camf.speed",speed_setting,2);   /* 0 cinematic 6, 1 slow 10, 2 medium 16, 3 fast 26 units/s */
static CONFIG_INT("camf.sens",sens_setting,1);     /* 0 low 20%, 1 medium 12%, 2 high 7% sharpness drop */
static CONFIG_INT("camf.range",range_setting,1);   /* 0: 40, 1: 80, 2: 160 units each way */
static CONFIG_INT("camf.comp",comp_setting,3);     /* 0 off, 1: 2 units, 2: 4 units, 3: AUTO (C2 default: profile, else 2) */
static CONFIG_INT("camf.region",focus_region,0);   /* 0 centre-weighted, 1 balanced */
static CONFIG_INT("camf.now",now_request,0);
static CONFIG_INT("camf.log",log_setting,1);
static volatile int worker_exit=0,worker_busy=0;
static int sample_frame(struct score *v)
{
    struct vram_info_probe *vi=get_yuv422_vram();
    uint8_t *buf;
    uint32_t raw[3]={0,0,0},wg[3]={0,0,0},lum[3]={0,0,0};
    uint32_t count[3]={0,0,0},pairs[3]={0,0,0};
    uint32_t normal_raw[3],normal_wide[3];
    int x,y,cx,cy,x0,x1,y0,y1,w,h,pitch,k;
    v->raw=v->wide=v->luma=0;
    v->raw_t=v->raw_m=v->raw_w=0;
    v->wide_t=v->wide_m=v->wide_w=0;
    v->raw_noise=v->wide_noise=0;
    v->clipped=v->dark=v->samples=0;
    image_reason=I_OK;
    if (!vi){image_reason=I_NO_DESC;return 0;}
    buf=vi->vram;w=vi->width;h=vi->height;pitch=vi->pitch;
    last_buf_addr=(uint32_t)buf;last_buf_w=w;last_buf_h=h;last_buf_pitch=pitch;
    if (!buf){image_reason=I_NULL_PTR;return 0;}
    if (!valid_addr((uint32_t)buf)){image_reason=I_BAD_ADDR;return 0;}
    if(w<240 || h<180 || pitch<w*2 || pitch>8192){image_reason=I_BAD_GEOM;return 0;}
    cx=w/2;cy=h/2;
    x0=cx-WIDE_W;x1=cx+WIDE_W;y0=cy-WIDE_H;y1=cy+WIDE_H;
    if(x0<8)x0=8;if(y0<8)y0=8;
    if(x1>w-9)x1=w-9;if(y1>h-9)y1=h-9;
    for(y=y0;y<y1;y+=4)
    {
        uint8_t *r=buf+y*pitch,*up=buf+(y-2)*pitch,*dn=buf+(y+2)*pitch;
        uint8_t *wu=buf+(y-6)*pitch,*wd=buf+(y+6)*pitch;
        for(x=x0;x<x1;x+=4)
        {
            int off=(x<<1)+1;
            int yc=r[off],yl=r[((x-2)<<1)+1],yr=r[((x+2)<<1)+1];
            int yu=up[off],yd=dn[off];
            int wl=r[((x-6)<<1)+1],wr=r[((x+6)<<1)+1];
            int vw=wu[off],vx=wd[off];
            uint32_t g=(uint32_t)(absi(yr-yl)+absi(yd-yu));
            uint32_t gw=0,ng=0;
            if(wl>3&&wl<252&&wr>3&&wr<252){gw+=(uint32_t)absi(wr-wl);ng++;}
            if(vw>3&&vw<252&&vx>3&&vx<252){gw+=(uint32_t)absi(vx-vw);ng++;}
            /* 0 wide, 1 medium, 2 tight: nested region statistics. */
            for(k=0;k<3;k++)
            {
                if(k==1 && (x<cx-MED_W||x>=cx+MED_W||y<cy-MED_H||y>=cy+MED_H)) continue;
                if(k==2 && (x<cx-TIGHT_W||x>=cx+TIGHT_W||y<cy-TIGHT_H||y>=cy+TIGHT_H)) continue;
                raw[k]+=g;wg[k]+=gw;lum[k]+=(uint32_t)yc;
                count[k]++;pairs[k]+=ng;
            }
            if(x>=cx-TIGHT_W&&x<cx+TIGHT_W&&y>=cy-TIGHT_H&&y<cy+TIGHT_H)
            {
                v->samples++;if(yc<=16)v->dark++;if(yc>=235)v->clipped++;
            }
        }
    }
    if (!count[2]||!pairs[2]){image_reason=I_EMPTY;return 0;}
    for(k=0;k<3;k++)
    {
        uint32_t mean=count[k]?divu(lum[k],count[k]):1u;
        uint32_t rscore=count[k]?divu(raw[k],count[k])*TIGHT_SAMPLES:0;
        uint32_t wscore=pairs[k]?divu(wg[k],pairs[k])*TIGHT_PAIRS:0;
        normal_raw[k]=divu(rscore*256u,mean?mean:1u);
        normal_wide[k]=divu(wscore*256u,mean?mean:1u);
    }
    v->raw=raw[2];v->wide=wg[2];v->luma=divu(lum[2],count[2]);
    v->raw_t=normal_raw[2];v->raw_m=normal_raw[1];v->raw_w=normal_raw[0];
    v->wide_t=normal_wide[2];v->wide_m=normal_wide[1];v->wide_w=normal_wide[0];
    if (v->luma<12){image_reason=I_TOO_DARK;return 0;}
    if (v->luma>242){image_reason=I_TOO_BRIGHT;return 0;}
    if (v->dark > v->samples - v->samples/10){image_reason=I_TOO_DARK;return 0;}   /* C2: >90% (the >50% rule rejected in-focus frames on dark backgrounds) */
    if(!v->raw||!v->wide){image_reason=I_NO_CONTRAST;return 0;}
    return 1;
}
static int divs(int a,int b)
{
    int neg=0;uint32_t ua,ub,q;
    if(!b)return 0;
    if(a<0){a=-a;neg^=1;}
    if(b<0){b=-b;neg^=1;}
    ua=(uint32_t)a;ub=(uint32_t)b;
    q=divu(ua*2u+ub,ub*2u);
    return neg?-(int)q:(int)q;
}

static uint32_t fv_from(const struct score *v)
{
    uint32_t r,w;
    if(focus_region)
    {
        r=divu(v->raw_w*40u+v->raw_m*35u+v->raw_t*25u,100u);
        w=divu(v->wide_w*40u+v->wide_m*35u+v->wide_t*25u,100u);
    }
    else
    {
        r=divu(v->raw_w*15u+v->raw_m*30u+v->raw_t*55u,100u);
        w=divu(v->wide_w*15u+v->wide_m*30u+v->wide_t*55u,100u);
    }
    return r+w;
}
static int output_handle=0;static char output_buf[512];static int output_len=0;
static void flush(void)
{
    if(output_len&&output_handle>0)FIO_WriteFile(output_handle,output_buf,(unsigned)output_len);
    output_len=0;
}
static void ch(char c)
{
    if(output_len>450)flush();output_buf[output_len++]=c;
}
static void txt(const char *s){while(*s)ch(*s++);}
static void num(uint32_t n)
{
    char b[12];int i=0;if(!n){ch('0');return;}
    while(n&&i<11){b[i++]=(char)('0'+n%10u);n=divu(n,10);}
    while(i)ch(b[--i]);
}
static void snum(int n){if(n<0){ch('-');num((uint32_t)(-(int64_t)n));}else num((uint32_t)n);}
static void comma(void){ch(',');}
static void iout(int n){snum(n);comma();}
static void uout(uint32_t n){num(n);comma();}

/* ======================= camcorder AF engine ======================= */
extern void powersave_prolong(void);



static int sgn(int v){return v>0?1:(v<0?-1:0);}
static int clampi(int v,int lo,int hi){return v<lo?lo:(v>hi?hi:v);}
/* (a-b)/b in basis points, clamped, no 64-bit divide. */
static int rel_bp(uint32_t a,uint32_t b)
{
    uint32_t d,q;int neg;
    if(!b)return a?20000:0;
    while(b>(1u<<17)){a>>=1;b>>=1;}
    if(!b)return 0;
    neg=a<b;d=neg?b-a:a-b;
    if(d>(1u<<22))d=(1u<<22);
    q=divu(d<<8,b);
    if(q>3200u)q=3200u;
    q=(q*625u)>>4;
    if(q>20000u)q=20000u;
    return neg?-(int)q:(int)q;
}

#define LAG_UNITS 1
#define RANGE_CAP 160
#define TMAX 360
#define ROWS 1500
enum { ST_OFF=0,ST_BASE,ST_WATCH,ST_CLIMB,ST_BRAKE,ST_RETURN,ST_SETTLE,ST_VERIFY,ST_COOL,ST_PAUSE };
enum { R_NONE=-1,R_OK=0,R_AT_PEAK=1,R_NO_GAIN=2,R_NO_HILL=3,R_GATE=4,R_TIMEOUT=5,R_MOTOR=6,R_PAUSED=7 };
static int hs_rel_t=0,resume_quiet=0,pauses=0;   /* C3 */

static volatile uint32_t vs_seq=0,vs_ms=0;
static unsigned int on_vsync(unsigned int ctx){(void)ctx;vs_seq++;vs_ms=get_ms_clock();return 0;}

static int state=ST_OFF;
static uint32_t frame_no=0,prev_vs_ms=0,t_now=0;
static int fp_ms=33;
static int cur_pos=0,origin=0,last_move_dir=0,last_cmd_frame=-100,cmds=0,fail_streak=0;
static uint32_t hist[3];static int hist_n=0;
static uint32_t fvs=0,fvs_h[3];static int fvs_hn=0;
static uint32_t ref_fv=0,fv0=0,best_fv=0,fin_fv=0;
static int nz_bp=300,trig_n=0,streak=0;
static int base_n=0;static uint32_t base_fv[8];
/* search */
static int cdir=1,last_good_dir=1,reversed=0,rise_seen=0,decline=0,wd=0,pause_n=0,n_run=0;
static int run_start=0,tbase=0,best_eff=0,v_q8=0,acc_q8=0,brake_n=0,settle_n=0,cool_n=0;
static int target=0,homing=0,result=R_NONE,at_peak=0,fails_row=0,comp_used=0,peak_pos=0;
static int search_no=0,flat_lim=14;
static uint32_t search_t0=0,ver_fv[3];static int ver_n=0;
static uint32_t tsum[TMAX];static uint8_t tcnt[TMAX];

static int range_units(void){return range_setting>=2?RANGE_CAP:(range_setting==1?80:40);}
/* C2: lens profile, re-read when idle and the focal length changed (zoom) */
static const struct lprof *prof=0;static int prof_near=0,prof_focal=-1;
static void prof_setup(void){prof=0;prof_near=0;prof_focal=(int)lens_info.focal_len;if(lp_load())prof=lp_find(prof_focal,&prof_near);}
/* setting 3 = AUTO: same rule CAMCAL uses for its CAMF advice (backlash <1 unit: off, <3: 2 units, else 4);
   2 units (the C1 default) when there is no profile */
static int comp_units(void)
{
    if(comp_setting>=3)
    {
        int B;
        if(!prof)return 2;
        B=(prof->back10+5)/10;
        return B<1?0:(B<3?2:4);
    }
    return comp_setting>=2?4:(comp_setting==1?2:0);
}
static int vsec(void){static const int t[4]={6,10,16,26};return t[clampi(speed_setting,0,3)];}
static int vmax_q8(void)
{
    uint32_t q=divu((uint32_t)vsec()*(uint32_t)fp_ms*256u+500u,1000u);
    if(q>256u)q=256u;if(q<48u)q=48u;return (int)q;
}
static int vmin_q8(void){int v=vmax_q8()/4;return v<40?40:v;}
static int trig_bp(void){int t=sens_setting>=2?700:(sens_setting==1?1200:2000);int n=nz_bp*4;return n>t?n:t;}
static int rise_thr(void){int t=nz_bp*3;return t<300?300:t;}
static int drop_thr(void){int t=(nz_bp*7)>>1;return t<400?400:t;}
static int gain_need(void){int t=nz_bp*3;return t<300?300:t;}

static int gate(void)
{
    int g=0;
    if(!lv)g|=1;
    if(!is_movie_mode())g|=2;
    if(is_manual_focus())g|=4;
    if(is_continuous_af())g|=8;
    if(!lens_info.lens_exists)g|=16;
    if(lens_info.job_state)g|=32;
    if(worker_exit)g|=64;
    return g;
}

/* ---- log ring ---- */
struct row { uint32_t ms; int16_t pos,eff; uint32_t fv,fvs; uint16_t vq,rel; uint8_t st,cmd,valid,rsv; };
static struct row rows[ROWS];static int row_n=0,row_head=0;
static int cur_eff=0,cur_cmd=0,cur_valid=0;static uint32_t cur_fv=0;
static void log_row(void)
{
    struct row *r;int idx;
    if(!log_setting)return;
    idx=row_head;
    if(row_n<ROWS){idx=row_n++;} else {row_head++;if(row_head>=ROWS)row_head=0;}
    r=&rows[idx];
    r->ms=t_now;r->pos=(int16_t)cur_pos;r->eff=(int16_t)cur_eff;r->fv=cur_fv;r->fvs=fvs;
    r->vq=(uint16_t)v_q8;r->rel=(uint16_t)clampi(rel_bp(fvs,ref_fv)+10000,0,20000);
    r->st=(uint8_t)state;r->cmd=(uint8_t)cur_cmd;r->valid=(uint8_t)cur_valid;
}
static uint32_t log_serial=0;

/* ---- motion ---- */
static int issue(int dir)
{
    int rc;
    if(gate())return 0;
    rc=lens_focus(1,dir,0,0);               /* ONE unit, NOT waited (V18V invariant) */
    if(!rc){fail_streak++;return 0;}
    fail_streak=0;cur_pos+=dir;last_move_dir=dir;last_cmd_frame=(int)frame_no;cmds++;cur_cmd=1;
    return 1;
}
/* accumulate fractional units; at most one command per VSYNC */
static void pace(int dir)
{
    acc_q8+=v_q8;
    if(acc_q8>512)acc_q8=512;
    if(acc_q8>=256 && dir){ if(issue(dir))acc_q8-=256; }
}
static void ramp_to(int tq8)
{
    int a=vmax_q8()/5;if(a<8)a=8;
    if(v_q8<tq8){v_q8+=a;if(v_q8>tq8)v_q8=tq8;}
    else if(v_q8>tq8){v_q8-=2*a;if(v_q8<tq8)v_q8=tq8;}
}
static int eff_pos(void)
{
    if(last_move_dir && (int)frame_no-last_cmd_frame<=2)return cur_pos-last_move_dir*LAG_UNITS;
    return cur_pos;
}
static void table_clear(void){int i;for(i=0;i<TMAX;i++){tsum[i]=0;tcnt[i]=0;}}
static void table_add(int eff,uint32_t fv)
{
    int i=(eff-tbase)*cdir;
    if(i<0)i=0;if(i>=TMAX)i=TMAX-1;
    if(tcnt[i]<255){tsum[i]+=fv;tcnt[i]++;}
}
static int table_val(int i,uint32_t *v)
{
    if(i<0||i>=TMAX||!tcnt[i])return 0;
    *v=divu(tsum[i],tcnt[i]);return 1;
}
/* 3-wide mean over the populated neighbours */
static int table_smooth(int i,uint32_t *v)
{
    uint32_t s=0,t;int n=0,k;
    for(k=-1;k<=1;k++)if(table_val(i+k,&t)){s+=t;n++;}
    if(!n)return 0;*v=divu(s,(uint32_t)n);return 1;
}
/* Peak position (absolute command coordinate) from the table. */
static int estimate_peak(void)
{
    int i,ib=-1,h,top=0;uint32_t bv=0,v,y1,y2,y3;int off=0;
    for(i=0;i<TMAX;i++)if(tcnt[i])top=i;
    for(i=0;i<=top;i++)if(table_smooth(i,&v)&&v>bv){bv=v;ib=i;}
    if(ib<0)return origin;
    for(h=3;h>=1;h--)
    {
        if(ib-h>=0&&ib+h<=top&&table_smooth(ib-h,&y1)&&table_smooth(ib,&y2)&&table_smooth(ib+h,&y3))
        {
            int den=(int)y1-2*(int)y2+(int)y3;
            if(den<0){off=divs(h*((int)y1-(int)y3),2*den);off=clampi(off,-h,h);}
            break;
        }
    }
    return tbase+cdir*(ib+off);
}

static int side0=1;     /* direction of the last lens move before this search began */
static void trace_reset(void)
{
    table_clear();
}
static void begin_search(void)
{
    origin=cur_pos;fv0=fvs;cdir=last_good_dir?last_good_dir:1;reversed=0;rise_seen=0;decline=0;wd=0;
    pause_n=0;v_q8=0;acc_q8=0;run_start=cur_pos;tbase=cur_pos;n_run=0;cmds=0;flat_lim=14;
    homing=0;at_peak=0;result=R_NONE;best_fv=0;best_eff=cur_pos;search_t0=t_now;search_no++;
    peak_pos=origin;target=origin;fail_streak=0;side0=last_move_dir?last_move_dir:1;
    trace_reset();state=ST_CLIMB;
}
static void reverse_now(void)
{
    reversed=1;cdir=-cdir;pause_n=3;acc_q8=0;v_q8=0;tbase=cur_pos;run_start=cur_pos;
    wd=0;rise_seen=0;decline=0;best_fv=0;n_run=0;trace_reset();
}
static void go_return(int tgt,int home)
{
    if(home)
    {   /* arrive back at the starting PHYSICAL position: allow for the play lost on each reversal */
        int b=comp_units(),h=sgn(origin-cur_pos);
        tgt=origin+b*((side0<0)-(h<0));
    }
    target=tgt;homing=home;state=ST_RETURN;acc_q8=0;
}
static void end_climb_peak(void)
{
    state=ST_BRAKE;brake_n=0;v_q8=0;acc_q8=0;
}
static void climb_fail(int code)
{
    result=code;go_return(origin,1);
}

static void climb_tick(int valid,uint32_t fv)
{
    int sdo,rel,vmaxq=vmax_q8(),tq,range=range_units();
    if(pause_n>0){pause_n--;v_q8=0;return;}
    n_run++;
    if((int)(t_now-search_t0)>14000 || cmds>2*range+80){climb_fail(R_TIMEOUT);return;}
    if(valid)
    {
        int eff=eff_pos();
        cur_eff=eff;
        table_add(eff,fv);
        sdo=(eff-origin)*cdir;
        rel=rel_bp(fvs,fv0);
        if(!rise_seen)
        {
            if(rel>=rise_thr() && sdo>=2){rise_seen=1;best_fv=fvs;best_eff=eff;decline=0;}
            else
            {
                if(sdo>=4 && rel<=-drop_thr()){wd++;} else if(wd>0){wd--;}
                if(wd>=2)
                {
                    if(!reversed){reverse_now();return;}
                    at_peak=1;result=R_AT_PEAK;go_return(origin,1);return;   /* both sides decline: origin is the peak */
                }
                if(sdo>=flat_lim && absi(rel)<rise_thr())
                {
                    if(!reversed){reverse_now();return;}
                    climb_fail(R_NO_HILL);return;
                }
            }
        }
        else
        {
            if(fvs>best_fv){best_fv=fvs;best_eff=eff;decline=0;}
            else if(rel_bp(fvs,best_fv)<=-drop_thr()){decline++;if(decline>=2){end_climb_peak();return;}}
            else if(decline>0)decline--;
        }
    }
    /* wall: range limit or the lens refusing commands */
    if(absi(cur_pos-origin)>=range || fail_streak>=5)
    {
        if(rise_seen){end_climb_peak();return;}
        if(!reversed){reverse_now();return;}
        climb_fail(fail_streak>=5?R_MOTOR:R_NO_HILL);return;
    }
    /* speed: ease off once we are on the hill's top */
    tq=vmaxq;
    if(rise_seen && fvs_hn>=3)
    {   /* ease off as the climb flattens: full speed above +15% per 3 frames, half speed at +3% or less */
        int slope=rel_bp(fvs,fvs_h[0]),f=clampi(slope-300,0,1200);
        tq=vmaxq/2+(vmaxq/2)*f/1200;
        if(tq<vmin_q8())tq=vmin_q8();
    }
    ramp_to(tq);
    pace(cdir);
}
static void brake_tick(int valid,uint32_t fv)
{
    v_q8=0;brake_n++;cur_eff=cur_pos;
    if(valid&&brake_n>=2)table_add(cur_pos,fv);
    if(brake_n>=4)
    {
        int comp=comp_units();
        peak_pos=estimate_peak();
        comp_used=comp;
        target=peak_pos-cdir*comp;
        target=clampi(target,origin-range_units(),origin+range_units());
        last_good_dir=cdir;
        go_return(target,0);
    }
}
static void return_tick(void)
{
    int dist=target-cur_pos,dir=sgn(dist),ad=absi(dist),tq,vmaxq=vmax_q8(),vmn=vmin_q8();
    if(!dist){v_q8=0;state=ST_SETTLE;settle_n=0;return;}
    if(!homing && absi(cur_pos-origin)>range_units()+8){go_return(origin,1);return;}
    if(last_move_dir && dir!=last_move_dir && v_q8>vmn)
    {   /* still travelling the other way: come to rest first, then reverse */
        ramp_to(vmn);pace(last_move_dir);return;
    }
    tq=vmn+ad*divs(vmaxq-vmn,8);if(tq>vmaxq)tq=vmaxq;
    ramp_to(tq);
    pace(dir);
    if(fail_streak>=5){state=ST_SETTLE;settle_n=0;if(result==R_NONE)result=R_MOTOR;}
}
static void begin_cool(int ms)
{
    cool_n=(int)divu((uint32_t)ms,(uint32_t)(fp_ms>0?fp_ms:33));state=ST_COOL;v_q8=0;
}
static void finish_search(void);
static void verify_done(void)
{
    uint32_t a=ver_fv[0],b=ver_fv[1],c=ver_fv[2],t;
    if(a>b){t=a;a=b;b=t;} if(b>c){t=b;b=c;c=t;} if(a>b){t=a;a=b;b=t;}
    fin_fv=b;
    if(homing)
    {
        if(result==R_NONE)result=R_NO_GAIN;
        ref_fv=fin_fv;finish_search();return;
    }
    if(rel_bp(fin_fv,fv0)>=gain_need()){result=R_OK;ref_fv=fin_fv;finish_search();return;}
    result=R_NO_GAIN;go_return(origin,1);          /* never leave it worse than we found it */
}

static void write_log(void);
static void finish_search(void)
{
    int bad=(result!=R_OK&&result!=R_AT_PEAK);
    if(bad)fails_row++;else fails_row=0;
    write_log();
    begin_cool(bad?(fails_row>=3?10000:4000):1500);
}

/* ---- WATCH ---- */
static uint32_t last_fv=0,ring6[6];static int ring6_n=0,ring6_i=0;
static void watch_tick(int valid,uint32_t fv)
{
    int calm,spread,i,need;uint32_t mx=0,mn=0xFFFFFFFFu;
    if(now_request){now_request=0;begin_search();return;}
    if(!valid)return;
    if(last_fv){int j=absi(rel_bp(fv,last_fv));nz_bp+=(j-nz_bp)>>4;nz_bp=clampi(nz_bp,100,1200);}
    last_fv=fv;
    ring6[ring6_i]=fv;ring6_i++;if(ring6_i>=6)ring6_i=0;if(ring6_n<6)ring6_n++;
    if(ring6_n<6)return;
    for(i=0;i<6;i++){if(ring6[i]>mx)mx=ring6[i];if(ring6[i]<mn)mn=ring6[i];}
    spread=rel_bp(mx,mn);
    i=nz_bp*8;if(i<1500)i=1500;
    calm=(spread<i);
    if(calm)
    {
        int d=rel_bp(fvs,ref_fv);
        if(d>-(trig_bp()>>1))
        {
            if(fvs>ref_fv)ref_fv+=(fvs-ref_fv)>>2;
            else ref_fv-=(ref_fv-fvs)>>7;
        }
        if(d<=-trig_bp())streak++;else streak=0;
    }
    else streak=0;
    need=(int)divu(250u+(uint32_t)fp_ms-1u,(uint32_t)(fp_ms>0?fp_ms:33));if(need<4)need=4;
    if(streak>=need){streak=0;begin_search();}
}

static int invalid_run=0;
static void camf_step(void)
{
    struct score f;uint32_t fv=0;int valid=0;
    t_now=get_ms_clock();frame_no++;
    if((state==ST_OFF||state==ST_BASE||state==ST_WATCH||state==ST_COOL)&&(int)lens_info.focal_len!=prof_focal)prof_setup();   /* C2 */
    {
        int dt=(int)(vs_ms-prev_vs_ms);
        if(prev_vs_ms&&dt>=8&&dt<=100)fp_ms+=(dt-fp_ms)>>3;
        prev_vs_ms=vs_ms;
    }
    cur_cmd=0;cur_valid=0;cur_fv=0;cur_eff=cur_pos;
    if(!af_on||gate())
    {
        if(state!=ST_OFF){state=ST_OFF;v_q8=0;acc_q8=0;}
        base_n=0;ring6_n=0;last_fv=0;
        return;
    }
    if(state==ST_OFF){state=ST_BASE;base_n=0;ring6_n=0;last_fv=0;hist_n=0;fvs_hn=0;}
    /* C3: half-shutter held (V17C r5 is focusing, or Canon AF): stop commanding at once and wait. 1.2 s after
       it is let go, measure the scene again WITHOUT searching (the focus was just set) and go back to watching. */
    if(get_halfshutter_pressed()||state==ST_PAUSE)
    {
        if(get_halfshutter_pressed())
        {
            hs_rel_t=0;
            if(state!=ST_PAUSE)
            {
                if(state>=ST_CLIMB&&state<=ST_VERIFY){result=R_PAUSED;fin_fv=0;write_log();}   /* search cut short */
                state=ST_PAUSE;v_q8=0;acc_q8=0;pauses++;
            }
            return;
        }
        if(!hs_rel_t)hs_rel_t=(int)t_now|1;
        if((int)t_now-hs_rel_t<1200)return;
        hs_rel_t=0;state=ST_BASE;base_n=0;ring6_n=0;last_fv=0;hist_n=0;fvs_hn=0;resume_quiet=1;
    }
    valid=sample_frame(&f);
    if(valid)
    {
        uint32_t s;int n,k;
        fv=fv_from(&f);cur_fv=fv;cur_valid=1;invalid_run=0;
        hist[2]=hist[1];hist[1]=hist[0];hist[0]=fv;if(hist_n<3)hist_n++;
        s=0;n=hist_n;for(k=0;k<n;k++)s+=hist[k];
        fvs_h[0]=fvs_h[1];fvs_h[1]=fvs_h[2];fvs_h[2]=fvs;if(fvs_hn<3)fvs_hn++;
        fvs=divu(s,(uint32_t)n);
    }
    else invalid_run++;
    switch(state)
    {
    case ST_BASE:
        if(valid)
        {
            base_fv[base_n++]=fv;
            if(base_n>=8)
            {
                int i,j,sum=0;uint32_t t;
                for(i=1;i<8;i++)sum+=absi(rel_bp(base_fv[i],base_fv[i-1]));
                nz_bp=clampi(divs(sum,7),100,1200);
                for(i=1;i<8;i++){t=base_fv[i];j=i-1;while(j>=0&&base_fv[j]>t){base_fv[j+1]=base_fv[j];j--;}base_fv[j+1]=t;}
                ref_fv=base_fv[4];
                hist[0]=hist[1]=hist[2]=ref_fv;hist_n=3;fvs=ref_fv;
                if(resume_quiet){resume_quiet=0;state=ST_WATCH;streak=0;ring6_n=0;}   /* C3: after a pause */
                else begin_search();       /* start-up focus */
            }
        }
        break;
    case ST_WATCH:  watch_tick(valid,fv);break;
    case ST_CLIMB:
        if(invalid_run>15){climb_fail(R_GATE);break;}
        climb_tick(valid,fv);break;
    case ST_BRAKE:  brake_tick(valid,fv);break;
    case ST_RETURN: return_tick();break;
    case ST_SETTLE:
        v_q8=0;settle_n++;
        if(settle_n>=3 && settle_n*fp_ms>=130){state=ST_VERIFY;ver_n=0;}
        break;
    case ST_VERIFY:
        if(valid){ver_fv[ver_n++]=fv;if(ver_n>=3)verify_done();}
        else if(invalid_run>15){result=R_GATE;ref_fv=fvs;finish_search();}
        break;
    case ST_COOL:
        if(--cool_n<=0){state=ST_WATCH;streak=0;ring6_n=0;}
        break;
    default:break;
    }
    log_row();
}

/* ---- CSV ---- */
static void write_log(void)
{
    char path[20]="ML/CAMF0000.CSV";
    uint32_t v;int i,k;
    static const char hx[]="0123456789ABCDEF";
    if(!log_setting||row_n<=0)return;
    if(!log_serial)log_serial=(t_now&0xFFFFu);else log_serial++;
    v=log_serial;
    for(i=0;i<4;i++){path[10-i]=hx[v&15u];v>>=4;}
    output_handle=FIO_CreateFile(path);
    if(output_handle<=0){row_n=0;row_head=0;return;}
    txt("# CAMF camcorder AF C3" CAM_CSV_TAG ". Command units are NOT encoder counts. fv = YUV preview sharpness (raw+wide).\n");
    txt("# state 1 base,2 watch,3 climb,4 brake,5 return,6 settle,7 verify,8 cool. rel_bp = fvs vs reference in basis points.\n");
    txt("# result 0 accepted,1 already at peak,2 no gain (went home),3 no hill,4 gate/image,5 timeout,6 motor reject,7 paused by half-shutter\n");
    txt("# SUMMARY,search,");num((uint32_t)search_no);
    txt(",result,");snum(result);
    txt(",origin,");snum(origin);txt(",peak_pos,");snum(peak_pos);txt(",target,");snum(target);
    txt(",final_pos,");snum(cur_pos);txt(",comp_units,");snum(comp_used);
    txt(",fv0,");num(fv0);txt(",best_fv,");num(best_fv);txt(",fin_fv,");num(fin_fv);txt(",ref_fv,");num(ref_fv);
    txt(",reversed,");snum(reversed);txt(",cmds,");snum(cmds);txt(",ms,");num(t_now-search_t0);
    txt(",noise_bp,");snum(nz_bp);txt(",trigger_bp,");snum(trig_bp());
    txt(",speed,");snum(speed_setting);txt(",sens,");snum(sens_setting);txt(",range,");snum(range_units());
    txt(",comp_setting,");snum(comp_setting);txt(",pauses,");snum(pauses);txt(",profile,");snum(prof?(prof_near?2:1):0);if(prof){txt(",prof_focal,");snum(prof->focal);txt(",prof_backlash_x10,");snum(prof->back10);}txt(",frame_ms,");snum(fp_ms);txt("\n");
    txt("ms,state,pos,eff,fv,fvs,vq8,cmd,valid,rel_bp\n");
    for(i=0;i<row_n;i++)
    {
        struct row *r;
        k=row_head+i;if(k>=ROWS)k-=ROWS;
        r=&rows[k];
        num(r->ms);comma();iout(r->st);iout(r->pos);iout(r->eff);uout(r->fv);uout(r->fvs);
        iout(r->vq);iout(r->cmd);iout(r->valid);snum((int)r->rel-10000);ch('\n');
    }
    flush();FIO_CloseFile(output_handle);output_handle=0;
    row_n=0;row_head=0;
}

/* ---- task, menu, module glue ---- */
static void worker(void *unused)
{
    uint32_t last=vs_seq;
    (void)unused;
    while(!worker_exit)
    {
        uint32_t t0=get_ms_clock();
        if(!af_on){if(state!=ST_OFF)camf_step();msleep(60);last=vs_seq;continue;}
        while(vs_seq==last&&!worker_exit){if((int)(get_ms_clock()-t0)>120)break;msleep(1);}
        if(vs_seq==last){msleep(20);continue;}
        last=vs_seq;
        worker_busy=1;powersave_prolong();camf_step();worker_busy=0;
    }
}
static struct menu_entry menu[] = {
    {.name="CAMF Camcorder AF",.priv=&af_on,.max=1,
     .choices=CHOICES("OFF","ON"),
     .help="Continuous glide-style contrast AF like an old camcorder. " CAM_SERVO_MUST,
     .help2="Pauses while the shutter is held half-way (V17C half-shutter AF). Log ML/CAMFxxxx.CSV."},
    {.name="CAMF Refocus Now",.priv=&now_request,.max=1,
     .choices=CHOICES("OFF","REFOCUS"),
     .help="Start a glide search immediately (also happens by itself when sharpness drops)."},
    {.name="CAMF Glide Speed",.priv=&speed_setting,.max=3,
     .choices=CHOICES("CINEMATIC","SLOW","MEDIUM","FAST"),
     .help="Focus travel speed in units/second: about 6 / 10 / 16 / 26 (never more than 1 unit per frame)."},
    {.name="CAMF Sensitivity",.priv=&sens_setting,.max=2,
     .choices=CHOICES("LOW 20%","MEDIUM 12%","HIGH 7%"),
     .help="How far sharpness must fall, and stay down while the shot is calm, before it refocuses."},
    {.name="CAMF Range",.priv=&range_setting,.max=2,
     .choices=CHOICES("40 UNITS","80 UNITS","160 UNITS"),
     .help="Farthest the glide may travel from where it started, each way."},
    {.name="CAMF Backlash Comp",.priv=&comp_setting,.max=3,
     .choices=CHOICES("OFF","2 UNITS","4 UNITS","AUTO (CAMCAL)"),
     .help="Glide past the peak and return so the lens arrives from the same side each time.",
     .help2="AUTO: from the backlash CAMCAL measured for this lens (ML/LPxxxx.TXT); 2 units without a profile."},
    {.name="CAMF Focus Region",.priv=&focus_region,.max=1,
     .choices=CHOICES("CENTRE 55%","BALANCED 25%"),
     .help="Weight the centre target or the whole detailed area."},
    {.name="CAMF Log",.priv=&log_setting,.max=1,
     .choices=CHOICES("OFF","ON"),
     .help="Write ML/CAMFxxxx.CSV after every search (about 60 KB)."},
};
static unsigned int focus_init(void)
{
    if(is_camera(CAM_MODEL,CAM_FW))
    {
        now_request=0;worker_exit=worker_busy=0;log_serial=0;state=ST_OFF;
        menu_add("Focus",menu,8);
        task_create("camf",29,16384,worker,0);
    }
    return 0;
}
static unsigned int focus_deinit(void)
{
    worker_exit=1;af_on=0;now_request=0;
    { int n; for(n=0;n<120 && worker_busy;n++)msleep(50); }
    msleep(150);
    if(worker_busy)return 1;
    menu_remove("Focus",menu,8);
    return 0;
}
MODULE_INFO_START()
  MODULE_INIT(focus_init)
  MODULE_DEINIT(focus_deinit)
  MODULE_LONGNAME("CAMF Camcorder AF")
MODULE_INFO_END()
MODULE_CBRS_START()
  MODULE_CBR(CBR_VSYNC, on_vsync, 0)
MODULE_CBRS_END()
MODULE_CONFIGS_START()
  MODULE_CONFIG(af_on)
  MODULE_CONFIG(speed_setting)
  MODULE_CONFIG(sens_setting)
  MODULE_CONFIG(range_setting)
  MODULE_CONFIG(comp_setting)
  MODULE_CONFIG(focus_region)
  MODULE_CONFIG(log_setting)
MODULE_CONFIGS_END()
MODULE_STRINGS_START()
  MODULE_STRING("Name","CAMF Camcorder AF")
  MODULE_STRING("Author","experimental")
  MODULE_STRING("License","GPL")
  MODULE_STRING("Summary","Continuous glide-style contrast autofocus like a 90s/2000s camcorder")
  MODULE_STRING("Description","Watches sharpness, glides focus to the new peak with soft start/stop, verifies, never leaves focus worse than it found it.")
MODULE_STRINGS_END()
