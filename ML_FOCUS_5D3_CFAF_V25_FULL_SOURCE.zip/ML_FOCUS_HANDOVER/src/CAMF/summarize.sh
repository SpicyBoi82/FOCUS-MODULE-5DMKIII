#!/bin/sh
awk '/^==/{h=$0;next}/^start/{n++; hn[h]++; e=$4; if(e>2){bad++;hb[h]++} if($6=="-1")nc++; c+=$6; tr+=$8; rv+=$10; if($12>m)m=$12; if($10>mr)mr=$10} END{print "runs",n,"err>2:",bad,"noconv",nc,"avg conv ms",c/n,"avg travel",tr/n,"avg rev",rv/n,"max rev",mr,"max units/4fr",m; for(k in hb)print "  bad in",k,hb[k]}' "$1"
