/* Host simulation of the CAMF state machine.
 *   gcc -O2 -w -I SDK_COMPAT SIM_CAMF.c -o sim_camf && ./sim_camf
 * Model (assumptions, NOT measurements of a real lens): focus motor executes one queued unit per MOTOR_MS
 * (queue depth 3, further commands rejected), backlash = first N units after a reversal move nothing,
 * the preview image shows the lens position LAT frames ago, sharpness = Lorentzian blur model on a checkerboard,
 * per-frame noise. Proves control logic only; NOT camera evidence. */
#define UNIT_TEST
#include "CAMF.c"
#define SIMCARD_LOG_MODE "a"
#include "../common/SIM_CARD.h"
#include "../common/REPLAY.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static uint8_t imagebuf[720*480*2];
static struct vram_info_probe mock={imagebuf,720,1440,480};
static uint32_t clk=1000,nrng=12345;
int lv=1; struct lens_info_probe lens_info={0};
static int phys=0,tfocus=0,lens_cmds=0,limit_lo=-300,limit_hi=300,backlash=0,slack=0,lastdir=0,cmdsum=0;
static int pan_on=0,noise_pct=0,width=8,qn=0,q[8],MOTOR_MS=22,LAT=1,FPMS=33,rejects=0;
static int rnd(void){nrng=nrng*1664525u+1013904223u;return (int)((nrng>>16)&0x7fff);}
static void regenerate(int p){
    int x,y,blur=absi(p-tfocus),contrast;
    contrast=6+(144*width*width)/(width*width+blur*blur);
    if(rp_n)contrast=6+144*replay_frac1000(p-tfocus)/1000;   /* real curve from a camera log */
    if(noise_pct){int r=rnd()%2001-1000;contrast+=contrast*noise_pct*r/100000;}
    if(pan_on){int r=rnd()%1001-500;contrast+=contrast*r/1000;}
    if(contrast<6)contrast=6;
    for(y=100;y<380;y++)for(x=150;x<570;x++){int sign=((x/7+y/9)&1)?1:-1;int v=120+sign*contrast/2;imagebuf[y*1440+x*2+1]=(uint8_t)v;}
}
int is_camera(const char*m,const char*f){return 1;}
int is_movie_mode(void){return 1;} uint32_t get_ms_clock(void){return clk;}
void msleep(int ms){clk+=(uint32_t)ms;}
int task_create(const char*a,int b,int c,void(*d)(void*),void*e){return 1;}
void menu_add(const char*a,struct menu_entry*b,int c){}
void menu_remove(const char*a,struct menu_entry*b,int c){}
void powersave_prolong(void){}
int is_manual_focus(void){return 0;} int is_continuous_af(void){return 0;}
static uint32_t hs_on=0,hs_off=0;static int hs_fix=0;   /* half-press window (clock ms); hs_fix: V17C sets focus */
int get_halfshutter_pressed(void){return hs_on&&clk>=hs_on&&clk<hs_off;}
static int cmds_while_held=0;
int get_halfshutter_pressed(void);
int lens_focus(int a,int b,int c,int d){
    if(a!=1||(b!=1&&b!=-1))return 0;
    if(get_halfshutter_pressed())cmds_while_held++;
    if(qn>=3){rejects++;return 0;}
    if(cmdsum+b<limit_lo||cmdsum+b>limit_hi)return 0;
    cmdsum+=b;q[qn++]=b;lens_cmds++;return 1;}
struct vram_info_probe *get_yuv422_vram(void){return &mock;}
static void motor_advance(int ms,int *mrem){
    *mrem+=ms;
    while(*mrem>=MOTOR_MS && qn){
        int mv=q[0],dir=mv>0?1:-1,i;
        for(i=1;i<qn;i++)q[i-1]=q[i]; qn--;
        if(backlash){ if(dir!=lastdir){slack=backlash;lastdir=dir;} if(slack>0){slack--;} else phys+=mv; } else {phys+=mv;lastdir=dir;}
        *mrem-=MOTOR_MS;
    }
    if(!qn&&*mrem>MOTOR_MS)*mrem=MOTOR_MS;
}
#define NF 2400
static int physh[NF+8];static int pan_from=0,pan_len=0;
/* one scenario: returns via printed line */
static int tf_preset=0,tf_use=0;
static void scenario(int start_off,int shift_at,int shift_by,int secs,int verbose){
    int f,mrem=0,rev=0,lastv=0,first_cool=-1,nframes=secs*1000/FPMS,maxwin=0,trig_after=0,wake_frames=0,i;
    int win[64];long travel=0;int lastphys;for(i=0;i<64;i++)win[i]=start_off;
    tfocus=tf_use?tf_preset:0;phys=start_off;if(!lastdir)lastdir=1;physh[0]=phys;lastphys=phys;
    af_on=1;lens_info.lens_exists=1;
    for(f=1;f<=nframes&&f<NF;f++){
        int pimg;
        clk+=FPMS;motor_advance(FPMS,&mrem);
        physh[f]=phys;
        if(shift_at&&f==shift_at*1000/FPMS)tfocus=shift_by;
        if(hs_fix&&hs_off&&clk>=hs_off-500&&clk<hs_off-500+FPMS){phys=tfocus;}   /* "V17C" lands on focus */
        if(pan_from&&f==pan_from*1000/FPMS)pan_on=1;
        if(pan_from&&f==(pan_from+pan_len)*1000/FPMS)pan_on=0;
        pimg=physh[f>LAT?f-LAT:0];
        regenerate(pimg);
        vs_ms=clk;vs_seq++;
        camf_step();
        if(state==ST_COOL&&first_cool<0)first_cool=f;
        { int v=phys-lastphys; if(v){ if(lastv&&sgn(v)!=sgn(lastv))rev++; lastv=v; travel+=absi(v);} lastphys=phys; }
        { int w; win[f&63]=phys; if(f>=4){ w=absi(phys-win[(f-4)&63]); if(w>maxwin)maxwin=w; } }
        if(verbose&&(f%3==0))printf("%5d ms st%d phys %4d tf %4d pos %4d v %3d fvs %7u res %d\n",f*FPMS,state,phys,tfocus,cur_pos,v_q8,fvs,result);
    }
    printf("start %4d  err %3d  conv %5dms  travel %4ld  reversals %d  max4fr %2d  cmds %d  rej %d  res %d  searches %d\n",
        start_off,absi(phys-tfocus),first_cool<0?-1:first_cool*FPMS,travel,rev,maxwin,lens_cmds,rejects,result,search_no);
}
static void runfork(int w,int bl,int nz,int st,int shift_at,int shift_by,int secs,int sp,int cp,int fpms,int sens,int pf,int pl){
    pid_t p;fflush(stdout);p=fork();
    if(p==0){width=w;backlash=bl;noise_pct=nz;speed_setting=sp;sens_setting=sens;range_setting=2;comp_setting=cp;FPMS=fpms;pan_from=pf;pan_len=pl;
        scenario(st,shift_at,shift_by,secs,0);fflush(stdout);_exit(0);}
    waitpid(p,0,0);
}
static void scenario_tf(int st,int tf){tf_preset=tf;tf_use=1;scenario(st,0,0,20,0);}
int main(int argc,char**argv){
    int starts[]={-60,-30,-15,-8,-4,0,4,8,15,30,60};int si,w,bl,nz,sp;
    int verbose=argc>1&&!strcmp(argv[1],"v");
    if(argc>1&&!strcmp(argv[1],"halfpress")){
        /* C3: half-shutter held 3 s while "V17C" refocuses on a moved subject. CAMF must issue no commands while
           held, must not start a search right after release, and must end in focus. Case 2 presses DURING a CAMF
           search (cut short, result 7). Case 3: half-press with no refocus (Canon AF off, nothing moves). */
        struct{int shift_at,shift_by,on_ms,len,fix;}C[]={{0,0,8000,3000,0},{6,25,6600,3000,1},{0,0,1500,3000,1},{10,-30,10200,2500,1}};
        int i;
        for(i=0;i<4;i++){pid_t p;fflush(stdout);p=fork();
            if(p==0){width=8;backlash=2;noise_pct=2;speed_setting=2;sens_setting=1;range_setting=2;comp_setting=1;
                hs_on=1000+C[i].on_ms;hs_off=hs_on+C[i].len;hs_fix=C[i].fix;
                printf("[halfpress %d at %d ms for %d ms, shift %d at %d s] ",i+1,C[i].on_ms,C[i].len,C[i].shift_by,C[i].shift_at);
                scenario(0,C[i].shift_at,C[i].shift_by,20,0);printf("      pauses %d  commands_while_held %d\n",pauses,cmds_while_held);fflush(stdout);_exit(0);}
            waitpid(p,0,0);}
        return 0;}
    if(argc>2&&!strcmp(argv[1],"replay")){
        /* real curve (tests/curves). Backlash Comp setting from COMPSET (default 3 = AUTO: profile, else 2 units) */
        int st[9]={-30,-15,-8,-4,0,4,8,15,30},cp=getenv("COMPSET")?atoi(getenv("COMPSET")):3;
        replay_load(argv[2]);
        printf("== replay %s comp setting %d ==\n",strrchr(argv[2],'/')?strrchr(argv[2],'/')+1:argv[2],cp);
        for(si=0;si<9;si++){pid_t p;int s=st[si];fflush(stdout);
            if(rp_lo>-100000&&s<rp_lo+2)s=rp_lo+2;if(rp_hi<100000&&s>rp_hi-2)s=rp_hi-2;
            p=fork();
            if(p==0){width=8;backlash=rp_backlash>=0?rp_backlash:2;noise_pct=rp_noise>=0?rp_noise:2;speed_setting=2;sens_setting=1;range_setting=2;comp_setting=cp;
                if(rp_lo>-100000)limit_lo=rp_lo;if(rp_hi<100000)limit_hi=rp_hi;lens_info.focal_len=rp_focal;lens_info.lens_id=rp_lensid;
                scenario(s,0,0,14,0);fflush(stdout);_exit(0);}
            waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"stable")){int nzs[4]={0,2,4,6};for(nz=0;nz<4;nz++){printf("== STABLE 60s noise %d%% (searches should be 1) ==\n",nzs[nz]);for(w=0;w<3;w++){int ws[3]={4,8,14};runfork(ws[w],2,nzs[nz],0,0,0,60,2,1,33,1,0,0);}}return 0;}
    if(argc>1&&!strcmp(argv[1],"shift")){int sh[8]={-40,-25,-10,-5,5,10,25,40};int ws[3]={4,8,14};for(w=0;w<3;w++){printf("== SHIFT width %d bl 2 noise 2%% ==\n",ws[w]);for(si=0;si<8;si++)runfork(ws[w],2,2,0,10,sh[si],30,2,1,33,1,0,0);}return 0;}
    if(argc>1&&!strcmp(argv[1],"fps")){int f[5]={17,20,33,40,42};for(si=0;si<5;si++){printf("== FPS frame %d ms ==\n",f[si]);for(sp=0;sp<4;sp++){printf(" speed %d: ",sp);runfork(8,2,2,25,0,0,20,sp,1,f[si],1,0,0);}}return 0;}
    if(argc>1&&!strcmp(argv[1],"limit")){
        int lims[3][3]={{-12,12,0},{-12,12,25},{-12,12,-25}};int k,st[3]={-10,0,8};
        for(k=0;k<3;k++)for(si=0;si<3;si++){pid_t p;fflush(stdout);p=fork();if(p==0){width=8;backlash=2;noise_pct=2;speed_setting=2;sens_setting=1;range_setting=2;comp_setting=1;limit_lo=lims[k][0];limit_hi=lims[k][1];
            printf("limits %d..%d focus at %d: ",limit_lo,limit_hi,lims[k][2]);fflush(stdout);
            tfocus=lims[k][2];scenario_tf(st[si],lims[k][2]);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"pan")){printf("== PAN: contrast jitters +/-50%% for 3 s while in focus ==\n");for(sp=0;sp<3;sp++){runfork(8,2,2,0,0,0,40,2,1,33,sp,12,3);}return 0;}
    if(argc>1&&!strcmp(argv[1],"comp")){int bl2[4]={0,1,2,3};for(bl=0;bl<4;bl++)for(sp=0;sp<3;sp++){printf("== backlash %d comp setting %d (0/2/4 units) ==\n",bl2[bl],sp);for(si=0;si<11;si++){int starts[]={-30,-15,-8,-4,0,4,8,15,30,22,-22};runfork(8,bl2[bl],2,starts[si],0,0,14,2,sp,33,1,0,0);}}return 0;}
    if(verbose){int st=argc>2?atoi(argv[2]):25;width=argc>3?atoi(argv[3]):8;backlash=argc>4?atoi(argv[4]):2;noise_pct=argc>5?atoi(argv[5]):2;speed_setting=argc>6?atoi(argv[6]):2;sens_setting=1;range_setting=2;comp_setting=argc>7?atoi(argv[7]):1;if(argc>8)lastdir=atoi(argv[8]);scenario(st,0,0,12,1);return 0;}
    for(w=0;w<3;w++)for(bl=0;bl<3;bl++)for(nz=0;nz<3;nz++){
        static const int ws[3]={4,8,14},bls[3]={0,2,3},nzs[3]={0,2,4};
        printf("== width %d backlash %d noise %d%% ==\n",ws[w],bls[bl],nzs[nz]);
        for(si=0;si<11;si++){
            pid_t p;fflush(stdout);p=fork();
            if(p==0){
                width=ws[w];backlash=bls[bl];noise_pct=nzs[nz];speed_setting=2;sens_setting=1;range_setting=2;comp_setting=1;
                scenario(starts[si],0,0,14,0);fflush(stdout);_exit(0);
            }
            waitpid(p,0,0);
        }
    }
    return 0;
}
