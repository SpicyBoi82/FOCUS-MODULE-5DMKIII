/* Host simulator for CFAF v2.  gcc -O2 -w -DCAM_5D3 -I SDK_COMPAT SIM_CFAF.c -o sim_cfaf && ./sim_cfaf
 * Plant from the CFAF camera logs (CFAF1550-1885, 18 Oct 2026), position in +/-2 steps:
 *   - a +/-2 moves 1 step (+/-JIT pct, - side ASYM pct more): it reverses cleanly in the logs;
 *   - a +/-1 moves R steps (tiny), a +/-3 moves K3 steps (~6 at 81 mm) with 30 pct scatter, ~1 s;
 *   - waited +/-2 takes T2 ms (50 mm ~80, 81 mm ~220); backlash B steps; end stops refuse; BUSY after a +/-3;
 *   - Canon value every 42 ms showing the lens LAG ms earlier; Lorentzian hill, half-width W steps, on a floor;
 *     noise NZ pct; the first SETTLE frames after the start are junk (Canon re-meters on the half-press).
 * Score: sharpness = hill height at the final position (floor removed); >= 0.95 good. */
#define UNIT_TEST
#include "CFAF.c"
#include "../common/SIM_CARD.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int lv=1; struct lens_info_probe lens_info={0};
static uint32_t clk=1000,nseed=1,tjunk=0;
static double phys=0,lo=-60,hi=60,B=0.2,slack=0;static int pdir=0;
static double K3JIT=0.3,ASYM3=15,W=5,R=0.3,K3=6,JIT=3,ASYM=3,FLOOR=6000,AMP=30000,NZ=1;static int CH=0,DRIFT=0,ENDOK=0,COAST=0,BUSY=150,LAG=40,T2=150,T3=1000,SETTLE=5,BIG=1;
static uint32_t last_big=0;
#define HN 8192
static uint32_t ht[HN];static double hp[HN];static int hn=0;
static void hist(void){if(hn<HN){ht[hn]=clk;hp[hn]=phys;hn++;}else{memmove(ht,ht+1,(HN-1)*4);memmove(hp,hp+1,(HN-1)*sizeof(double));ht[HN-1]=clk;hp[HN-1]=phys;}}
static double phys_at(uint32_t t){int i;for(i=hn-1;i>=0;i--)if(ht[i]<=t)return hp[i];return hn?hp[0]:phys;}
static double hill(double x){return W*W/(W*W+x*x);}
static uint32_t rng(void){nseed=nseed*1664525u+1013904223u;return nseed>>8;}
static double urand(void){return (double)(rng()&0xFFFF)/65535.0;}
static uint32_t last_fi=0xFFFFFFFFu;
static void emit(void){
    uint32_t fi=clk/42,b[8]={0};double v,v1=FLOOR*2.5*(1.0+0.03*(urand()*2-1));
    if(fi==last_fi)return;last_fi=fi;
    v=FLOOR+AMP*hill(phys_at(fi*42-LAG));
    v*=1.0+NZ/100.0*(urand()*2-1)*1.7;
    if(DRIFT){double g=1.0+DRIFT/100.0*((double)(clk%6000)/3000.0-1.0);v*=g;v1*=g;}
    if(clk<tjunk){double f=0.08+0.9*(1.0-(double)(tjunk-clk)/(SETTLE*42.0));v*=f;v1*=f;}
    b[1]=(uint32_t)v1;b[2]=(uint32_t)(v/2);b[3]=(uint32_t)(v-v/2);b[7]=65195;
    if(CH)
    {   /* two channels measuring different detail: v2 a narrower hill, v3 wider, each with its own noise */
        double x=phys_at(fi*42-LAG),g=v/(FLOOR+AMP*hill(x)),h2,h3,W0=W;
        W=W0*0.7;h2=hill(x);W=W0*1.4;h3=hill(x);W=W0;
        b[2]=(uint32_t)(g*(FLOOR*0.5+AMP*0.5*h2)*(1.0+NZ/100.0*(urand()*2-1)*1.7));
        b[3]=(uint32_t)(g*(FLOOR*0.5+AMP*0.5*h3)*(1.0+NZ/100.0*(urand()*2-1)*1.7));
    }
    cfd_handler(PROP_LV_FOCUS_DATA,0,b,32);
}
int is_camera(const char*m,const char*f){return 1;}
void powersave_prolong(void){}
int is_movie_mode(void){return 1;} uint32_t get_ms_clock(void){return clk;}
void msleep(int ms){clk+=(uint32_t)ms;emit();}
int task_create(const char*a,int b,int c,void(*d)(void*),void*e){return 1;}
void menu_add(const char*a,struct menu_entry*b,int c){} void menu_remove(const char*a,struct menu_entry*b,int c){}
int is_manual_focus(void){return 0;} int is_continuous_af(void){return 0;}
void NotifyBox(int t,const char*f,...){}
int get_halfshutter_pressed(void){return 0;} int gui_menu_shown(void){return 0;} void bmp_draw_rect(int c,int x,int y,int w,int h){} void (*prc_hook)(unsigned,const void*,unsigned)=0; void prop_request_change(unsigned p,const void*a,unsigned l){if(prc_hook)prc_hook(p,a,l);} int bmp_printf(uint32_t f,int x,int y,const char*fmt,...){return 0;} void assign_af_button_to_star_button(void){} void restore_af_button_assignment(void){}
static void unit_move(double du){
    int dir=du>0?1:-1;double a=du>0?du:-du;
    if(dir!=pdir){slack=B;pdir=dir;}
    if(slack>0){double t=a<slack?a:slack;slack-=t;a-=t;}
    if(dir>0){phys+=a;if(phys>hi)phys=hi;}else{phys-=a;if(phys<lo)phys=lo;}
}
int lens_focus(int n,int b,int wait,int d){
    int mag=b<0?-b:b,dir=b>0?1:-1;double u;uint32_t t;
    if(n!=1||mag<1||mag>3)return 0;
    if(BUSY&&last_big&&clk-last_big<(uint32_t)BUSY){clk+=8;return 0;}
    if((dir>0&&phys>=hi)||(dir<0&&phys<=lo)){if(mag==3&&ENDOK){clk+=200;return 1;}clk+=10;return 0;}
    if(mag==1){u=R;t=45;}
    else if(mag==2){u=1+JIT/100.0*(urand()*2-1);if(dir<0)u*=1+ASYM/100.0;t=T2;}
    else{u=K3*(1+K3JIT*(urand()*2-1));if(dir<0)u*=1+ASYM3/100.0;if(COAST)u*=1+0.6*urand();t=T3;}
    {int i,ns=(int)(t/42)+1;double step=dir*u/ns;for(i=0;i<ns;i++){unit_move(step);clk+=t/ns;hist();emit();}}
    clk+=(uint32_t)d;
    if(mag==3)last_big=clk;
    emit();
    return 1;
}
struct prof{const char*name;int focal;double W,floor,amp;int T2;double K3;int T3;};
static struct prof P[]={
 {"81mm W=4 ",81,4,6000,26000,220,6.5,1000},
 {"85mm W=3 ",85,3,6000,24000,250,7,1100},
 {"35mm W=6 ",35,6,12000,100000,120,6,600},
 {"50mm W=13",50,13,8000,60000,80,7,330},
 {"wide W=20",24,20,10000,60000,80,7,330},
 {"85real W=2",85,2.2,2350,10150,230,7,1100},
 {"50stm W=35",50,35,3000,30000,90,7,330}};
#define NP (int)(sizeof P/sizeof P[0])
int main(int argc,char**argv){
    int pi,si,seed,verbose=getenv("VERBOSE")!=0;long G=0,GT=0,GFA=0;
    if(getenv("BUSY"))BUSY=atoi(getenv("BUSY"));
    if(getenv("LAG"))LAG=atoi(getenv("LAG"));
    if(getenv("NZ"))NZ=atof(getenv("NZ"));
    if(getenv("B"))B=atof(getenv("B"));
    if(getenv("JIT"))JIT=atof(getenv("JIT"));
    if(getenv("ASYM"))ASYM=atof(getenv("ASYM"));
    if(getenv("SETTLE"))SETTLE=atoi(getenv("SETTLE"));
    if(getenv("BIG"))BIG=atoi(getenv("BIG"));
    if(getenv("K3JIT"))K3JIT=atof(getenv("K3JIT"));
    if(getenv("COAST"))COAST=atoi(getenv("COAST"));
    if(getenv("ENDOK"))ENDOK=atoi(getenv("ENDOK"));
    if(getenv("DRIFT"))DRIFT=atoi(getenv("DRIFT"));
    if(getenv("CH"))CH=atoi(getenv("CH"));
    if(getenv("ASYM3"))ASYM3=atof(getenv("ASYM3"));
    for(pi=0;pi<NP;pi++){
        long tot=0,good=0,fails=0,falseacc=0,msum=0,mmax=0;double shs=0;
        double starts[11]={0,0.3,-0.3,1.0,-1.0,2.5,-2.5,5.0,-5.0,10,-10};
        if(P[pi].W<2.5){double s2[11]={0,0.5,-0.5,2,-2,5,-5,8,-8,12,-12};memcpy(starts,s2,sizeof s2);}
        for(si=0;si<11;si++)for(seed=0;seed<4;seed++){
            int fd[2];pipe(fd);fflush(stdout);
            if(fork()==0){
                double sh,x0;uint32_t tstart;int ok;
                close(fd[0]);
                W=P[pi].W;FLOOR=P[pi].floor;AMP=P[pi].amp;T2=P[pi].T2;K3=P[pi].K3;T3=P[pi].T3;big_setting=BIG;
                lens_info.focal_len=P[pi].focal;lens_info.lens_exists=1;lens_info.lens_id=36912;
                nseed=1+seed*977+si*131+pi*7919;clk=1000+seed*13;
                x0=starts[si]*W;if(x0>hi-2)x0=hi-2-seed;if(x0<lo+2)x0=lo+2+seed;
                phys=x0;slack=0;pdir=0;hn=0;last_big=0;hist();
                cfd_v1s16=0;{int i;for(i=0;i<12;i++)msleep(42);}
                norm_setting=getenv("NORM")?atoi(getenv("NORM")):1;
                tjunk=clk+SETTLE*42;
                if(getenv("TRACK")){c_run=1;cont_setting=1;cbig_setting=getenv("CBIG")?atoi(getenv("CBIG")):0;c_ref=(uint32_t)((FLOOR+AMP)*4096.0/(FLOOR*2.5));c_first=(seed&1)?1:-1;tjunk=0;}
                if(getenv("CAL")){cal_loaded=1;cal_n=1;cal_lens[0]=36912;cal_fb[0]=cal_bucket(lens_info.focal_len);cal_w4[0]=(int)(W*4*0.65);cal_cnt[0]=5;if(getenv("CAL3")){cal_k3x4[0]=(int)(K3*4);cal_rev[0]=0;}}
                if(getenv("AGREE"))agree_setting=atoi(getenv("AGREE"));glide_setting=getenv("GLIDE")?atoi(getenv("GLIDE")):1;if(getenv("GLAG"))g_lag_def=atoi(getenv("GLAG"));if(getenv("GBK"))g_bk_def=atoi(getenv("GBK"));if(getenv("GUNIT"))g_unit_def=atoi(getenv("GUNIT"));qglide_setting=getenv("QGLIDE")?atoi(getenv("QGLIDE")):1;if(getenv("FAR2"))g_far2=atoi(getenv("FAR2"));
                tstart=clk;speed_setting=getenv("SPEED")?atoi(getenv("SPEED")):1;
                if(getenv("CALIB")){int r=calibrate_lens();
                    printf("%s start=%5.1f seed=%d CAL r=%d hw=%.2f(true %.2f) k3=%.2f(true %.1f) reterr=%d back=%.2f(true %.1f) k1=%.2f(true %.2f) t2=%d t3=%d nz=%d ms=%u\n",
                      P[pi].name,x0,seed,r,c_res[0]/4.0,0.62*W,c_res[1]/4.0,K3,(int)c_res[2],c_res[3]/4.0,B,c_res[4]/4.0,R,(int)c_res[5],(int)c_res[6],(int)c_res[7],clk-tstart);
                    {char b[96];int n=snprintf(b,sizeof b,"%d %f %u\n",r==0,hill(phys),clk-tstart);write(fd[1],b,n);}
                    fflush(stdout);_exit(0);}
                ok=af_run()==0;
                sh=hill(phys);
                if(verbose)printf("%s start=%6.1f seed=%d -> stop=%d sharp=%.3f err=%.1f ms=%u cmds=%d\n",P[pi].name,x0,seed,stop_code,sh,phys,clk-tstart,cmds);
                if(getenv("LOGOUT")&&getenv("ONE")&&atoi(getenv("ONE"))==pi*1000+si*10+seed)save_log();
                {char b[96];int n=snprintf(b,sizeof b,"%d %f %u\n",ok,sh,clk-tstart);write(fd[1],b,n);}
                fflush(stdout);_exit(0);}
            close(fd[1]);
            {char b[96]={0};int n=read(fd[0],b,95),ok;float sh;unsigned ms;close(fd[0]);wait(0);
             if(n>0&&sscanf(b,"%d %f %u",&ok,&sh,&ms)==3){tot++;if(!ok)fails++;if(sh>=0.95)good++;if(ok&&sh<0.8)falseacc++;shs+=sh;msum+=ms;if(ms>mmax)mmax=ms;}}
        }
        G+=good;GT+=tot;GFA+=falseacc;
        printf("%s | runs %3ld  sharp>=95%%: %5.1f%%  mean sharp %.3f  fail %3ld  false-accept %2ld | mean %5ld ms (max %5ld)\n",
            P[pi].name,tot,100.0*good/tot,shs/tot,fails,falseacc,msum/tot,mmax);
    }
    printf("ALL | %.1f%% sharp>=95%%, false accepts %ld\n",100.0*G/GT,GFA);
    return 0;
}
