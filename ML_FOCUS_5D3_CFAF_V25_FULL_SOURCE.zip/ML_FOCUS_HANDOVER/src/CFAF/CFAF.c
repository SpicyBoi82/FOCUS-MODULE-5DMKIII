/*
 * CFAF - "Canon Focus AF" for the Canon 5D Mark III 1.1.3 (Magic Lantern module API 8).  v25, 30 Oct 2026.
 *
 * Written from scratch. It uses ONLY Canon's own LiveView focus measurement (PROP_LV_FOCUS_DATA, the value
 * behind Magic Zoom's green border; v2+v3, one value per LiveView frame). No YUV preview metric.
 *
 * What the 5D3 + EF-S 18-135 logs taught (FZ7C... runs, 18 Oct 2026):
 *   - Canon's value reacts about one frame after a move (the preview needs ~4) and its hill is clean;
 *   - a +/-1 command moves very little: the hill is ~30-40 units wide each side at 35 mm and wider at 81 mm,
 *     with a flat top (about 1 pct per 2 units near the top at 81 mm);
 *   - a +/-3 command moves a lot (~22 units at 35 mm, ~50+ at 81 mm) and is not exactly reversible;
 *   - the lens sometimes refuses a command right after a big move (not an end stop).
 *
 * v2 (after the first CFAF camera logs, CFAF1550-1885): only +/-2 steps, counted, so every position can be
 * found again exactly (+/-2 reverses cleanly; +/-1 is too small on a 50 mm; +/-3 does not reverse).
 *   0. wait until Canon's numbers have settled after the half-press (v1 showed it jumps for a few frames);
 *   1. walk + reading after every step until the value clearly drops below the best;
 *      if + never rose, walk - the same way;
 *   2. both sides flat = far out of focus: v3 jumps with +/-3 (menu CFAF Big Jumps) toward the side whose
 *      readings were a little higher until the value rises and falls again, then counts +/-2 again from there
 *      (Big Jumps OFF: long +/-2 strides);
 *   3. refine: read both neighbours of the best position, move while a neighbour is better, go there;
 *      on a narrow top (a neighbour < 90 pct, 85 mm) a few +/-1 steps toward the better neighbour;
 *   4. refused command: wait 150 ms and try once more; only a second refusal is an end stop. Canon changing
 *      its scale (its own AF / exposure state) or stopping sending data ends the run (logged).
 *
 * Trigger: hold the shutter half-way (default) or menu "CFAF Run". Letting go stops at once.
 * Log: ML/CFAFxxxx.CSV. Not camera tested.
 */
#define MODULE
#define MODULE_NAME cfaf
#include <stdint.h>
#include "module.h"
#include "dryos.h"
#include "menu.h"
#include "config.h"

/* ===================== CAMERA PROFILE ===================== */
#if defined(CAM_5D3)
#define CAM_MODEL "5D3"
#define CAM_FW    "1.1.3"
#else   /* the 70D never sends Canon focus data: CFAF loads there but only says so */
#define CAM_MODEL "70D"
#define CAM_FW    "1.1.2"
#endif
/* ========================================================== */

extern int is_camera(const char*,const char*);
extern int get_halfshutter_pressed(void);
extern void assign_af_button_to_star_button(void);
extern void restore_af_button_assignment(void);
extern int is_movie_mode(void);
extern uint32_t get_ms_clock(void);
extern void msleep(int);
extern int task_create(const char*,int,int,void(*)(void*),void*);
extern int FIO_CreateFile(const char*);
extern int FIO_WriteFile(int,const void*,unsigned);
extern int FIO_CloseFile(int);
extern void menu_remove(const char*,struct menu_entry*,int);
extern int lv;
extern int is_manual_focus(void);
extern int is_continuous_af(void);
extern int lens_focus(int,int,int,int);
extern void powersave_prolong(void);
static void keep_awake(void){static uint32_t t=0;if((int)(get_ms_clock()-t)>2000){t=get_ms_clock();powersave_prolong();}}   /* v19: LCD / LiveView must not go off mid-run */
extern void NotifyBox(int timeout,const char *fmt,...);
struct lens_info_probe
{
    void *token;
    char name[32];
    unsigned focal_len;
    unsigned focus_dist;
    unsigned IS;
    unsigned aperture;
    int ae;
    unsigned shutter;
    unsigned iso;
    unsigned iso_auto;
    unsigned iso_analog_raw;
    int iso_digital_ev;
    unsigned iso_equiv_raw;
    unsigned hyperfocal;
    unsigned dof_near;
    unsigned dof_far;
    unsigned job_state;
    unsigned wb_mode;
    unsigned kelvin;
    unsigned WBGain_R;
    unsigned WBGain_G;
    unsigned WBGain_B;
    int8_t wbs_gm;
    int8_t wbs_ba;
    unsigned picstyle;
    uint8_t raw_aperture;
    uint8_t raw_shutter;
    uint8_t raw_iso;
    uint8_t raw_iso_auto;
    uint8_t raw_picstyle;
    uint8_t raw_aperture_min;
    uint8_t raw_aperture_max;
    int flash_ae;
    uint16_t lens_id;
    uint16_t dof_flags;
    int dof_diffraction_blur;
    int focus_pos;
    uint8_t lens_exists;
};
extern struct lens_info_probe lens_info;

/* ---------------- Canon focus data (runs in PropMgrTask: copy and return) ---------------- */
#define PROP_LV_FOCUS_DATA 0x80050026u
static volatile uint32_t cfd_seq=0,cfd_ms=0;
static volatile uint32_t cfd_v[8];
static volatile int cfd_v1s16=0;
static int cv_sh=512,s_sh=512;           /* v2's share of v2+v3 x1024: latest frame / last reading */      /* v1 smoothed over ~8 frames, x16 */
static void cfd_handler(unsigned int property,void *priv,uint32_t *buf,unsigned int len)
{
    unsigned n=len>>2,i;
    (void)property;(void)priv;
    if(!buf)return;
    if(n>8)n=8;
    for(i=0;i<n;i++)cfd_v[i]=buf[i];
    if(n>1&&buf[1]<(1u<<20))
    {   int x=(int)(buf[1]<<4);
        int d=x-cfd_v1s16;
        if(!cfd_v1s16||d>cfd_v1s16/8||-d>cfd_v1s16/8)cfd_v1s16=x;   /* a real change (> 12 pct): follow at once */
        else cfd_v1s16+=d>>3;                                        /* frame jitter (~3 pct): smooth */
    }
    cfd_ms=get_ms_clock();cfd_seq++;
}
static module_prophandler_t cfd_block={"PROP_LV_FOCUS_DATA",cfd_handler,PROP_LV_FOCUS_DATA,0};
/* Canon's LiveView AF box (ML shoot.c): [0],[1] = sensor W,H; [2],[3] = top-left x,y; [4],[5] = box w,h.
   Canon's focus value (v2+v3) is measured inside this box. */
#define PROP_LV_AFFRAME 0x80050007u
static volatile int aff[6];static volatile uint32_t aff_seq=0;static int aff_raw[32];
static void aff_handler(unsigned int property,void *priv,uint32_t *buf,unsigned int len)
{
    unsigned n=len>>2,i;
    (void)property;(void)priv;
    if(!buf||n<6)return;
    if(n>32)n=32;
    for(i=0;i<n;i++)aff_raw[i]=(int)buf[i];
    for(i=0;i<6;i++)aff[i]=(int)buf[i];
    aff_seq++;
}
static module_prophandler_t aff_block={"PROP_LV_AFFRAME",aff_handler,PROP_LV_AFFRAME,0};


/* ---------------- settings ---------------- */
static CONFIG_INT("cfaf.run",run_request,0);
static CONFIG_INT("cfaf.cal",cal_request,0);
static CONFIG_INT("cfaf.probe",probe_request,0);
static CONFIG_INT("cfaf.stop",cancel_request,0);
static CONFIG_INT("cfaf.trigger",trigger_setting,1);   /* half-shutter: 0 nothing, 1 quick AF (hold), 2 toggle continuous */
static CONFIG_INT("cfaf.speed",speed_setting,1);       /* 0 fast (1 value per reading), 1 normal, 2 careful (2 values) */
static CONFIG_INT("cfaf.log",log_setting,1);
static CONFIG_INT("cfaf.big",big_setting,1);
static CONFIG_INT("cfaf.norm",norm_setting,1);
static CONFIG_INT("cfaf.cont",cont_setting,0);          /* continuous AF: watch Canon's sharpness, refocus when it drops */
static CONFIG_INT("cfaf.csens",csens_setting,1);        /* 0 low (drop 35 pct, 1 s), 1 medium (25, 0.6 s), 2 high (15, 0.3 s) */
static CONFIG_INT("cfaf.calways",calways_setting,0);    /* continuous: 0 refocus when sharpness drops, 1 keep checking all the time */
static CONFIG_INT("cfaf.cbig",cbig_setting,0);
static CONFIG_INT("cfaf.agree",agree_setting,1);
static CONFIG_INT("cfaf.afpoint",afpoint_setting,0);    /* 0 Canon (joystick), 1 centre, 2-9 grid points */
static CONFIG_INT("cfaf.afsize",afsize_setting,0);      /* 0 Canon size, 1 small (1/2), 2 large (2x) - experimental */
static CONFIG_INT("cfaf.afbtn",afbtn_setting,1);       /* AF-point button toggles continuous: 0 off, 1 on, 2 learn */
static CONFIG_INT("cfaf.afcode",afcode,-1);           /* learned raw button code of the AF-point button */
static CONFIG_INT("cfaf.fbtn",fbtn_setting,0);          /* v21 focus button: 0 off, 1 on (tap = focus once), 2 learn */
static CONFIG_INT("cfaf.fcode",fcode,-1);
static CONFIG_INT("cfaf.btncodes",btncodes_setting,0);
static CONFIG_INT("cfaf.handoff",handoff_setting,1);    /* v25 half-press let go: 0 nothing, 1 direction (default), 2 direction + go back */  /* v21 show the code of every button pressed */
static CONFIG_INT("cfaf.afshow",afshow_setting,1);      /* draw the AF box */        /* "sharper" only when Canon's v2 AND v3 both agree */          /* continuous may use big +/-3 jumps: 0 no (default), 1 yes */
static CONFIG_INT("cfaf.glide",glide_setting,1);
static CONFIG_INT("cfaf.qglide",qglide_setting,1);     /* v19: quick AF motion: 0 steps, 1 glide */       /* continuous motion: 0 steps (v14), 1 glide */
static CONFIG_INT("cfaf.cspeed",cspeed_setting,1);      /* continuous refocus speed: 0 slow (cinematic), 1 medium, 2 fast */
static CONFIG_INT("cfaf.ind",ind_setting,1);            /* on-screen indicator */         /* 1: sharpness = (v2+v3) / smoothed v1 (cancels exposure drift) */           /* 1: far out of focus, find the hill with big +/-3 jumps */
static volatile int worker_exit=0,worker_busy=0,hs_run=0,hs_released=0,c_run=0,c_first=1,c_kick=1;
static uint32_t c_ref;

/* ---------------- small maths (no libgcc) ---------------- */
static int absi(int v){return v<0?-v:v;}
static uint32_t divu(uint32_t n,uint32_t d)
{
    uint32_t q=0,b=1;
    if(!d)return 0;
    while(d<n&&!(d&0x80000000u)){d<<=1;b<<=1;}
    while(b){if(n>=d){n-=d;q|=b;}d>>=1;b>>=1;}
    return q;
}
static int divs(int a,int b)   /* rounded */
{
    int neg=0;uint32_t ua,ub;
    if(!b)return 0;
    if(a<0){a=-a;neg^=1;}
    if(b<0){b=-b;neg^=1;}
    ua=(uint32_t)a;ub=(uint32_t)b;
    ua=divu(ua*2u+ub,ub*2u);
    return neg?-(int)ua:(int)ua;
}
/* a is above b by more than bp basis points (values < 2^24, so *10000 needs 64 bit: split instead) */
static int above(uint32_t a,uint32_t b,int bp){return a>b+divu(b,10000u)*(uint32_t)bp+divu((b%10000u)*(uint32_t)bp,10000u);}
static int below(uint32_t a,uint32_t b,int bp){uint32_t d=divu(b,10000u)*(uint32_t)bp+divu((b%10000u)*(uint32_t)bp,10000u);return d<b&&a<b-d;}

/* ---------------- state + log ---------------- */
enum { S_OK=0,S_GATE=1,S_LOST=2,S_SCALE=3,S_NOHILL=4,S_BUDGET=5,S_NODATA=6 };
enum { E_START=1,E_BASE=2,E_SAMPLE=3,E_MOVE=4,E_RETRY=5,E_WALL=6,E_LEVEL=7,E_TARGET=8,E_FINAL=9,E_ABORT=10,
       E_FLAT=11,E_PROBE=12,E_BACK=13,E_EXTEND=14 };
static const char *stop_text[]={"accepted","stopped (half-shutter let go / camera state)","Canon data stopped","Canon scale changed",
                                "no focus hill found","time / step limit","no Canon focus data (70D, or not in LiveView)"};
#define TR_MAX 1500
struct row { uint32_t ms,val; int32_t fpos; int16_t units,cmds,sh; uint16_t v1; uint8_t ev,lvl; int8_t dir,arg; };
static struct row tr[TR_MAX];static int tr_n=0,tr_drop=0;
static uint32_t t0,v_start,v_final,v_best,v_min,ref_v1,used_seq,seq0;
static int stop_code,lvl,units,cmds,tol_bp,last_dir,refusals,walls,levels_used;
static int g_noscale=0;
static int g_lag=100,g_bk=1,g_k21=4,g_nz=0,g_from_probe=0,g_lag_def=50,g_bk_def=1,g_unit=1,g_unit_def=1,g_k3u=0,g_span=0,g_far2=25;   /* GLIDE parameters (see GLIDE) */

static void note(int ev,int dir,int arg,uint32_t val)
{
    struct row *r;
    if(tr_n>=TR_MAX){tr_drop++;return;}
    r=&tr[tr_n++];
    r->ms=get_ms_clock()-t0;r->ev=(uint8_t)ev;r->lvl=(uint8_t)lvl;r->dir=(int8_t)dir;r->arg=(int8_t)(arg>127?127:(arg<-127?-127:arg));
    r->val=val;r->units=(int16_t)units;r->cmds=(int16_t)cmds;r->fpos=lens_info.focus_pos;r->v1=(uint16_t)(cfd_v[1]>65535u?65535u:cfd_v[1]);r->sh=(int16_t)(ev==E_SAMPLE?s_sh:cv_sh);
}
static uint32_t hs_rel_ms=0;
static int gate_why=0;static volatile int tap_rel=0,tap_run=0;   /* tap_run: 1 focus button, 2 half-shutter TAP AF */   /* v18: why the last run was stopped (logged as stopped_by) */
static int gate(void)
{
    int g=0;
    if(!lv)g|=1;
    if(!is_movie_mode())g|=2;
    if(is_manual_focus())g|=4;
    if(is_continuous_af())g|=8;
    if(!lens_info.lens_exists)g|=16;
    if(lens_info.job_state)g|=32;
    if(cancel_request||worker_exit)g|=64;
    if(hs_run&&!get_halfshutter_pressed()){if(!hs_released)hs_rel_ms=get_ms_clock();hs_released=1;g|=128;}  /* quick AF let go */
    if(c_run&&get_halfshutter_pressed())g|=256;                     /* continuous: half-press takes over */
    if(tap_run==2){if(!get_halfshutter_pressed())tap_rel=1;else if(tap_rel)g|=1024;}   /* TAP AF: pressed again = stop */
    if(c_run&&!cont_setting)g|=512;                                 /* continuous switched off */
    if(g)gate_why=g;
    return g;
}
extern int bmp_printf(uint32_t fontspec,int x,int y,const char *fmt,...);
extern int gui_menu_shown(void);
#define COLOR_WHITE 0x01u
#define COLOR_BLACK 0x02u
#define COLOR_GREEN 0x06u
#define COLOR_YELLOW 0x0Fu
#define IND_FONT(fg) ((2u<<16)|(COLOR_BLACK<<8)|(fg))
static uint32_t ind_ms=0;static int ind_shown=0;
/* small status text top-left: "CAF" green = continuous watching, "CAF>" yellow = continuous refocusing,
   "AF>" yellow = quick AF running. Redrawn every 0.3 s (LiveView overlays get wiped). */
extern void bmp_draw_rect(int color,int x0,int y0,int w,int h);
static int box_x=-1,box_y,box_w,box_h,box_col;static uint32_t ok_until=0;
/* Canon's AF box drawn on the 720x480 overlay: white idle, yellow while focusing, green after a good focus */
static void draw_box(int force)
{
    int W=aff[0],H=aff[1],x,y,w,h,col;
    if(!afshow_setting||!lv||gui_menu_shown()||W<=0||H<=0||aff[4]<=0)
    {   if(box_x>=0&&afshow_setting==0){bmp_draw_rect(0,box_x,box_y,box_w,box_h);bmp_draw_rect(0,box_x+1,box_y+1,box_w-2,box_h-2);box_x=-1;}
        return;
    }
    x=(int)divu((uint32_t)aff[2]*720u,(uint32_t)W);y=(int)divu((uint32_t)aff[3]*480u,(uint32_t)H);
    w=(int)divu((uint32_t)aff[4]*720u,(uint32_t)W);h=(int)divu((uint32_t)aff[5]*480u,(uint32_t)H);
    if(w<8||h<8||x<0||y<0||x+w>720||y+h>480)return;
    col=worker_busy?(int)COLOR_YELLOW:((int)(get_ms_clock()-ok_until)<0?(int)COLOR_GREEN:(int)COLOR_WHITE);
    if(box_x>=0&&(box_x!=x||box_y!=y||box_w!=w||box_h!=h))
    {   bmp_draw_rect(0,box_x,box_y,box_w,box_h);bmp_draw_rect(0,box_x+1,box_y+1,box_w-2,box_h-2);}
    if(force||box_x!=x||box_y!=y||box_w!=w||box_h!=h||box_col!=col||1)
    {   bmp_draw_rect(col,x,y,w,h);bmp_draw_rect(col,x+1,y+1,w-2,h-2);}
    box_x=x;box_y=y;box_w=w;box_h=h;box_col=col;
}
static void draw_status(int force)
{
    uint32_t now=get_ms_clock();int busy=worker_busy;
    if(!lv||gui_menu_shown())return;
    if(!force&&(int)(now-ind_ms)<300)return;
    ind_ms=now;
    draw_box(force);
    if(!ind_setting)return;
    if(busy&&!c_run){bmp_printf(IND_FONT(COLOR_YELLOW),8,60," AF> ");ind_shown=1;}
    else if(busy&&c_run){bmp_printf(IND_FONT(COLOR_YELLOW),8,60,"CAF> ");ind_shown=1;}
    else if(cont_setting){bmp_printf(IND_FONT(COLOR_GREEN),8,60," CAF ");ind_shown=1;}
    else if(ind_shown){bmp_printf(IND_FONT(COLOR_WHITE),8,60,"     ");ind_shown=0;}
}
static int fail(int code){if(!stop_code)stop_code=code;note(E_ABORT,0,code,0);return -1;}

/* ---------------- Canon readings ---------------- */
/* next NEW Canon value (v2+v3); -1 abort */
static uint32_t cur_value(void);
/* Canon sends two focus numbers, v2 and v3. CFAF's value is their sum; cv_sh = v2's share x1024 of the latest
   frame, s_sh = averaged over a reading. With "CFAF Two Channels" a position only counts as sharper when
   neither channel got worse (FZ16Z12G's rule for its two measures): a false peak from noise or a moving
   subject usually lifts one and not the other. */
static uint32_t chan(uint32_t v,int sh){if(sh<0)sh=0;if(sh>1024)sh=1024;return ((v>>4)*(uint32_t)sh)>>6;}
static int agree(uint32_t v,int sh,uint32_t rv,int rsh,int bp_)
{
    if(!agree_setting)return 1;
    if(sh<100||sh>924||rsh<100||rsh>924)return 1;           /* one channel ~empty: nothing to compare */
    return !below(chan(v,sh),chan(rv,rsh),bp_)&&!below(chan(v,1024-sh),chan(rv,1024-rsh),bp_);
}
static int cnext(uint32_t *v)
{
    uint32_t t=get_ms_clock(),v1;
    for(;;)
    {
        while(cfd_seq==used_seq)
        {
            if(gate())return fail(S_GATE);
            if((int)(get_ms_clock()-t)>300)return fail(S_LOST);
            msleep(5);
        }
        used_seq=cfd_seq;
        /* Canon sometimes sends all-zero frames (CFAF0B79/7A, 0CB2-B4: v1 = 0, value 0): skip them */
        if(cfd_v[1]&&(cfd_v[2]|cfd_v[3]))break;
    }
    v1=cfd_v[1];
    /* Canon switched its scale. With Exposure Comp the value is divided by v1, so only a > 3x change counts
       (CAMGAIN changes v1 by 30-60 pct within a run: 6A60, 0B7F, 0B81, 7C84, 7C86 stopped for that) */
    if(ref_v1&&(norm_setting?(v1*3u<ref_v1||v1>ref_v1*3u):(v1*10u<ref_v1*7u||v1*7u>ref_v1*10u)))
    {   if(!g_noscale)return fail(S_SCALE);
        ref_v1=v1;note(E_RETRY,0,99,v1);              /* v22 GLIDE: carry on with the new scale (06C6, 06CA-06CE) */
    }
    *v=cur_value();
    {   uint32_t a=cfd_v[2],b=cfd_v[3],t=a+b;                 /* this frame's share of v2 in v2+v3, x1024 */
        cv_sh=t?(int)divu((a>(1u<<21)?a>>10:a)*1024u,(a>(1u<<21)?t>>10:t)):512;
    }
    return 0;
}
/* Canon sharpness of the latest frame (normalised by smoothed v1 when Exposure Comp is ON) */
static uint32_t cur_value(void)
{
    uint32_t vv=cfd_v[2]+cfd_v[3],*v=&vv;
    if(*v>(1u<<24))*v=1u<<24;
    if(norm_setting)
    {   /* (v2+v3)*4096 / v1 (smoothed). CFAF3D9D: the value fell 10 pct while v1 fell 13 pct and the lens was far
           out of focus - CFAF read it as "both sides lower = in focus". The ratio stayed flat (0.205-0.218).
           In focus the ratio was 1.5-7 in all logs, far out 0.2-0.9. */
        uint32_t d=(uint32_t)(cfd_v1s16>>4),q,r;
        if(d<256)d=256;if(d>(1u<<19))d=1u<<19;
        q=divu(*v,d);r=*v-q*d;
        *v=(q<<12)+divu(r<<12,d);
        if(*v>(1u<<24))*v=1u<<24;
    }
    return vv;
}
/* after a move: skip 2 new frames (Canon shows a move ~1 frame late), then average n new values */
static int sample(uint32_t *v,int n)
{
    uint32_t s=0,x;int i,ssh=0;
    used_seq=cfd_seq;
    for(i=0;i<2;i++)if(cnext(&x)<0)return -1;
    for(i=0;i<n;i++){if(cnext(&x)<0)return -1;s+=x;ssh+=cv_sh;}
    *v=divu(s,(uint32_t)n);s_sh=n>1?(ssh+(n>>1))/n:ssh;
    if(*v>v_best)v_best=*v;
    if(!v_min||*v<v_min)v_min=*v;
    note(E_SAMPLE,last_dir,n,*v);
    draw_status(0);
    return 0;
}
static int nvals(void){return speed_setting>=2?2:1;}

/* ---------------- moves ---------------- */
#define CMD_MAX 260
#define TIME_MAX 20000
static int cal_busy=0;                  /* lens calibration running: it may take ~60 s and ~600 commands */
/* one waited command of size mag (1..3) in dir. 1 moved, 0 end stop (refused twice), -1 abort */
/* v20 end stop by the encoder. The Sigma 18-300 does NOT refuse at its end stops: probe CFP32745 sent ~1000
   +/-2 commands into the - end (lens position stuck at 6897, every command "accepted") and after that the lens's
   position report stayed frozen. Now: if the position report was alive in this run and has not changed for
   >= 6 commands and >= 0.9 s (it updates every ~0.25 s while the lens moves), that is an end stop. */
static int ew_pos=0,ew_alive=0,ew_n=0;static uint32_t ew_t=0;
static void ew_reset(void){ew_pos=lens_info.focus_pos;ew_alive=0;ew_n=0;ew_t=get_ms_clock();}
static int ew_end(void)
{
    uint32_t now=get_ms_clock();
    if(lens_info.focus_pos!=ew_pos){ew_pos=lens_info.focus_pos;ew_alive=1;ew_n=0;ew_t=now;return 0;}
    ew_n++;
    return ew_alive&&ew_n>=6&&(int)(now-ew_t)>=900;
}
static int cmd(int mag,int dir)
{
    int rc;
    keep_awake();
    if(gate())return fail(S_GATE);
    if(cmds>=(cal_busy?1000:CMD_MAX)||(int)(get_ms_clock()-t0)>(cal_busy?120000:TIME_MAX))return fail(S_BUDGET);
    rc=lens_focus(1,dir*mag,1,(last_dir&&dir!=last_dir)?60:10);
    if(!rc&&cal_busy){note(E_WALL,dir,mag,0);refusals++;return 0;}   /* v16 calibration: an end stop, no 2nd "soft limit" */
    if(!rc)
    {   /* the lens refuses some commands right after a big move: wait, then once more */
        msleep(150);
        if(gate())return fail(S_GATE);
        rc=lens_focus(1,dir*mag,1,10);
        note(rc?E_RETRY:E_WALL,dir,mag,0);
        if(!rc){refusals++;return 0;}
    }
    if(ew_end()){note(E_WALL,dir,mag,1);refusals++;return 0;}            /* v20: encoder says end stop */
    cmds++;last_dir=dir;
    if(c_run&&mag==2&&cspeed_setting<2)msleep(cspeed_setting==0?300:120);   /* cinematic: slower focus travel */
    if(mag==2)units+=dir;
    note(E_MOVE,dir,mag,0);
    return 1;
}
/* k commands; returns how many moved (stops at an end stop), -1 abort */
static int cmdn(int mag,int dir,int k)
{
    int i,r;
    for(i=0;i<k;i++){r=cmd(mag,dir);if(r<0)return -1;if(!r){walls++;break;}}
    return i;
}

/* ---------------- v2 search: everything in +/-2 steps ----------------
   Camera logs (CFAF1550-1885): +/-2 steps come back to the same Canon value when reversed (31560 -> 31117
   after 2 back, 37143 -> 36817 after 6 back), +/-1 is too small to matter on a 50 mm (0.2 pct per step),
   +/-3 takes ~1 s at 81 mm and does not come back (17396 -> one back -> 6343). So: +/-2 only, counted. */
#define PO 160
static uint32_t pv[2*PO+1];      /* last Canon value read at +/-2 position p (index p+PO); 0 = not read */
static int p2,bp;                /* net +/-2 position; position of the best value */
static uint32_t bv;              /* best value read */
static int psh[2*PO+1],bsh=512;  /* v2 share at each position / at the best */
enum { W_DROP=1,W_FLAT=2,W_WALL=3 };
static int cal_k3r=0,cal_use3=0,cal_back=0,go_last=0;   /* from CFAF Calibrate Lens (see below) */
static int go2(int k,int dir)    /* move k +/-2 steps; returns how many moved, -1 abort */
{
    int m=0,r;
    /* backlash measured by the calibration: after a reversal the first cal_back steps do not move the focus */
    if(cal_back>0&&go_last&&dir!=go_last){r=cmdn(2,dir,cal_back);if(r<0)return -1;}
    go_last=dir;
    /* a lens whose +/-3 lands where it should (calibration: comes back to >= 85 pct) covers long distances in
       +/-3 jumps of cal_k3r steps each - much faster on lenses with tiny steps (50 mm STM) */
    if(cal_use3&&cal_k3r>=3&&!(c_run&&!cbig_setting))
        while(k-m>=cal_k3r){r=cmd(3,dir);if(r<0)return -1;if(!r)break;m+=cal_k3r;}
    r=cmdn(2,dir,k-m);if(r<0)return -1;m+=r;
    p2+=dir*m;return m;
}
static int goto2(int t){int d=t-p2;if(!d)return 0;return go2(d>0?d:-d,d>0?1:-1)<0?-1:0;}
static int read_here(uint32_t *v)
{
    if(sample(v,nvals())<0)return -1;
    if(p2>-PO&&p2<PO){pv[p2+PO]=*v;psh[p2+PO]=s_sh;}
    if(*v>bv&&(!bv||agree(*v,s_sh,bv,bsh,tol_bp))){bv=*v;bp=p2;bsh=s_sh;}
    return 0;
}
/* walk one way reading after every stride of s +/-2 steps.
   Rising (> the last rise + tol): keep going; a slow rise lengthens the stride (up to smax).
   Clearly below the best (2 tol): W_DROP.  flatmax strides without a rise: W_DROP if below the best by tol, else W_FLAT. */
/* ---------------- learned lens calibration (ML/CFAFCAL.TXT) ----------------
   After every good focus CFAF measures how wide the sharp zone is in +/-2 steps for that lens and focal length
   (half-width down to 70 pct) and keeps it on the card. 23 Oct logs: the 50 mm STM climbed 24-44 single +/-2
   steps (+7-15 pct each) for 4-7 s and was let go before the top (5105, 5106) - its +/-2 is tiny next to its
   sharp zone; the 18-135 at 85 mm is the opposite (zone ~2 steps). Knowing the width it picks the stride.
   Line format: lens_id,focal_bucket,halfwidth_x4,count  (delete the file to forget). */
extern int FIO_OpenFile(const char*,unsigned);
extern int FIO_ReadFile(int,void*,unsigned);
#define CAL_N 48
static int cal_lens[CAL_N],cal_fb[CAL_N],cal_w4[CAL_N],cal_cnt[CAL_N];static int cal_n=0,cal_loaded=0;
/* measured by CFAF Calibrate Lens (0 = not measured): +/-3 size x4 in +/-2 steps, +/-3 come-back pct, backlash x4,
   +/-1 size x4, ms per +/-2 and +/-3 command, noise bp. cal_rev = +/-3 there-and-back error x4 (0 = perfect) */
static int cal_k3x4[CAL_N],cal_rev[CAL_N],cal_b4[CAL_N],cal_k1x4[CAL_N],cal_t2[CAL_N],cal_t3[CAL_N],cal_nz[CAL_N];
static int cal_hw=0;                     /* this run: half-width in +/-2 steps, 0 = not learned yet */
static char cal_buf[3072];
static int cal_bucket(int f){if(f<=0)return 0;if(f<30)return f;return (int)divu((uint32_t)f,5u)*5;}
static void cal_load(void)
{
    int h,len,i,st,k,v[11],c;
    cal_loaded=1;cal_n=0;
    h=FIO_OpenFile("ML/CFAFCAL.TXT",010000u);
    if(h==0||h==-1)return;
    len=FIO_ReadFile(h,cal_buf,sizeof(cal_buf)-1);FIO_CloseFile(h);
    if(len<=0)return;if(len>(int)sizeof(cal_buf)-1)len=(int)sizeof(cal_buf)-1;cal_buf[len]=0;
    for(st=0,i=0;i<=len&&cal_n<CAL_N;i++)
    {
        if(i<len&&cal_buf[i]!='\n')continue;
        for(k=0,c=st;k<11;)
        {   int val=0,dig=0;
            while(c<i&&cal_buf[c]>='0'&&cal_buf[c]<='9'){val=val*10+(cal_buf[c]-'0');c++;dig=1;if(val>1000000)val=1000000;}
            if(!dig)break;
            v[k++]=val;
            if(c<i&&cal_buf[c]==',')c++;else break;
        }
        if(k>=4&&v[2]>0)
        {   int j=cal_n++;
            cal_lens[j]=v[0];cal_fb[j]=v[1];cal_w4[j]=v[2];cal_cnt[j]=v[3];
            cal_k3x4[j]=k>4?v[4]:0;cal_rev[j]=k>5?v[5]:0;cal_b4[j]=k>6?v[6]:0;cal_k1x4[j]=k>7?v[7]:0;
            cal_t2[j]=k>8?v[8]:0;cal_t3[j]=k>9?v[9]:0;cal_nz[j]=k>10?v[10]:0;
        }
        st=i+1;
    }
}
static int cal_find(void){int i,fb=cal_bucket(lens_info.focal_len);for(i=0;i<cal_n;i++)if(cal_lens[i]==(int)lens_info.lens_id&&cal_fb[i]==fb)return i;return -1;}
static int cal_find_near(void)
{   int i,b=-1,bd=16,fb=cal_bucket(lens_info.focal_len),d;
    for(i=0;i<cal_n;i++)if(cal_lens[i]==(int)lens_info.lens_id){d=cal_fb[i]-fb;if(d<0)d=-d;if(d<bd){bd=d;b=i;}}
    return b;
}
static void cal_put(char **o,int n){char b[12];int i=0;if(n<0)n=0;if(!n)b[i++]='0';while(n&&i<11){b[i++]=(char)('0'+(int)(n-(int)divu((uint32_t)n,10u)*10));n=(int)divu((uint32_t)n,10u);}while(i)*(*o)++=b[--i];}
static void cal_save(void)
{
    int h,i;char *o=cal_buf;
    for(i=0;i<cal_n&&o<cal_buf+sizeof(cal_buf)-96;i++)
    {   cal_put(&o,cal_lens[i]);*o++=',';cal_put(&o,cal_fb[i]);*o++=',';cal_put(&o,cal_w4[i]);*o++=',';cal_put(&o,cal_cnt[i]);
        *o++=',';cal_put(&o,cal_k3x4[i]);*o++=',';cal_put(&o,cal_rev[i]);*o++=',';cal_put(&o,cal_b4[i]);*o++=',';cal_put(&o,cal_k1x4[i]);
        *o++=',';cal_put(&o,cal_t2[i]);*o++=',';cal_put(&o,cal_t3[i]);*o++=',';cal_put(&o,cal_nz[i]);*o++='\n';}
#ifndef UNIT_TEST
    h=FIO_CreateFile("ML/CFAFCAL.TXT");
    if(h>0){FIO_WriteFile(h,cal_buf,(unsigned)(o-cal_buf));FIO_CloseFile(h);}
#else
    (void)h;
#endif
}
static void cal_learn(int w4)
{
    int i=cal_find();
    if(i<0)
    {   if(cal_n>=CAL_N)return;
        i=cal_n++;cal_lens[i]=(int)lens_info.lens_id;cal_fb[i]=cal_bucket(lens_info.focal_len);cal_w4[i]=w4;cal_cnt[i]=1;
        cal_k3x4[i]=cal_rev[i]=cal_b4[i]=cal_k1x4[i]=cal_t2[i]=cal_t3[i]=cal_nz[i]=0;
    }
    else{cal_w4[i]=(cal_w4[i]*3+w4+2)>>2;if(cal_cnt[i]<9999)cal_cnt[i]++;}
    cal_save();
}

static int walk(int dir,int s,int smax,int flatmax,int *s_out)
{
    uint32_t v,sig=bv,gain,pgain=0;int flat=0,m,su,sigsh=bsh,rose=0;
    int gentle=c_run&&!cbig_setting;     /* v13: continuous, C-Big Jumps OFF: single +/-2 steps only, stop at the first drop */
    lvl=2;levels_used|=4;
    if(gentle){smax=cal_hw>=8?(cal_hw>>2):2;if(s>smax)s=smax;}   /* strides up to 1/4 of a learned wide zone, else 2 */
    for(;;)
    {
        *s_out=s;su=s;
        m=go2(s,dir);if(m<0)return -1;
        if(m==0){note(E_WALL,dir,0,0);return W_WALL;}
        if(read_here(&v)<0)return -1;
        if(above(v,sig,tol_bp)&&agree(v,s_sh,sig,sigsh,tol_bp))
        {
            /* longer strides while rising; when the rise per step halves the top is near: shorter */
            gain=divu(v-sig,(uint32_t)su);
            if(pgain&&gain*2u<pgain)s=(s+1)>>1;else if(s<smax)s++;
            {   /* clearly on the hill (2x the floor): shorter strides, less overshoot - how short depends on the
                   sharp zone: learned width / 2, or, not learned yet, keep going while each step adds < 8 pct */
                int cap=cal_hw>=4?(cal_hw>>1):2;
                if(!cal_hw&&gain*12u<sig)cap=smax;
                if(v_min&&(v>>1)>v_min&&s>cap)s=cap;
            }
            /* gentle: longer than 1 only while the rise is slow (< 8 pct a step = far below a wide top) */
            if(gentle&&(cal_hw<8&&gain*12u>=sig))s=1;
            pgain=gain;sig=v;sigsh=s_sh;flat=0;rose=1;
        }
        else
        {
            if(below(v,bv,2*tol_bp)){note(E_LEVEL,dir,1,v);return W_DROP;}
            if(gentle&&rose&&below(v,sig,tol_bp)){note(E_LEVEL,dir,3,v);return W_DROP;}   /* past the top: stop now */
            if(++flat>=flatmax){int r=below(v,bv,tol_bp)?W_DROP:W_FLAT;note(r==W_DROP?E_LEVEL:E_FLAT,dir,2,v);return r;}
        }
        if(m<su){note(E_WALL,dir,1,0);return W_WALL;}
    }
}
static uint32_t pval(int p){return (p>-PO&&p<PO)?pv[p+PO]:0;}
/* read position p (go there); 0 ok */
static int read_at(int p,uint32_t *v){if(goto2(p)<0)return -1;return read_here(v);}
/* settle on the best +/-2 position: make sure both neighbours were read at stride 1, move the centre while a
   neighbour is better, then go to the centre (from the side that leaves the least travel) and read it again */
static int refine(uint32_t *cur)
{
    uint32_t v,a,b,c;int n,ctr,k;
    lvl=1;levels_used|=2;
    /* neighbour spacing: 1 step, or a quarter of a learned wide zone (on the 50 mm STM 1 step changes < 1 pct) */
    k=cal_hw>=8?(cal_hw>>2):1;
    if(cal_hw>=8)
    {   /* wide learned zone: the nearest readings either side of the best are both lower - fit a parabola
           through the three and go straight to its top (saves walking k-step neighbours back and forth) */
        int dl=0,dr=0,q,off;
        for(q=1;q<=2*cal_hw&&bp-q>-PO;q++)if(pv[bp-q+PO]){dl=q;break;}
        for(q=1;q<=2*cal_hw&&bp+q<PO;q++)if(pv[bp+q+PO]){dr=q;break;}
        if(dl&&dr&&pv[bp-dl+PO]<bv&&pv[bp+dr+PO]<bv)
        {
            int y0=(int)(bv>>6),yl=(int)(pv[bp-dl+PO]>>6)-y0,yr=(int)(pv[bp+dr+PO]>>6)-y0;
            int num=yr*dl*dl-yl*dr*dr,den=2*(yl*dr+yr*dl);
            off=den?-divs(num,den):0;
            if(off<-dl)off=-dl;if(off>dr)off=dr;
            note(E_TARGET,0,bp+off,bv);
            if(read_at(bp+off,&v)<0)return -1;
            if(!below(v,bv,300)){*cur=v;return 0;}               /* within 3 pct of the best: done */
        }
    }
    for(n=0;n<12;n++)
    {
        ctr=bp;
        /* read the neighbours, nearest one first */
        if(p2>=ctr){ if(!pval(ctr+k)&&read_at(ctr+k,&v)<0)return -1; if(!pval(ctr-k)&&read_at(ctr-k,&v)<0)return -1; }
        else       { if(!pval(ctr-k)&&read_at(ctr-k,&v)<0)return -1; if(!pval(ctr+k)&&read_at(ctr+k,&v)<0)return -1; }
        if(bp==ctr)break;               /* a neighbour beat the centre: move the centre there */
    }
    note(E_TARGET,0,bp,bv);
    if(read_at(bp,&v)<0)return -1;
    if(below(v,bv,3*tol_bp))
    {   /* lower than when it was read: read again, then come in once more from the side */
        if(read_here(&v)<0)return -1;
        if(below(v,bv,3*tol_bp)){if(goto2(bp-1)<0)return -1;if(read_at(bp,&v)<0)return -1;}
    }
    a=pval(bp-1);b=pval(bp);c=pval(bp+1);
    if(a&&c&&b&&!(c_run&&cspeed_setting<2)&&(below(a,b,1000)||below(c,b,1000)))
    {   /* narrow top (a neighbour < 90 pct, 85 mm logs: 83 pct): half a +/-2 step matters. Small +/-1 steps toward
           the better neighbour while it gets better, then back to the best of them. */
        int dir=c>a?1:-1,q=0,bq=0,i,r;uint32_t best=v,w;
        lvl=1;
        for(i=0;i<3;i++)
        {
            r=cmd(1,dir);if(r<0)return -1;if(!r)break;
            q+=dir;
            if(sample(&w,nvals())<0)return -1;
            if(w>best){best=w;bq=q;}
            else if(below(w,best,tol_bp)||(q-bq)*dir>=2)break;
        }
        note(E_TARGET,dir,bq,best);
        if(q!=bq){if(cmdn(1,q>bq?-1:1,q>bq?q-bq:bq-q)<0)return -1;if(sample(&v,nvals())<0)return -1;}
        else v=best;
    }
    *cur=v;
    return 0;
}
/* wait until Canon's numbers have settled after the half-press (Canon's own metering changes them for a few
   frames: CFAF1881/1882 started from 726 / 669 when the scene really read ~9000). 4 frames in a row with v1 within
   4 pct and the value within 10 pct, or 1.5 s. */
static uint32_t sbuf[4];
static int settle(void)
{
    uint32_t *a=sbuf,b[4],t=get_ms_clock(),x,lo,hi,l1,h1;int n=0,i;
    for(;;)
    {
        if(cnext(&x)<0)return -1;
        a[n&3]=x;b[n&3]=cfd_v[1];n++;
        if(n>=4)
        {
            lo=hi=a[0];l1=h1=b[0];
            for(i=1;i<4;i++){if(a[i]<lo)lo=a[i];if(a[i]>hi)hi=a[i];if(b[i]<l1)l1=b[i];if(b[i]>h1)h1=b[i];}
            if(!above(hi,lo,1000)&&!above(h1,l1,400))return 0;
        }
        if((int)(get_ms_clock()-t)>1500){note(E_FLAT,0,9,x);if(n<4)for(i=n;i<4;i++)a[i]=x;return 0;}
    }
}

/* both sides with +/-2 steps from position 0 (first side first). 1 = hill found (climbed, or dropped both ways),
   0 = flat on a side (*fa / *fb = how each side ended), -1 abort */
static int flatmax_first=2,far_mode=0;
static int two_side(int first,int smax,int *fa,int *fb)
{
    int r,r2=0,s,climbed;uint32_t base=pv[PO];
    {   /* a learned sharp zone: the first look steps half its width at once (in focus that drops ~10 pct: clear) */
        int s0=c_run?(cal_hw>=8?(cal_hw>>2):1):(cal_hw>=4?(cal_hw>>1):1),sm=smax;   /* continuous: smaller looks (less visible) */
        if(cal_hw>sm&&!c_run)sm=cal_hw>12?12:cal_hw;
        r=walk(first,s0,sm,flatmax_first,&s);if(r<0)return -1;
    }
    climbed=bp*first>0&&above(bv,base,tol_bp);
    if(climbed&&r==W_FLAT){r=walk(first,2,6,6,&s);if(r<0)return -1;}   /* rose, then flat: may be a slow slope - go on */
    *fa=r;*fb=0;
    if(climbed)return 1;
    if(goto2(0)<0)return -1;
    {   int s0=c_run?(cal_hw>=8?(cal_hw>>2):1):(cal_hw>=4?(cal_hw>>1):1),sm=smax;   /* continuous: smaller looks (less visible) */
        if(cal_hw>sm&&!c_run)sm=cal_hw>12?12:cal_hw;
        r2=walk(-first,s0,sm,flatmax_first,&s);if(r2<0)return -1;
    }
    climbed=bp*first<0&&above(bv,base,tol_bp);
    if(climbed&&r2==W_FLAT){r2=walk(-first,2,6,6,&s);if(r2<0)return -1;}
    *fb=r2;
    if(first<0){int t=*fa;*fa=*fb;*fb=t;}                     /* *fa = + side, *fb = - side */
    if(climbed)return 1;
    if((r==W_DROP||r==W_WALL)&&(r2==W_DROP||r2==W_WALL))
    {   if(!far_mode)return 1;                                   /* both ways down: the start is the top */
        *fa=*fb=W_FLAT;                                          /* far out: treat as flat, search */
    }
    return 0;
}
/* after +/-3 jumps the +/-2 positions are lost: start counting again here */
static int rebase(void)
{
    uint32_t v;int i;
    for(i=0;i<2*PO+1;i++)pv[i]=0;
    p2=0;bp=0;bv=0;
    return read_here(&v);
}
/* big +/-3 jumps one way (the 5D3 + 18-135 logs: one +/-3 = ~6 +/-2 steps, ~1 s at 81 mm, does not reverse
   exactly). B_PASSED: rose and then fell (or stopped rising) - the hill is behind us, within ~2 jumps.
   B_FELL: it only fell (clearly below the start, never rose): the start was on a wide top - jumped back.
   B_FLAT: nothing changed in maxj jumps. */
enum { B_PASSED=1,B_FELL=2,B_FLAT=3,B_NEAR=4 };
static uint32_t jbest,jfloor;     /* best and starting value of the big jumps */
static int seek_big(int dir,int maxj,int *jumps)
{
    uint32_t v,sig,start,t;int j,r,rose=0,flat=0,n,k,quick=0,dt,dtmax=0,moved=0;
    lvl=3;levels_used|=8;
    if(sample(&v,nvals())<0)return -1;
    sig=start=v;jbest=v;jfloor=v;
    for(j=0;j<maxj;)
    {
        n=1;                                                 /* one jump per reading: a narrow 85 mm zone spans only ~2 jumps */
        for(k=0;k<n;k++)
        {
            if(j||k)msleep(150);                             /* the lens refuses commands right after a +/-3 */
            t=get_ms_clock();
            r=cmd(3,dir);if(r<0)return -1;
            if(!r){note(E_WALL,dir,3,0);return rose?B_PASSED:B_FLAT;}
            (*jumps)++;j++;
            /* a +/-3 that "moves" a real distance takes 0.5-1.1 s at 85 mm; at the end of the range it returns in
               ~0.2-0.33 s and nothing changes (CFAF65AB: first jump 0.57 s, then 10 quick ones, value flat) = end stop */
            dt=(int)(get_ms_clock()-t);if(dt>dtmax)dtmax=dt;
            if(dt<200||(dtmax>=400&&dt*5<dtmax*3))quick++;else{quick=0;moved++;}   /* < 0.2 s or < 60 pct of the slowest */
        }
        if(sample(&v,nvals())<0)return -1;
        if(v>jbest)jbest=v;
        if(quick>=2&&!rose){note(E_WALL,dir,4,v);return B_FLAT;}
        if(above(v,jfloor,4000))
        {   /* clearly above the blurred floor (1.4x): the sharp zone starts here. Stop jumping (one more +/-3
               would jump over it: CFAFB132 2349 -> 6937 -> 2034) and walk on with +/-2 */
            note(E_LEVEL,dir,5,v);return B_NEAR;
        }
        if(above(v,sig,tol_bp)){rose=1;sig=v;flat=0;continue;}
        if(rose){if(below(v,sig,2*tol_bp)||++flat>=2){note(E_LEVEL,dir,3,v);return B_PASSED;}continue;}
        if(below(v,start,2*tol_bp))
        {   /* only ever lower than the start: the start was on a wide top - jump back there */
            note(E_LEVEL,dir,4,v);
            msleep(150);
            if(cmdn(3,-dir,moved>0?moved:1)<0)return -1;  /* back by the jumps that really moved (CFAF3D99) */
            return B_FELL;
        }
    }
    note(E_FLAT,dir,3,v);
    return rose?B_PASSED:B_FLAT;
}

/* after the jumps passed the sharp zone: walk back with +/-2 (stride 2) until the value is back to >= 55 pct of
   the way from the floor to the best jump reading. Camera logs CFAF65AC/65AD/65B1: the first +/-2 steps back can still read LOWER (the
   zone is a whole jump behind), so early drops are ignored here. Then the normal two-sided settle. 1 ok, 0 lost */
static int return_walk(int back)
{
    uint32_t v,want=jfloor+((jbest-jfloor)>>1);                 /* half way between the floor and the best jump */
    int n,d,dd;
    lvl=2;
    if(rebase()<0)return -1;
    for(dd=0;dd<2;dd++)
    {
        d=dd?-back:back;
        if(dd&&goto2(0)<0)return -1;
        for(n=0;n<(dd?8:16);n++)
        {
            int m=go2(2,d);if(m<0)return -1;
            if(read_here(&v)<0)return -1;
            if(v>=want){note(E_TARGET,d,9,v);return 1;}
            if(m<2)break;
        }
    }
    return 0;
}

/* ---------------- one AF run ---------------- */
static int glide_run(void);
static void gp_apply(void);
static int af_run(void)
{
    uint32_t v[5],cur,spread;int r,i,j,s,fa=0,fb=0;
    stop_code=0;gate_why=0;tr_n=tr_drop=0;units=cmds=0;ew_reset();last_dir=0;refusals=walls=0;levels_used=0;lvl=0;
    v_start=v_final=v_best=v_min=0;ref_v1=0;t0=get_ms_clock();seq0=cfd_seq;
    for(i=0;i<2*PO+1;i++)pv[i]=0;
    p2=0;bp=0;bv=0;
    note(E_START,0,0,0);
    if(!cal_loaded)cal_load();
    {   int ci=cal_find_near();
        cal_hw=ci>=0?((cal_w4[ci]+2)>>2):0;
        cal_k3r=ci>=0?((cal_k3x4[ci]+2)>>2):0;
        cal_use3=ci>=0&&cal_k3r>=3&&cal_k3x4[ci]>0&&cal_rev[ci]<=4&&cal_hw>=8;   /* +/-3 comes back within 1 step */
        cal_back=ci>=0&&cal_b4[ci]>=4?((cal_b4[ci]+2)>>2):0;
        go_last=0;
    }
    if(gate()){fail(S_GATE);return -1;}
    if(!cfd_seq||(int)(get_ms_clock()-cfd_ms)>300){fail(S_NODATA);return -1;}
    used_seq=cfd_seq;
    if(!c_run&&settle()<0)return -1;             /* continuous: no half-press, nothing to settle */
    /* baseline: 5 new values -> median, noise, scale reference */
    for(i=0;i<5;i++)if(cnext(&v[i])<0)return -1;     /* 5 new values after settling (the v1 average has caught up) */
    ref_v1=cfd_v[1]?cfd_v[1]:1;
    for(i=1;i<5;i++)for(j=i;j>0&&v[j-1]>v[j];j--){uint32_t t=v[j];v[j]=v[j-1];v[j-1]=t;}
    cur=v[2];spread=v[4]-v[0];
    v_start=cur;v_best=cur;v_min=cur;bv=cur;bp=0;pv[PO]=cur;bsh=cv_sh;psh[PO]=cv_sh;
    tol_bp=(int)divu(spread*10000u,cur?cur:1u)+100;        /* the range of 5 + 1 pct */
    if(tol_bp<250)tol_bp=250;if(tol_bp>600)tol_bp=600;
    note(E_BASE,0,0,cur);
    if((c_run&&glide_setting)||(!c_run&&!cal_busy&&qglide_setting))
    {   /* v15: GLIDE continuous AF - the +/-1 rapid-fire motion, read every frame (position counts in +/-1 steps,
           so the +/-2 restore after a failed run is off: glide puts the lens back itself) */
        gp_apply();levels_used|=8;
        {int r;g_noscale=1;r=glide_run();g_noscale=0;return r;}
    }

    /* 1. both sides with +/-2 (+ first) */
    /* far out of focus (ratio < 0.5, only with exposure compensation): small dips both ways are not a top -
       search with the big jumps (CFAF3D9D accepted such a dip far out of focus) */
    far_mode=norm_setting&&v_start<2048u;
    flatmax_first=(cal_hw>=4&&!c_run)?1:2;              /* learned zone: one half-width look each side is enough */
    if(far_mode)note(E_FLAT,0,6,v_start);
    r=two_side(c_run?c_first:1,c_run?2:6,&fa,&fb);if(r<0)return -1;   /* continuous: last good direction first, short strides */
    far_mode=0;flatmax_first=2;
    if(!r&&c_run&&(c_ref&&!below(v_start,c_ref,5000)))
    {   /* continuous, still at least half as sharp as the last focus and nothing better either side: stay */
        uint32_t v;
        if(goto2(0)<0)return -1;if(read_here(&v)<0)return -1;
        v_final=v;note(E_FINAL,0,0,v);return 0;
    }
    if(!r&&c_run&&!cbig_setting)
    {   /* continuous with C-Big Jumps OFF: no long search while filming - back to where it was, not "OK" */
        if(goto2(0)<0)return -1;
        fail(S_NOHILL);return -1;
    }
    if(!r)
    {   /* 2. flat on at least one side: far out of focus */
        int dirs[2],nd=0,k,rr,jumps;
        {   /* which side to search first: the side whose readings were a little higher (far out the hill still
               tilts the floor: 6F80 + side 2326-2359 vs - side 2380-2383, hill on the -; 6F7C the same) */
            uint32_t sp=0,sm=0;int np=0,nm=0,q;
            for(q=1;q<PO;q++){if(pv[PO+q]){sp+=pv[PO+q]>>4;np++;}if(pv[PO-q]){sm+=pv[PO-q]>>4;nm++;}}
            if(np&&nm&&divu(sp,(uint32_t)np)>divu(sm,(uint32_t)nm))
            {   if(fa==W_FLAT)dirs[nd++]=1; if(fb==W_FLAT)dirs[nd++]=-1; }
            else
            {   if(fb==W_FLAT)dirs[nd++]=-1; if(fa==W_FLAT)dirs[nd++]=1; }
            note(E_FLAT,nd?dirs[0]:0,5,0);
        }
        if(big_setting)
        {   /* big +/-3 jumps to find the hill, then +/-2 again from where they stopped */
            for(k=0;k<nd;k++)
            {
                jumps=0;
                rr=seek_big(dirs[k],k?24:12,&jumps);if(rr<0)return -1;
                if(rr==B_PASSED)
                {
                    r=return_walk(-dirs[k]);if(r<0)return -1;
                    if(!r){fail(S_NOHILL);return -1;}
                    if(rebase()<0)return -1;                /* count again from here, on the hill */
                    r=two_side(-dirs[k],2,&fa,&fb);if(r<0)return -1;r=1;break;
                }
                if(rr==B_FELL){if(rebase()<0)return -1;r=two_side(dirs[k],2,&fa,&fb);if(r<0)return -1;r=1;break;}
                if(rr==B_NEAR){if(rebase()<0)return -1;r=two_side(dirs[k],2,&fa,&fb);if(r<0)return -1;r=1;break;}
                if(k+1<nd)
                {   /* nothing that way: jump back past the start and look the other way */
                    if(cmdn(3,-dirs[k],jumps)<0)return -1;
                }
            }
            if(!r){fail(S_NOHILL);return -1;}
        }
        else
        {   /* long +/-2 strides along the flat side(s) */
            for(k=0;k<nd;k++)
            {
                if(k&&goto2(0)<0)return -1;
                rr=walk(dirs[k],4,6,6,&s);if(rr<0)return -1;
                if(above(bv,v_start,3*tol_bp))break;
            }
            if(!above(bv,v_start,3*tol_bp)&&!below(v_min,bv,2*tol_bp))
            {   /* nothing rose and nothing fell: no hill in reach - back to the start */
                if(goto2(0)<0)return -1;fail(S_NOHILL);return -1;
            }
            /* else: the long strides fell well below the best: the best (near the start) is a wide top */
        }
    }
    if(refine(&cur)<0)return -1;
    v_final=cur;
    /* never call it OK when it ended far below the best value it saw, or near the floor while a real hill was seen */
    if(below(v_final,bv,3000)||below(v_final,v_best,4000)){fail(S_NOHILL);return -1;}
    if(above(v_best,v_min,3000)&&v_final-v_min<divu((v_best-v_min)*3u,5u)){fail(S_NOHILL);return -1;}
    /* with exposure compensation the value is Canon's sharpness / brightness: below 0.6 is not in focus in any log
       (in focus 1.5-7, far out 0.2-0.9) unless it at least doubled from the lowest reading */
    if(norm_setting&&v_final<2458u&&!above(v_final,v_min,10000)){fail(S_NOHILL);return -1;}
    note(E_FINAL,0,bp,v_final);
    {   /* learn the half-width: nearest read positions either side of the best that are below 70 pct of it */
        int q,dl=0,dr=0;uint32_t lim=bv-(bv>>2)-(bv>>4)+(bv>>5);              /* ~72 pct */
        for(q=1;q<60&&bp-q>-PO;q++){uint32_t x=pv[bp-q+PO];if(x&&x<lim){dl=q;break;}}
        for(q=1;q<60&&bp+q<PO;q++){uint32_t x=pv[bp+q+PO];if(x&&x<lim){dr=q;break;}}
        if(dl||dr){int d=(dl&&dr)?(dl<dr?dl:dr):(dl?dl:dr);note(E_TARGET,0,d,0);cal_learn(d*4);}
    }
    return 0;
}


/* ---------------- CSV ---------------- */
static int oh=0;static char ob[512];static int on=0;
static void flush(void){if(on&&oh>0)FIO_WriteFile(oh,ob,(unsigned)on);on=0;}
static void ch(char c){if(on>450)flush();ob[on++]=c;}
static void txt(const char *s){while(*s)ch(*s++);}
static void num(uint32_t n){char b[12];int i=0;if(!n){ch('0');return;}while(n&&i<11){b[i++]=(char)('0'+n%10u);n=divu(n,10);}while(i)ch(b[--i]);}
static void snum(int n){if(n<0){ch('-');num((uint32_t)(-n));}else num((uint32_t)n);}
static uint32_t log_serial=0;
static void save_log(void)
{
    char path[20]="ML/CFAF0000.CSV";static const char hx[]="0123456789ABCDEF";uint32_t x;int i;
    if(!log_setting)return;
    if(!log_serial)log_serial=t0&0xFFFFu;else log_serial++;
    x=log_serial;for(i=0;i<4;i++){path[10-i]=hx[x&15u];x>>=4;}
    oh=FIO_CreateFile(path);if(oh<=0){oh=0;return;}
    txt("# CFAF v25 Canon Focus AF [" CAM_MODEL " " CAM_FW "]. Sharpness = Canon PROP_LV_FOCUS_DATA v2+v3");if(norm_setting)txt(" x4096 / smoothed v1 (exposure comp ON: 4096 = ratio 1.0)");txt(".\n");
    txt("# SUMMARY,stop,");snum(stop_code);txt(",result,");txt(stop_text[stop_code<7?stop_code:0]);
    txt(",start,");num(v_start);txt(",final,");num(v_final);txt(",best_seen,");num(v_best);txt(",lowest_seen,");num(v_min);
    txt(",final_pct_of_best,");num(v_best?divu(v_final*10u,divu(v_best,10u)+1u):0);
    txt(",tol_bp,");snum(tol_bp);txt(",commands,");snum(cmds);txt(",units_net,");snum(units);txt(",refusals_end,");snum(refusals);
    txt(",levels_used,");snum(levels_used);txt(",ms,");num(get_ms_clock()-t0);txt(",canon_frames,");num(cfd_seq-seq0);
    txt(",focal_mm,");num(lens_info.focal_len);txt(",lens_id,");num(lens_info.lens_id);
    txt(",trigger,");txt(c_run?"continuous":(hs_run?"halfshutter":(tap_run==2?"tap":(tap_run==1?"focusbutton":"menu"))));txt(",released,");snum(hs_released);txt(",speed,");snum(speed_setting);
    txt(",rows_dropped,");snum(tr_drop);txt(",two_channels,");snum(agree_setting);txt(",afbox_x,");snum(aff[2]);txt(",afbox_y,");snum(aff[3]);txt(",afbox_w,");snum(aff[4]);txt(",afbox_h,");snum(aff[5]);txt(",sensor_w,");snum(aff[0]);txt(",sensor_h,");snum(aff[1]);txt(",c_mode_always,");snum(calways_setting);txt(",c_big_jumps,");snum(cbig_setting);txt(",zone_halfwidth_steps,");snum(cal_hw);txt(",stopped_by,");snum(stop_code==S_GATE?gate_why:0);txt(",glide,");snum(c_run?glide_setting:(cal_busy?0:qglide_setting));txt(",glide_unit,");snum(g_unit);txt(",glide_lag_ms,");snum(g_lag);txt(",glide_backlash,");snum(g_bk);txt(",glide_pm1_per_pm2,");snum(g_k21);txt(",glide_from_probe,");snum(g_from_probe);ch('\n');
    txt("# event 1 start,2 baseline,3 sample(arg=values),4 move(arg=size),5 refused then ok on retry,6 end stop / wall,7 walk ended: drop (arg 1 clear,2 after flat),8 best position chosen(arg=pos),9 final(arg=pos),10 abort(arg=stop),11 walk ended flat (arg 2 +/-2, 3 big jumps, 5 search side chosen = dir, 9 Canon never settled). Level 3 = big +/-3 jumps (event 7 arg 3 passed the hill, arg 4 only fell: jumped back)\n");
    txt("# level 2 = walk, 1 = refine around the best. units = net +/-2 position (CFAF v2 moves only in +/-2 steps).\n");
    txt("ms,event,level,dir,arg,canon,units,commands,canon_v1,focus_pos,v2_share_x1024\n");
    for(i=0;i<tr_n;i++)
    {
        struct row *r=&tr[i];
        num(r->ms);ch(',');snum(r->ev);ch(',');snum(r->lvl);ch(',');snum(r->dir);ch(',');snum(r->arg);ch(',');
        num(r->val);ch(',');snum(r->units);ch(',');snum(r->cmds);ch(',');num(r->v1);ch(',');snum(r->fpos);ch(',');snum(r->sh);ch('\n');
    }
    flush();FIO_CloseFile(oh);oh=0;
}

/* ---------------- CFAF Calibrate Lens ----------------
   Tripod, a detailed target (CAMCAL_TARGET on a monitor is fine), Magic Zoom ON, set the focal length, then
   menu "CFAF Calibrate Lens". It maps this lens at this focal length, about 20-60 s:
     1. focuses normally;
     2. reads Canon's value 6 times without moving (noise);
     3. sweeps the focus in single +/-2 steps through the whole sharp zone, forward and back, reading every step
        -> the shape and width of the sharp zone, and the backlash (the two sweeps' peaks are shifted by it);
     4. from the peak: one +/-3 jump and back (its size in +/-2 steps from the measured shape, and whether it
        comes back), and 4 x +/-1 and back (+/-1 size);
     5. times every command type.
   Saves it in ML/CFAFCAL.TXT for this lens + focal length (normal focusing uses it from then on: zone width,
   +/-3 jumps on lenses whose +/-3 comes back, backlash) and writes ML/CFCxxxxx.CSV with the sweeps.
   Do it at several focal lengths on a zoom (e.g. 17, 24, 35, 55). */
#define CPN 200
static uint32_t cpu[CPN],cpd[CPN];static int cp_lo=0,cpn_u=0,cpn_d=0;
static uint32_t c_res[12];
/* position (x4) on the rising/falling side of a sweep where it crosses value y, searching outward from the peak */
static int cross_x4(const uint32_t *a,int n,int pk,int dir,uint32_t y)
{
    int i;
    for(i=pk;i>=0&&i<n;i+=dir)
    {
        int j=i+dir;
        if(j<0||j>=n)return -1;
        if(a[j]<=y&&a[i]>y)
        {   uint32_t d=a[i]-a[j];int fr=d?(int)divu((a[i]-y)*4u,d):0;   /* fraction of the step x4 */
            if(fr>4)fr=4;
            return i*4+dir*fr;
        }
    }
    return -1;
}
static int peak_x4(const uint32_t *a,int n)
{   int i,b=0;for(i=1;i<n;i++)if(a[i]>a[b])b=i;
    if(b>0&&b<n-1)
    {   int y0=(int)(a[b]>>6),yl=(int)(a[b-1]>>6),yr=(int)(a[b+1]>>6),den=2*(yl+yr-2*y0);
        int off=den?divs((yl-yr)*4,den):0;if(off>2)off=2;if(off<-2)off=-2;
        return b*4+off;
    }
    return b*4;
}
static void cal_csv(int ok);
static int calibrate_lens(void)
{
    uint32_t v,P,lo,hi,t,lim,w45;int i,n,L,pu,pd,a,b,hw4,k3x4=0,rev=99,k1x4=0,t2=0,t3=0,nz,pk;int save_use3;
    cal_busy=1;for(i=0;i<12;i++)c_res[i]=0;cpn_u=cpn_d=0;
    save_use3=cal_use3;
    /* 1. focus */
    if(af_run()<0||stop_code!=S_OK){cal_busy=0;return -1;}
    cal_use3=0;cal_back=0;                                    /* plain +/-2 steps while measuring */
    if(rebase()<0)goto fail;
    P=pv[PO];
    /* 2. noise */
    lo=hi=P;
    for(i=0;i<6;i++){if(cnext(&v)<0)goto fail;if(v<lo)lo=v;if(v>hi)hi=v;}
    nz=(int)divu((hi-lo)*625u,(P>>4)+1);                      /* bp = (hi-lo)/P*10000 */
    w45=(P>>1)-(P>>4)-(P>>5);                                 /* ~41 pct: far enough down the slope */
    /* 3a. walk down until well off the zone */
    for(n=0;n<80;n++){int m=go2(1,-1);if(m<0)goto fail;if(!m)break;if(sample(&v,1)<0)goto fail;if(v<w45)break;}   /* v18: an end stop ends the walk (the Sigma 18-300 got 43 refusals in a row and stopped answering) */
    L=p2;cp_lo=L;
    /* 3b. sweep up */
    t=get_ms_clock();cpn_u=0;
    for(n=0;n<CPN;n++)
    {   int m=go2(1,1);if(m<0)goto fail;if(!m)break;if(sample(&v,1)<0)goto fail;cpu[cpn_u++]=v;
        if(p2>0&&v<w45)break;
    }
    t2=(int)divu(get_ms_clock()-t,(uint32_t)(cpn_u?cpn_u:1));
    /* 3c. sweep down to the start (position k of cpd = same command count as cpu[k]) */
    cpn_d=cpn_u;
    for(i=cpn_u-2;i>=0;i--){int m=go2(1,-1);if(m<0)goto fail;if(!m)goto fail;if(sample(&v,1)<0)goto fail;cpd[i]=v;}
    cpd[cpn_u-1]=cpu[cpn_u-1];
    pu=peak_x4(cpu,cpn_u);pd=peak_x4(cpd,cpn_d);
    /* backlash: after each reversal the first steps do not move, so the up sweep sees the peak later */
    b=pu-pd;if(b<0)b=0;
    lim=0;{uint32_t m=0;for(i=0;i<cpn_u;i++)if(cpu[i]>m)m=cpu[i];lim=m-(m>>2)-(m>>4)+(m>>5);}   /* ~72 pct */
    pk=(pu+2)>>2;
    a=cross_x4(cpu,cpn_u,pk,-1,lim);i=cross_x4(cpu,cpn_u,pk,1,lim);
    hw4=(a>=0&&i>=0)?((i-a)>>1):(a>=0?pu-a:(i>=0?i-pu:0));
    /* 4. measure +/-3 and +/-1 on the steep part of the slope (left 72 pct point): there a small move changes the
          value a lot, so sizes come out precise even on lenses with a wide, flat top */
    {
        int S,c,x,y4;uint32_t y0,y1,y2;
        S=a>=0?((a+2)>>2):(pk>2?pk-2:0);                       /* index into the up sweep */
        if(goto2(L+1+S-2)<0)goto fail;if(goto2(L+1+S)<0)goto fail;   /* arrive going up, like the sweep */
        if(sample(&y0,2)<0)goto fail;
        /* +/-1: 4 steps down the slope, read, find that value on the sweep */
        for(i=0;i<4;i++)if(cmd(1,-1)<=0)goto fail;
        if(sample(&y1,2)<0)goto fail;
        x=cross_x4(cpu,cpn_u,S,-1,y1);k1x4=x>=0?divs(S*4-x,4):0;if(k1x4<0)k1x4=0;
        for(i=0;i<4;i++)if(cmd(1,1)<=0)goto fail;
        if(goto2(L+1+S-2)<0)goto fail;if(goto2(L+1+S)<0)goto fail;
        if(sample(&y0,2)<0)goto fail;
        /* +/-3 down the slope, then +/-2 steps back up until the value is back: that count is the +/-3 size */
        t=get_ms_clock();
        if(cmd(3,-1)<=0)goto fail;
        t3=(int)(get_ms_clock()-t);
        if(sample(&y1,1)<0)goto fail;
        for(c=0,y2=y1;c<40;c++)
        {   if(cmd(2,1)<=0)goto fail;if(sample(&v,1)<0)goto fail;
            if(v>=y0){uint32_t d=v-y2;y4=d?(int)divu((y0-y2)*4u,d):4;if(y4>4)y4=4;k3x4=c*4+y4-b;break;}
            y2=v;
        }
        if(k3x4<0)k3x4=0;
        /* does +/-3 come back? from the slope point: one down, one up, read, see where that is on the sweep */
        if(goto2(L+1+S-2-c-1)<0)goto fail;                    /* p2 still counts the walk-back steps only */
        if(goto2(L+1+S)<0)goto fail;
        if(sample(&y0,2)<0)goto fail;
        if(cmd(3,-1)<=0)goto fail;msleep(150);
        if(cmd(3,1)<=0)goto fail;
        if(sample(&y2,2)<0)goto fail;
        x=cross_x4(cpu,cpn_u,pk,-1,y2);                        /* where on the rising side is that value */
        rev=x>=0?(x>S*4?x-S*4:S*4-x):99;                      /* return error x4 (+/-2 steps), 0 = perfect */
    }
    /* 5. save */
    {
        int ci=cal_find();
        if(ci<0){if(cal_n>=CAL_N)goto fail;ci=cal_n++;cal_lens[ci]=(int)lens_info.lens_id;cal_fb[ci]=cal_bucket(lens_info.focal_len);cal_cnt[ci]=0;}
        cal_w4[ci]=hw4>0?hw4:cal_w4[ci];cal_cnt[ci]+=5;
        cal_k3x4[ci]=k3x4;cal_rev[ci]=rev;cal_b4[ci]=b;cal_k1x4[ci]=k1x4;cal_t2[ci]=t2;cal_t3[ci]=t3;cal_nz[ci]=nz;
        cal_save();
    }
    c_res[0]=(uint32_t)hw4;c_res[1]=(uint32_t)k3x4;c_res[2]=(uint32_t)rev;c_res[3]=(uint32_t)b;c_res[4]=(uint32_t)k1x4;
    c_res[5]=(uint32_t)t2;c_res[6]=(uint32_t)t3;c_res[7]=(uint32_t)nz;
    cal_csv(1);
    NotifyBox(10000,"CFAF calibrated %dmm: zone %d.%d steps, +-3 = %d.%d steps (returns within %d.%d), backlash %d.%d",
        lens_info.focal_len,hw4>>2,(hw4&3)*25,k3x4>>2,(k3x4&3)*25,rev>>2,(rev&3)*25,b>>2,(b&3)*25);
    cal_use3=save_use3;cal_busy=0;
    return 0;
fail:
    cal_csv(0);
    NotifyBox(5000,"CFAF calibration stopped (tripod, detailed target, Magic Zoom ON, keep still)");
    cal_use3=save_use3;cal_busy=0;
    return -1;
}

static void cal_csv(int ok)
{
    char path[20]="ML/CFC00000.CSV";static const char hx[]="0123456789ABCDEF";uint32_t x;int i;
    x=get_ms_clock()&0xFFFFFu;for(i=0;i<5;i++){path[10-i]=hx[x&15u];x>>=4;}
    oh=FIO_CreateFile(path);if(oh<=0){oh=0;return;}
    txt("# CFAF lens calibration [" CAM_MODEL " " CAM_FW "]. lens_id,");num(lens_info.lens_id);txt(",focal_mm,");num(lens_info.focal_len);
    txt(",ok,");snum(ok);txt(",stop,");snum(stop_code);txt("\n# zone_halfwidth_x4,");num(c_res[0]);txt(",pm3_steps_x4,");num(c_res[1]);
    txt(",pm3_return_error_x4,");num(c_res[2]);txt(",backlash_x4,");num(c_res[3]);txt(",pm1_steps_x4,");num(c_res[4]);
    txt(",ms_per_pm2,");num(c_res[5]);txt(",ms_per_pm3,");num(c_res[6]);txt(",noise_bp,");num(c_res[7]);
    txt("\n# steps are +/-2 commands. up = sweep going +, down = sweep going -, same command positions\nstep,up,down\n");
    for(i=0;i<cpn_u;i++){snum(i);ch(',');num(cpu[i]);ch(',');num(i<cpn_d?cpd[i]:0);ch('\n');}
    flush();FIO_CloseFile(oh);oh=0;
}

/* ---------------- GLIDE continuous AF (v15, menu CFAF C-Motion = GLIDE) ----------------
   CFAF Probe Lens on the 17-55 (30 Oct): waited +/-1 steps can be sent back to back, one every 31-56 ms - a fine,
   continuous-looking movement - and Canon's value follows it frame by frame. So instead of step / stop / read,
   GLIDE keeps the lens moving in +/-1 steps and reads every frame on the way:
     - each frame is tagged with where the lens was g_lag ms earlier (Canon shows a move a little late);
     - it glides the last good direction first; if it only gets softer it turns round (backlash taken up);
     - when the value has clearly dropped past the best it saw, it glides back to the best position
       with a soft stop (ease out), and checks the value there;
     - long distances (value under half the reference) use +/-2 steps (one +/-2 = g_k21 +/-1 steps);
     - C-Speed SLOW adds a pause to every step (slower, gentler glide).
   g_lag, g_bk (backlash in +/-1 steps), g_k21 come from CFAF Probe Lens (ML/CFAFGLD.TXT) or defaults. */
#define GL_N 700
#define GF_N 500
static int gl_pos=0,gl_last=0,gl_n=0,gf_n=0;
static uint32_t gl_t[GL_N],gf_v[GF_N],gf_t[GF_N];static int16_t gl_p[GL_N],gf_p[GF_N];
static uint32_t g_bv;static int g_bp;
enum { G_PASSED=1,G_WRONG=2,G_FLAT=3,G_WALL=4 };
static int gl_pos_at(uint32_t t)
{   int i;
    for(i=gl_n-1;i>=0;i--)if((int)(gl_t[i]-t)<=0)return gl_p[i];
    return gl_n?gl_p[0]:0;
}
static void gl_mark(void){if(gl_n<GL_N){gl_t[gl_n]=get_ms_clock();gl_p[gl_n]=(int16_t)gl_pos;gl_n++;}}
/* new Canon frames since the last call -> gf_*; 1 = got one, 0 none, -1 abort */
static int gpoll(void)
{
    int got=0;
    if(cfd_seq!=used_seq)
    {   uint32_t v1;
        used_seq=cfd_seq;
        if(cfd_v[1]&&(cfd_v[2]|cfd_v[3]))
        {   v1=cfd_v[1];
            /* v17: Canon's v1 jumped 3x mid-glide in CFAF8169/816C/816E (WD-40 bottle) and v16 stopped the run.
               GLIDE carries on with the new scale (the two-way top and the 75 pct landing check guard it) */
            if(ref_v1&&(norm_setting?(v1*3u<ref_v1||v1>ref_v1*3u):(v1*10u<ref_v1*7u||v1*7u>ref_v1*10u))){note(E_RETRY,0,99,v1);ref_v1=v1;}
            if(gf_n<GF_N)
            {   int u=units;
                gf_v[gf_n]=cur_value();gf_t[gf_n]=cfd_ms;gf_p[gf_n]=(int16_t)gl_pos_at(cfd_ms);   /* v16: position AT the frame (two-way peak cancels the delay) */
                units=gf_p[gf_n];note(E_SAMPLE,gl_last,0,gf_v[gf_n]);units=u;
                if(gf_v[gf_n]>v_best)v_best=gf_v[gf_n];if(!v_min||gf_v[gf_n]<v_min)v_min=gf_v[gf_n];
                gf_n++;got=1;
            }
        }
    }
    if((int)(get_ms_clock()-cfd_ms)>400)return fail(S_LOST);
    return got;
}
static uint32_t g_sm(int i)            /* median of frames i-2..i */
{   uint32_t a,b,c;
    if(i<2)return gf_v[i<0?0:i];
    a=gf_v[i-2];b=gf_v[i-1];c=gf_v[i];
    if(a>b){uint32_t t=a;a=b;b=t;}if(b>c){uint32_t t=b;b=c;c=t;}if(a>b){uint32_t t=a;a=b;b=t;}
    return b;
}
/* one waited command, backlash taken up on a reversal. 1 moved, 0 end stop, -1 abort */
static int gstep(int dir,int mag)
{
    int rc,i;
    keep_awake();
    if(gate())return fail(S_GATE);
    if(cmds>=1500||(int)(get_ms_clock()-t0)>(c_run?TIME_MAX:40000))return fail(S_BUDGET);   /* quick AF on a slow lens may need the whole travel */
    if(gl_last&&dir!=gl_last)for(i=0;i<g_bk;i++){if(!lens_focus(1,dir,1,0))break;cmds++;}
    gl_last=dir;
    rc=lens_focus(1,dir*mag,1,0);
    if(!rc)
    {   msleep(100);if(gate())return fail(S_GATE);
        rc=lens_focus(1,dir*mag,1,0);
        if(!rc){note(E_WALL,dir,mag,0);refusals++;return 0;}
    }
    if(ew_end()){note(E_WALL,dir,mag,1);refusals++;return 0;}            /* v20: encoder says end stop */
    cmds++;last_dir=dir;
    gl_pos+=dir*(mag==3?g_k3u:((mag==2&&g_unit==1)?g_k21:1));units=gl_pos;gl_mark();
    note(E_MOVE,dir,mag,0);
    return 1;
}
static int g_pause(int ms)              /* wait ms, reading frames */
{   uint32_t t=get_ms_clock();
    do{if(gpoll()<0)return -1;msleep(10);}while((int)(get_ms_clock()-t)<ms);
    return 0;
}
/* v16 GLIDE: two-way peak. Camera log CFAF8F28 (17-55 at 55 mm, f/2.8): it glided 115 +/-1 steps up a long slope,
   passed a very narrow peak (8972 -> 11063 -> 4710 in two frames), then went back to where it THOUGHT the peak
   was using a guessed Canon delay of 100 ms - 4 steps off a peak only ~3 steps wide (value 4775 = 43 pct) - and
   accepted it because it was still better than the start. Now:
   - frames are tagged with the lens position at the moment of the frame (no delay guess);
   - after passing the top one way it glides back the other way through it and past it: Canon's delay shifts the
     two peaks in opposite directions, so the middle of the two IS the top (the delay cancels; it is also learned);
   - it lands there with a soft stop, polishes +/-1 either side if the value is low, and only says OK at >= 75 pct
     of the best it saw; otherwise it stays at the best place and the next run carries on;
   - far below a good value it moves in +/-2 steps (8F28 took 9.7 s at +/-1), +/-1 near the top. */
static uint32_t c_mem=0;static int c_mem_lens=-1,c_mem_fb=-1;   /* best OK value this session (lens, focal) */
static int g_ms1=30;                                            /* measured ms per +/-1 step this run */
static int g_dropbp(void){int d=2*tol_bp;if(d<900)d=900;if(g_nz&&d<g_nz*3)d=g_nz*3;return d;}
/* glide one way until the value has clearly dropped past the best of THIS pass (G_PASSED, *pk / *vk = where
   and what the best frame was), G_WRONG (only softer from the start, wrongcheck), G_FLAT, G_WALL; -1 abort.
   fixed: constant speed (no ease, +/-1 only) - used for the return pass so both passes see the same delay */
static int glide_pass(int dir,int wrongcheck,int fixed,int maxst,int *pk,uint32_t *vk)
{
    int st=0,mag,drops=0,rose=0,pstart=gl_pos,ease=fixed?3:0,i0=gf_n,dropbp=g_dropbp(),wrong_n,flat_n,j,pmax=gl_pos;
    uint32_t vmax=0,vst=0,ref=c_ref>c_mem?c_ref:c_mem,t1=get_ms_clock();int n1=0;
    if(!ref&&norm_setting)ref=8192u;                       /* in focus = ratio 1.5-7 in every log so far */
    wrong_n=g_k21*2;if(wrong_n<6)wrong_n=6;
    flat_n=cal_hw>0?cal_hw*g_k21:16;if(flat_n<16)flat_n=16;if(flat_n>120)flat_n=120;
    if(!c_run&&flat_n<32)flat_n=32;                                             /* quick AF: wide tops need a longer look */
    if(g_unit==2){wrong_n=3;flat_n=cal_hw>8?cal_hw:8;if(flat_n>60)flat_n=60;}     /* counted in +/-2 steps */
    lvl=4;levels_used|=16;
    while(st<maxst)
    {
        uint32_t sm=gf_n>i0?g_sm(gf_n-1):0;
        mag=g_unit;
        {   /* +/-2 far below: quick AF under 25 pct of a good value; continuous only with C-Speed FAST (under 20 pct) -
               in the simulator +/-2 in continuous overshot narrow tops (85 mm: 93 -> 73 pct sharp) */
            int f2=c_run?(cspeed_setting==2?20:0):g_far2;
            if(g_unit==1&&!fixed&&f2&&st>=2&&ref&&gf_n>i0&&sm*100u<ref*(uint32_t)f2)mag=2;
        }   /* far below: +/-2 (v21: also while rising -
            v20 only used it while falling, so CFAF0D57 / 0F5C crawled 160 +/-1 steps) */
        /* v19 very far below (under a quarter): +/-3 jumps when calibration showed this lens's +/-3 lands where
           it should (Sigma 18-300: one +/-3 = ~6 +/-2 in 0.57 s, the +/-2 alone 0.25 s each) */
        if(g_k3u>0&&!fixed&&!c_run&&st>=2&&ref&&gf_n>i0&&sm*4u<ref)mag=3;
        j=gstep(dir,mag);if(j<0)return -1;if(!j){*pk=pmax;*vk=vmax;return G_WALL;}
        st+=mag==3?g_k3u:((mag==2&&g_unit==1)?g_k21:1);if(mag==g_unit)n1++;
        if(mag==3&&g_pause(120)<0)return -1;                                   /* Canon's value after a jump */
        {   int pz=ease<3?(3-ease)*15:0;ease++;                                  /* ease in */
            if(cspeed_setting==0)pz+=45;                                         /* cinematic */
            if(pz&&g_pause(pz)<0)return -1;
        }
        if(gpoll()<0)return -1;
        if(gf_n-i0<3)continue;
        j=gf_n-1;sm=g_sm(j);
        if(!vst)vst=sm;
        if(!vmax||sm>vmax){if(vmax&&above(sm,vmax,tol_bp))rose=1;if(above(sm,vst,tol_bp))rose=1;vmax=sm;pmax=gf_p[j-1];drops=0;}
        else if(below(sm,vmax,dropbp)&&dir*(gf_p[j]-pmax)>0&&(rose||!wrongcheck)){if(++drops>=2){*pk=pmax;*vk=vmax;goto passed;}}
        else drops=0;
        {   int far=ref&&sm*2u<ref&&!rose;                                    /* far out, flat floor */
            if(wrongcheck&&!rose&&dir*(gl_pos-pstart)>=wrong_n&&below(sm,vst,far?1500:tol_bp)){*pk=pmax;*vk=vmax;return G_WRONG;}
            if(!far&&dir*(gl_pos-pmax)>=flat_n){*pk=pmax;*vk=vmax;return G_FLAT;}
        }
    }
    *pk=pmax;*vk=vmax;return G_FLAT;
passed:
    if(n1>3)g_ms1=(int)divu(get_ms_clock()-t1,(uint32_t)st);
    return G_PASSED;
}
/* glide to position t in +/-1 steps, soft stop: the last 3 steps slow down */
static int glide_to(int t)
{
    int d,dir,j,k=0;
    lvl=4;
    while((d=t-gl_pos)!=0&&k<400)
    {   dir=d>0?1:-1;
        j=gstep(dir,g_unit);if(j<0)return -1;if(!j)return 0;
        if(gpoll()<0)return -1;
        d=t-gl_pos;if(d<0)d=-d;
        if(d<=3&&d>0){if(g_pause((4-d)*15+(cspeed_setting==0?45:0))<0)return -1;}   /* ease out */
        else if(cspeed_setting==0&&g_pause(45)<0)return -1;
        k++;
    }
    return 0;
}
/* value after the lens settled: median of 3 new frames, skipping 2 */
static int g_read(uint32_t *v)
{   uint32_t a[3],x;int i;
    used_seq=cfd_seq;
    for(i=0;i<(g_lag<=50?1:2);i++)if(cnext(&x)<0)return -1;      /* v23: skip 1 frame when the delay is short */
    for(i=0;i<3;i++)if(cnext(&a[i])<0)return -1;
    if(a[0]>a[1]){x=a[0];a[0]=a[1];a[1]=x;}if(a[1]>a[2]){x=a[1];a[1]=a[2];a[2]=x;}if(a[0]>a[1]){x=a[0];a[0]=a[1];a[1]=x;}
    *v=a[1];note(E_SAMPLE,0,3,*v);return 0;
}
/* polish: read +/-1 and +/-2 around here (fewest moves), go to the best. */
static int g_polish(uint32_t *v)
{
    int best=gl_pos,c=gl_pos,k;uint32_t bvv=*v,x;static const signed char off[4]={1,2,-1,-2};
    for(k=0;k<4;k++)
    {   if(glide_to(c+off[k])<0)return -1;
        if(g_read(&x)<0)return -1;
        if(x>bvv){bvv=x;best=gl_pos;}
        if(k==1&&best==c+2){if(glide_to(c+3)<0)return -1;if(g_read(&x)<0)return -1;if(x>bvv){bvv=x;best=gl_pos;}break;}
        if(k==1&&best==c+1)break;                             /* + side better at +1: done */
    }
    if(glide_to(best)<0)return -1;
    if(g_read(&x)<0)return -1;
    *v=x;return 0;
}
/* wide polish: read -4..+4 in one direction (one backlash), go to the best */
static int g_polish_wide(uint32_t *v)
{
    int c=gl_pos,best=gl_pos,k;uint32_t bvv=*v,x;
    if(glide_to(c-5)<0)return -1;                        /* approach from below: every reading going + */
    for(k=-4;k<=4;k++){if(glide_to(c+k)<0)return -1;if(g_read(&x)<0)return -1;if(x>bvv){bvv=x;best=gl_pos;}}
    if(best!=gl_pos){if(glide_to(best-2)<0)return -1;if(glide_to(best)<0)return -1;}
    if(g_read(&x)<0)return -1;
    *v=x;return 0;
}
static int g_fpos0=0;
/* v18: after Calibrate on the Sigma 18-300 the lens accepted commands but nothing moved: Canon's value stayed
   within ~2 pct over 40-70 commands and the lens position report froze. Say so instead of hunting silently. */
static void g_check_stuck(void)
{
    if(cmds>=20&&lens_info.focus_pos==g_fpos0&&v_min&&!above(v_best,v_min,600))
        NotifyBox(6000,"CFAF: the lens is not moving (no change after %d commands). Lens AF/MF switch off and on, or camera off/on",cmds);
}
/* v23: learn the sharp zone while working. The constant-speed return pass crossed the whole top: where the
   value is >= 72 pct of its best gives the zone width (Canon's delay shifts both edges the same way). Saved
   per lens + focal length like Calibrate's - so every focal length of a zoom gets learned just by using it,
   and the step size (+/-1 or +/-2) follows. Only when the pass started and ended below 72 pct. */
static int g_p1i=-1,g_p2i=-1,r2_ok=0;
static void g_learn_zone(void)
{
    /* rising side of the pass that first crossed the top: from where it was under 72 pct of that pass's best
       up to the best = the half-width (Canon's delay shifts both points the same way) */
    int j,jb=-1,pb=0,pe=0,found=0,w4;uint32_t best=0,lim;static uint32_t last=0;
    if(g_p1i<0||g_p2i<=g_p1i+4)return;
    if(last&&(int)(get_ms_clock()-last)<60000)return;           /* at most one card write a minute (recording!) */
    for(j=g_p1i+2;j<g_p2i;j++){uint32_t m=g_sm(j);if(m>best){best=m;jb=j;}}
    if(jb<0)return;
    lim=best-(best>>2)-(best>>5);
    pb=gf_p[jb-1];
    for(j=jb;j>=g_p1i+2;j--)if(g_sm(j)<lim){pe=gf_p[j-1];found=1;break;}
    if(!found)return;                                            /* it started inside the zone */
    w4=(pb>pe?pb-pe:pe-pb)*4;                                    /* half-width x4 in position units */
    if(g_unit==1)w4=divs(w4,g_k21);                              /* -> +/-2 steps x4 */
    if(w4<2)w4=2;if(w4>200)w4=200;
    note(E_TARGET,1,w4,best);
    last=get_ms_clock()|1;
    cal_learn(w4);
}
/* v24 hand-off: the half-press (HOLD AF) is let go early on purpose - "close enough, continuous finishes it".
   What quick AF saw on the way is used instead of thrown away:
   1. if it already passed a clearly sharper spot (best >= 1.15x where it is now), glide straight back there
      (to where the lens was when that frame was shown: frame time minus Canon's delay);
   2. continuous starts gliding the way that was getting sharper (no wrong-way look first). */
static void glide_handoff(void)
{
    /* v25: v24 went back to "the sharper spot" on almost every release and made things worse (CFAF13CE ->
       13CF, 13D5, 13D6): you let go when it LOOKS sharp, but the frames right at and after the release are not
       to be trusted - Canon's brightness number (v1) jumps up to 30x for a second around a half-press release
       (13CE: 9287 -> 28224 -> 595 -> 372), so the value "now" looked low and CFAF moved away from the good spot;
       the target was also shifted by the Sigma's doubtful 300 ms delay. Now only frames from before the
       release are used, the direction hand-off is the default, and going back (Release Hand-off = DIR + BACK)
       needs a 25 pct better spot, a steady v1, and uses at most a 150 ms delay. */
    int j,jb=-1,jn=-1,pb,dir,lag;uint32_t best=0,now_v,lim=hs_rel_ms?hs_rel_ms-80u:0u;
    if(!handoff_setting||gf_n<6)return;
    for(j=2;j<gf_n;j++){if(lim&&(int)(gf_t[j]-lim)>0)break;jn=j;{uint32_t m=g_sm(j);if(m>best){best=m;jb=j;}}}
    if(jn<4||jb<0)return;
    now_v=g_sm(jn);
    if(handoff_setting==2&&jb<jn-2&&above(best,now_v,2500))
    {   int sh=hs_run,sc=c_run;
        lag=g_lag>150?150:g_lag;
        pb=gl_pos_at(gf_t[jb-1]-(uint32_t)lag);
        if(pb!=gl_pos&&gl_pos-pb<200&&pb-gl_pos<200)
        {   hs_run=0;c_run=0;stop_code=0;
            dir=pb>gl_pos?1:-1;
            if(glide_to(pb)==0){c_first=dir;note(E_FINAL,dir,97,best);}
            hs_run=sh;c_run=sc;stop_code=S_GATE;
            return;
        }
    }
    {   uint32_t a=g_sm(jn>6?jn-4:2);
        if(gl_last)c_first=above(now_v,a,tol_bp)?gl_last:(below(now_v,a,tol_bp)?-gl_last:gl_last);
        note(E_FINAL,c_first,96,now_v);
    }
}
static int glide_run(void)
{
    int r,r2,dir=c_first?c_first:1,maxst=300,pk1=0,pk2=0,top,fb=cal_bucket(lens_info.focal_len);uint32_t v,vk1=0,vk2=0,vbest;
    if(c_mem_lens!=(int)lens_info.lens_id||c_mem_fb!=fb)
    {   c_mem=0;c_mem_lens=(int)lens_info.lens_id;c_mem_fb=fb;
        if(!g_from_probe)NotifyBox(3000,"CFAF: lens %d at %dmm not learned yet - Focus > CFAF Lens > Learn (works anyway)",lens_info.lens_id,lens_info.focal_len);
    }
    gl_pos=0;gl_last=0;gl_n=0;gf_n=0;units=0;gl_mark();g_fpos0=lens_info.focus_pos;g_p1i=0;g_p2i=-1;r2_ok=0;
    if(g_unit==2)maxst=150;
    if(!c_run){maxst=g_span>600?g_span:600;}                  /* quick AF: up to the whole travel (from the probe) */
    r=glide_pass(dir,1,0,maxst,&pk1,&vk1);if(r<0)return -1;
    note(E_LEVEL,dir,r,vk1);
    if(r==G_WRONG||((r==G_FLAT||r==G_WALL)&&(pk1==0||!above(vk1,v_start,g_dropbp()))))   /* no clear rise: other way */
    {   dir=-dir;g_p1i=gf_n;
        r=glide_pass(dir,0,0,maxst+(gl_pos<0?-gl_pos:gl_pos),&pk1,&vk1);if(r<0)return -1;
        note(E_LEVEL,dir,r,vk1);
    }
    if(r==G_PASSED)
    {   /* back through the top the other way at constant speed: the middle of the two peaks is the top */
        g_p2i=gf_n;
        r2=glide_pass(-dir,0,1,(gl_pos-pk1<0?pk1-gl_pos:gl_pos-pk1)+24,&pk2,&vk2);if(r2<0)return -1;
        note(E_LEVEL,-dir,r2,vk2);
        /* v19: the return pass found a clearly higher top (pass 1 jumped over the narrow real one with +/-3 / +/-2):
           pass again through that one, so the middle of two passes over the SAME top is used */
        {   int k;
            for(k=0;k<2&&r2==G_PASSED&&vk2>vk1+(vk1>>2);k++)
            {   pk1=pk2;vk1=vk2;dir=-dir;g_p1i=g_p2i;g_p2i=gf_n;
                r2=glide_pass(-dir,0,1,(gl_pos-pk1<0?pk1-gl_pos:gl_pos-pk1)+24,&pk2,&vk2);if(r2<0)return -1;
                note(E_LEVEL,-dir,r2,vk2);
            }
        }
        if(r2==G_PASSED)
        {   int ls=(pk1-pk2)*dir;r2_ok=1;                              /* = 2 x Canon's delay in steps */
            top=(pk1+pk2+(pk1+pk2>=0?1:0))>>1;
            if(ls>=0&&ls<=16)g_lag=(ls*g_ms1)>>1;                /* learned (shown in the log) */
        }
        else top=pk2;
    }
    else top=pk1;
    vbest=vk1>vk2?vk1:vk2;
    if(!vbest||(r!=G_PASSED&&!above(vbest,v_start,g_dropbp())))
    {   /* nothing better anywhere it looked: back to the start */
        if(glide_to(0)<0)return -1;
        if(c_ref&&!below(v_start,c_ref,5000)){if(g_read(&v)<0)return -1;v_final=v;note(E_FINAL,0,0,v);return 0;}
        /* quick AF: lower (or the same) both ways and not far out = the start is the top */
        if(!c_run&&(!norm_setting||v_start>=2458u)&&above(v_start,v_min,2000)){if(g_read(&v)<0)return -1;v_final=v;note(E_FINAL,0,0,v);if(v>c_mem)c_mem=v;return 0;}
        g_check_stuck();
        fail(S_NOHILL);return -1;
    }
    note(E_TARGET,0,top,vbest);
    if(glide_to(top)<0)return -1;
    if(g_read(&v)<0)return -1;
    if(below(v,vbest,1500)&&g_polish(&v)<0)return -1;          /* under 85 pct of the best seen: look +/-1, +/-2 */
    if(below(v,vbest,2500)&&g_polish_wide(&v)<0)return -1;     /* v17: still under 75 pct: look -4..+4 (CFAF8171) */
    v_final=v;note(E_FINAL,0,gl_pos,v);
    if(norm_setting&&v<2458u&&!above(v,v_min,10000)){fail(S_NOHILL);return -1;}   /* far out: not a focus */
    if(below(v,vbest,2500)){fail(S_NOHILL);return -1;}         /* < 75 pct of the best it saw: stay, next run goes on */
    if(r!=G_PASSED&&c_mem&&below(v,c_mem,5000)){fail(S_NOHILL);return -1;}   /* never passed a top, still soft */
    if(v>c_mem)c_mem=v;
    if(r2_ok)g_learn_zone();
    return 0;
}
/* parameters measured by CFAF Probe Lens: ML/CFAFGLD.TXT  lens_id,focal_bucket,c1x4,c2x4,bk1x4,lag_ms,ms1,noise_bp,range,k21x4 */
#define GP_N 32
static int gp[GP_N][10],gp_n=0,gp_loaded=0;
static void gp_load(void)
{
    int h,len,i,st,k,c,v[10];
    gp_loaded=1;gp_n=0;
    h=FIO_OpenFile("ML/CFAFGLD.TXT",010000u);
    if(h==0||h==-1)return;
    len=FIO_ReadFile(h,cal_buf,sizeof(cal_buf)-1);FIO_CloseFile(h);
    if(len<=0)return;if(len>(int)sizeof(cal_buf)-1)len=(int)sizeof(cal_buf)-1;cal_buf[len]=0;
    for(st=0,i=0;i<=len&&gp_n<GP_N;i++)
    {   if(i<len&&cal_buf[i]!='\n')continue;
        for(k=0,c=st;k<10;)
        {   int val=0,dig=0;
            while(c<i&&cal_buf[c]>='0'&&cal_buf[c]<='9'){val=val*10+(cal_buf[c]-'0');c++;dig=1;if(val>1000000)val=1000000;}
            if(!dig)break;
            v[k++]=val;
            if(c<i&&cal_buf[c]==',')c++;else break;
        }
        if(k==10){int j;for(j=0;j<10;j++)gp[gp_n][j]=v[j];gp_n++;}
        st=i+1;
    }
}
static int gp_find(void){int i,fb=cal_bucket(lens_info.focal_len);for(i=0;i<gp_n;i++)if(gp[i][0]==(int)lens_info.lens_id&&gp[i][1]==fb)return i;return -1;}
/* v17: a zoom probed at another focal length: use the nearest one (within 15 mm) of the same lens */
static int gp_find_near(void)
{   int i,b=-1,bd=100000,fb=cal_bucket(lens_info.focal_len),d;
    /* v23: the motor of a zoom behaves much the same at every focal length - use the nearest learned one of the
       same lens at any distance (v17-v22: only within 15 mm, so the Sigma at 92-300 mm used the defaults) */
    for(i=0;i<gp_n;i++)if(gp[i][0]==(int)lens_info.lens_id){d=gp[i][1]-fb;if(d<0)d=-d;if(d<bd){bd=d;b=i;}}
    return b;
}
static void gp_apply(void)
{
    int i;
    if(!gp_loaded)gp_load();
    g_lag=g_lag_def;g_bk=g_bk_def;g_k21=4;g_nz=0;g_from_probe=0;g_unit=g_unit_def;g_k3u=0;g_span=0;
    if(!cal_loaded)cal_load();
    {   /* +/-3 for the far search: only when Calibrate measured it landing within 1 +/-2 step */
        int ci,b=-1,bd=16,fb=cal_bucket(lens_info.focal_len),d;
        for(ci=0;ci<cal_n;ci++)if(cal_lens[ci]==(int)lens_info.lens_id&&cal_k3x4[ci]>0){d=cal_fb[ci]-fb;if(d<0)d=-d;if(d<bd){bd=d;b=ci;}}
        if(b>=0&&cal_k3x4[b]>=8&&cal_rev[b]<=4)g_k3u=cal_k3x4[b];          /* x4 +/-2 steps, scaled below */
    }
    i=gp_find_near();
    if(i<0){if(cal_hw>=4)g_unit=2;if(g_k3u)g_k3u=g_unit==2?((g_k3u+2)>>2):((g_k3u*g_k21+2)>>2);return;}
    g_from_probe=gp[i][1]==cal_bucket(lens_info.focal_len)?1:2;   /* 2 = from a nearby focal length */
    g_bk=(gp[i][4]+2)>>2;if(g_bk>6)g_bk=6;
    g_lag=gp[i][5];if(g_lag>300)g_lag=300;
    g_nz=gp[i][7];
    g_k21=(gp[i][9]+2)>>2;if(g_k21<2)g_k21=2;if(g_k21>10)g_k21=10;
    /* v18: a slow focus motor (Sigma 18-300: 196 ms per +/-1, ~165 ms per +/-2) glides in +/-2 steps -
       ~4x the distance in about the same time. Fast motors (17-55: 27 ms per +/-1) keep the fine +/-1 */
    if(gp[i][6]>=120)g_unit=2;
    /* v22: a lens whose sharp zone is wide compared with a +/-2 step (50 STM: half-width ~5 +/-2 steps = ~40
       +/-1 steps; +/-1 is only 3 encoder counts) glides in +/-2: quick AF in CFAF06C5 took 147 +/-1 steps / 14 s
       and was let go before the top. The 17-55 at 55 mm (half-width ~2 +/-2) keeps +/-1. */
    if(cal_hw>=4)g_unit=2;
    if(g_k3u)g_k3u=g_unit==2?((g_k3u+2)>>2):((g_k3u*g_k21+2)>>2);                /* +/-3 in position units */
    /* whole travel in position units (for quick AF), from the probe's range */
    if(gp[i][8]>0&&gp[i][2]>0)
    {   int u1=(int)divu((uint32_t)gp[i][8]*4u,(uint32_t)gp[i][2]);           /* travel in +/-1 steps */
        g_span=(g_unit==2?(int)divu((uint32_t)u1,(uint32_t)g_k21):u1)+20;if(g_span>4000)g_span=4000;
    }
}
static void gp_write(void);
static void gp_save(int *row)
{
    int i,j,fb=cal_bucket(lens_info.focal_len);
    if(!gp_loaded)gp_load();
    i=gp_find();
    if(i<0){if(gp_n>=GP_N)i=GP_N-1;else i=gp_n++;}
    for(j=0;j<10;j++)gp[i][j]=row[j];
    gp[i][0]=(int)lens_info.lens_id;gp[i][1]=fb;
    gp_write();
}
static void gp_write(void)
{
    int h,i,j;char *o=cal_buf;
    for(i=0;i<gp_n&&o<cal_buf+sizeof(cal_buf)-120;i++)
    {   for(j=0;j<10;j++){if(j)*o++=',';cal_put(&o,gp[i][j]);}*o++='\n';}
#ifndef UNIT_TEST
    h=FIO_CreateFile("ML/CFAFGLD.TXT");
    if(h>0){FIO_WriteFile(h,cal_buf,(unsigned)(o-cal_buf));FIO_CloseFile(h);}
#else
    (void)h;
#endif
}


/* ---------------- CFAF Probe Lens (v15): how does this lens actually move? ----------------
   The 5D3 reports the lens's focus encoder (lens_info.focus_pos) - but only ~4 times a second (probe 30 Oct:
   updates every ~250 ms), so "still" here = no change for 600 ms. A second task records the encoder, Canon's
   value and Canon's "focus done" count every ~10 ms. Tests:
   T7 noise: Canon's value with the lens still (frame to frame spread)
   T1 single steps +/-1, +/-2, +/-3 (2 forward, 2 back): encoder counts per step
   T2 runs of waited steps with extra pauses 0 / 40 / 100 ms: time per command, counts, longest stall
   T3 runs of NOT-waited steps 20 / 50 / 100 ms apart: lost steps (30 Oct: lost at 20 ms - not used)
   T4 backlash of +/-1: 10 steps, 10 more, 10 back, 10 back, 10 forward - read the encoder after each
   T6 range: +/-2 to the + end, then the whole way to the - end reading every frame (coarse focus peak)
   T5 GLIDE sweep (around that peak): +/-1 rapid fire through the sharp zone up and down, every frame read.
      The peak is seen later than the lens passed it (Canon's lag); the lag that makes the up and the down
      sweep agree is what GLIDE uses to know where the lens was when a frame was taken. Also the zone width.
   then back to the focus found in T5 (or to the start) by the encoder.
   Saves the GLIDE parameters for this lens + focal length in ML/CFAFGLD.TXT (used at once) and the full
   log ML/CFPxxxxx.CSV. */
#define PRB_N 4000
#define PRB_R 64
#define PRB_C 11
static int prb_last_ok=0;
static volatile int prb_on=0,prb_test=0,prb_size=0,prb_delay=0,prb_wait=0,prb_cmd=0;
static volatile uint32_t done_cnt=0,lensu_cnt=0;
static uint32_t prb_ms[PRB_N];static int16_t prb_pos[PRB_N];static uint8_t prb_tag[PRB_N][4];static uint16_t prb_cmdn[PRB_N];
static uint32_t prb_val[PRB_N];static uint16_t prb_done[PRB_N];
static volatile int prb_n=0;static uint32_t prb_t0=0;
static int prr[PRB_R][PRB_C],prr_n=0;     /* test,size,delay,wait,n,ms,dpos,expected,max_stall,start_ms,ms_per_cmd */
static int pc[4],pbk=0,psign=0;           /* counts per step for +/-1,2,3, backlash (+/-1 steps x4), encoder sign */
static int pr_c1x4=0,pr_c2x4=0,pr_lag=-1,pr_ms1=0,pr_nz=0,pr_range=0,pr_k21x4=0,pr_up=0,pr_dn=0,pr_zone=0,pr_peak=0,pr_end_a=0,pr_end_b=0,pr_focus=-99999;
static int pr_lags[31];                   /* lag scan: |up peak - down peak| for 0..300 ms */
static void done_handler(unsigned int property,void *priv,uint32_t *buf,unsigned int len){(void)property;(void)priv;(void)buf;(void)len;done_cnt++;}
static void lensu_handler(unsigned int property,void *priv,uint32_t *buf,unsigned int len){(void)property;(void)priv;(void)buf;(void)len;lensu_cnt++;}
static module_prophandler_t done_block={"PROP_LV_FOCUS_DONE",done_handler,0x80050002u,0};
static module_prophandler_t lensu_block={"PROP_LV_LENS",lensu_handler,0x80050000u,0};
static void prb_rec(void)
{
    int n=prb_n;if(n>=PRB_N)return;
    prb_ms[n]=get_ms_clock()-prb_t0;prb_pos[n]=(int16_t)lens_info.focus_pos;
    prb_tag[n][0]=(uint8_t)prb_test;prb_tag[n][1]=(uint8_t)prb_size;prb_tag[n][2]=(uint8_t)(prb_delay>255?255:prb_delay);prb_tag[n][3]=(uint8_t)prb_wait;
    prb_cmdn[n]=(uint16_t)prb_cmd;prb_val[n]=cfd_v[2]+cfd_v[3];prb_done[n]=(uint16_t)done_cnt;
    prb_n=n+1;
}
static volatile int prb_task_alive=0;
static void prb_sampler(void *u)
{
    int lp=-99999,lc=-1,lt=-1;uint32_t last=0,ls=0;(void)u;
    prb_task_alive=1;
    while(prb_on)
    {   uint32_t now=get_ms_clock();
        if(lens_info.focus_pos!=lp||prb_cmd!=lc||prb_test!=lt||((prb_test==5||prb_test==7)&&cfd_seq!=ls)||now-last>=100u)
        {   lp=lens_info.focus_pos;lc=prb_cmd;lt=prb_test;ls=cfd_seq;last=now;prb_rec();}
        msleep(10);
    }
    prb_task_alive=0;
}
/* wait until the encoder has not changed for quiet ms (max maxms); returns the position */
static int prb_still(int quiet,int maxms)
{
    uint32_t t=get_ms_clock(),tc=t;int p=lens_info.focus_pos;
    keep_awake();
    while((int)(get_ms_clock()-t)<maxms)
    {   msleep(10);
        if(lens_info.focus_pos!=p){p=lens_info.focus_pos;tc=get_ms_clock();}
        else if((int)(get_ms_clock()-tc)>=quiet)break;
    }
    return lens_info.focus_pos;
}
#define STILL() prb_still(600,4000)
static int prb_abort(void){return worker_exit||cancel_request||!lv||is_manual_focus()||get_halfshutter_pressed();}
static int prb_stall(int a,int b)
{
    int i,m=0;uint32_t lt=a<prb_n?prb_ms[a]:0;
    for(i=a+1;i<b&&i<prb_n;i++)if(prb_pos[i]!=prb_pos[i-1]){int g=(int)(prb_ms[i]-lt);if(g>m)m=g;lt=prb_ms[i];}
    return m;
}
static void prb_result(const int *v)
{   int j;if(prr_n>=PRB_R)return;for(j=0;j<PRB_C;j++)prr[prr_n][j]=v[j];prr_n++;}
/* one run: n steps of size in dir, waited or not. Records a result. 0 ok, -1 abort, 1 end stop */
static int prb_run(int test,int size,int dir,int n,int wait,int delay)
{
    int i,p0,p1,a,ok=1,res[PRB_C];uint32_t t,tf=0,tl=0;
    prb_test=test;prb_size=size;prb_delay=delay;prb_wait=wait;
    p0=STILL();a=prb_n;t=get_ms_clock();
    for(i=0;i<n;i++)
    {   if(prb_abort())return -1;
        prb_cmd++;
        if(!lens_focus(1,dir*size,wait,wait?delay:(delay<10?10:delay))){ok=0;break;}
        if(!i)tf=get_ms_clock();tl=get_ms_clock();
    }
    p1=STILL();
    res[0]=test;res[1]=size;res[2]=delay;res[3]=wait;res[4]=n;res[5]=(int)(get_ms_clock()-t);res[6]=p1-p0;
    res[7]=(size<=3&&pc[size])?pc[size]*n*dir*psign:0;res[8]=prb_stall(a,prb_n);res[9]=(int)(t-prb_t0);
    res[10]=(i>1)?(int)divu(tl-tf,(uint32_t)(i-1)):0;
    prb_result(res);
    prb_test=0;
    return ok?0:1;
}
static int imed(int *a,int n){int i,j,t;for(i=1;i<n;i++)for(j=i;j>0&&a[j]<a[j-1];j--){t=a[j];a[j]=a[j-1];a[j-1]=t;}return n?a[n>>1]:0;}
static void prb_csv(int ok);
/* drive to encoder position p: bursts of +/-2 then +/-1 computed from the counts, re-read, up to 8 rounds */
static void prb_home(int p)
{
    int k,d,n,c1,c2;
    prb_test=9;
    c1=pr_c1x4?((pr_c1x4+2)>>2):pc[1];c2=pc[2];
    if(!psign||c1<=0)return;
    for(k=0;k<8&&!prb_abort();k++)
    {   d=p-STILL();
        if(c2>0&&(n=divs(d*3,c2*4))!=0)            /* 3/4 of the way in +/-2 (no overshoot), then finish */
        {   int dir=n>0?1:-1;if(n<0)n=-n;while(n--&&!prb_abort()){prb_cmd++;lens_focus(1,dir*psign*2,1,0);}}
        else if((n=divs(d,c1))!=0)
        {   int dir=n>0?1:-1;if(n<0)n=-n;while(n--&&!prb_abort()){prb_cmd++;lens_focus(1,dir*psign,1,0);}}
        else break;
    }
    prb_test=0;
}
/* T5 helper: one +/-1 step (backlash taken up on a reversal), position counted in gl_* */
static int pstep(int dir)
{
    int i;
    if(prb_abort())return -1;
    if(gl_last&&dir!=gl_last)for(i=0;i<g_bk;i++){prb_cmd++;lens_focus(1,dir,1,0);}
    gl_last=dir;prb_cmd++;
    if(!lens_focus(1,dir,1,0))return 0;
    gl_pos+=dir;gl_mark();
    if(gpoll()<0)return -1;
    return 1;
}
/* T5: peak of a sweep (frames in [ta,tb)) with lag L: median-of-3 smoothed, returns the position, *pv value */
static int sweep_peak(uint32_t ta,uint32_t tb,int L,uint32_t *pv,int *w)
{
    int i,k=0,bp=0,lo=99999,hi=-99999;uint32_t best=0,a[3],m;
    for(i=0;i<gf_n;i++)
    {   uint32_t t=gf_t[i]-(uint32_t)L;
        if((int)(t-ta)<0||(int)(t-tb)>=0)continue;
        a[k%3]=gf_v[i];k++;
        if(k<3)continue;
        {uint32_t x=a[0],y=a[1],z=a[2],q;if(x>y){q=x;x=y;y=q;}if(y>z){q=y;y=z;z=q;}if(x>y){q=x;x=y;y=q;}m=y;}
        if(m>best){best=m;bp=gl_pos_at(gf_t[i>0?i-1:0]-(uint32_t)L);}
    }
    *pv=best;
    if(w)
    {   uint32_t lim=best-(best>>2)-(best>>5);k=0;      /* ~72 pct */
        for(i=0;i<gf_n;i++)
        {   uint32_t t=gf_t[i]-(uint32_t)L;int p;
            if((int)(t-ta)<0||(int)(t-tb)>=0)continue;
            if(gf_v[i]>=lim){p=gl_pos_at(t);if(p<lo)lo=p;if(p>hi)hi=p;}
        }
        *w=hi>=lo?hi-lo:0;
    }
    return bp;
}
static int prb_sweep(void)
{
    int N,i,r,L,bestd=99999;uint32_t ta,tb,tc,td,v;
    prb_test=5;
    N=cal_hw>0?cal_hw*((pr_k21x4+2)>>2)*3/2:24;if(N<16)N=16;if(N>120)N=120;
    gl_pos=0;gl_last=0;gl_n=0;gf_n=0;g_lag=0;g_bk=(pbk+2)>>2;ref_v1=0;used_seq=cfd_seq;gl_mark();
    for(i=0;i<N;i++){r=pstep(-1);if(r<0)return -1;if(!r)break;}
    if(g_pause(300)<0)return -1;
    ta=get_ms_clock();
    for(i=0;i<2*N;i++){r=pstep(1);if(r<0)return -1;if(!r)break;}
    tb=get_ms_clock();
    if(g_pause(300)<0)return -1;
    tc=get_ms_clock();
    for(i=0;i<2*N;i++){r=pstep(-1);if(r<0)return -1;if(!r)break;}
    td=get_ms_clock();
    if(g_pause(300)<0)return -1;
    for(L=0;L<=300;L+=10)
    {   int pu=sweep_peak(ta,tb+400,L,&v,0),pd=sweep_peak(tc,td+400,L,&v,0),d=pu-pd;if(d<0)d=-d;
        pr_lags[L/10]=d;
        if(d<bestd){bestd=d;pr_lag=L;pr_up=pu;pr_dn=pd;}
    }
    pr_up=sweep_peak(ta,tb+400,pr_lag,&v,&pr_zone);pr_peak=(int)v;pr_dn=sweep_peak(tc,td+400,pr_lag,&v,0);
    /* glide to the found peak (between the two), read the encoder there = the focus position */
    {   int t=(pr_up+pr_dn)>>1;
        while(gl_pos!=t){r=pstep(t>gl_pos?1:-1);if(r<0)return -1;if(!r)break;}
    }
    pr_focus=STILL();
    prb_test=0;
    return 0;
}
static void probe_lens(void)
{
    int s,i,r=0,p0,d[8],nd,dl,rev[4]={0,0,0,0},sv_c=c_run,sv_h=hs_run;
    static const int dly[3]={0,40,100},nw[3]={20,50,100};
    prb_n=0;prr_n=0;pc[0]=pc[1]=pc[2]=pc[3]=0;pbk=0;psign=0;prb_cmd=0;prb_test=0;
    pr_c1x4=pr_c2x4=pr_ms1=pr_nz=pr_range=pr_k21x4=pr_up=pr_dn=pr_zone=pr_peak=pr_end_a=pr_end_b=0;pr_lag=-1;pr_focus=-99999;
    for(i=0;i<31;i++)pr_lags[i]=-1;
    if(!lv||is_manual_focus()||is_continuous_af()||!lens_info.lens_exists)
    {   NotifyBox(4000,"CFAF probe: needs LiveView, lens on AF, Canon's continuous AF (Servo) off");return;}
    if(!cal_loaded)cal_load();
    {int ci=cal_find();cal_hw=ci>=0?((cal_w4[ci]+2)>>2):0;}
    prb_t0=get_ms_clock();prb_on=1;
    task_create("cfaf_prb",28,4096,prb_sampler,0);
    for(i=0;i<50&&!prb_task_alive;i++)msleep(10);
    p0=STILL();
    /* T7: noise, lens still: 30 frames */
    {   int a[30],n=0;uint32_t sq=cfd_seq,t=get_ms_clock();prb_test=7;
        while(n<30&&(int)(get_ms_clock()-t)<3000){msleep(10);if(cfd_seq!=sq){sq=cfd_seq;if(cfd_v[2]|cfd_v[3])a[n++]=(int)((cfd_v[2]+cfd_v[3])>>4);}}
        if(n>=10){imed(a,n);pr_nz=a[n>>1]>0?divs((a[n-1-n/10]-a[n/10])*10000,a[n>>1]):0;}
        prb_test=0;
    }
    /* T1: single waited steps, 2 forward + 2 back per size */
    for(s=1;s<=3&&!r;s++)
    {   int dir,k;nd=0;
        for(k=0;k<4&&!r;k++)
        {   int b;dir=k<2?1:-1;
            r=prb_run(1,s,dir,1,1,0);if(r)break;
            b=prr[prr_n-1][6];
            if(!psign&&b)psign=(b>0)==(dir>0)?1:-1;
            if(k==2)rev[s]=b;
            else if(b)d[nd++]=b<0?-b:b;
        }
        pc[s]=imed(d,nd);
        NotifyBox(1500,"CFAF probe: +-%d step = %d encoder counts",s,pc[s]);
    }
    if(!psign)psign=-1;
    if(r<0)goto out;
    r=0;
    /* T2: waited runs out and back */
    for(s=1;s<=3&&r>=0;s++)
    {   int n=s==1?8:(s==2?4:1);
        for(dl=0;dl<3&&r>=0;dl++)
        {   NotifyBox(1500,"CFAF probe: %d x +-%d, pause %d ms",n,s,dly[dl]);
            r=prb_run(2,s,1,n,1,dly[dl]);if(r<0)break;
            r=prb_run(2,s,-1,n,1,dly[dl]);
            if(s==1&&dl==0&&r>=0)pr_ms1=prr[prr_n-1][10];
            if(s==2&&dl==2&&r>=0){int a=prr[prr_n-1][6],b=prr[prr_n-2][6];if(a<0)a=-a;if(b<0)b=-b;pr_c2x4=(a+b+1)>>1;}   /* x4 = per 4 steps */
        }
        prb_home(p0);
    }
    if(r<0)goto out;
    /* T3: not-waited runs */
    for(s=1;s<=2&&r>=0;s++)
    {   int n=s==1?8:4;
        for(dl=0;dl<3&&r>=0;dl++)
        {   NotifyBox(1500,"CFAF probe: no-wait %d x +-%d every %d ms",n,s,nw[dl]);
            r=prb_run(3,s,1,n,0,nw[dl]);if(r<0)break;
            r=prb_run(3,s,-1,n,0,nw[dl]);
            prb_home(p0);
        }
    }
    if(r<0)goto out;
    /* T4: +/-1 backlash: 10 +, 10 + (reference), 10 - (reversal), 10 -, 10 + (reversal) */
    {   int e[6],k,c,l1,l2;static const int dd[5]={1,1,-1,-1,1};
        NotifyBox(1500,"CFAF probe: backlash of +-1");
        prb_test=4;prb_size=1;e[0]=STILL();
        for(k=0;k<5&&r>=0;k++)
        {   for(i=0;i<10;i++){if(prb_abort()){r=-1;break;}prb_cmd++;lens_focus(1,dd[k],1,0);}
            e[k+1]=STILL();
        }
        prb_test=0;
        if(r<0)goto out;
        c=e[2]-e[1];if(c<0)c=-c;
        {int c2=e[4]-e[3];if(c2<0)c2=-c2;c=(c+c2+1)>>1;}                      /* same-direction tens */
        pr_c1x4=divs(c*4,10);
        l1=e[3]-e[2];if(l1<0)l1=-l1;l2=e[5]-e[4];if(l2<0)l2=-l2;
        if(c>0){pbk=divs(((c-l1)+(c-l2))*4*10,2*c);if(pbk<0)pbk=0;}       /* x4, in +/-1 steps */
        {int res[PRB_C]={4,1,0,1,10,0,c,l1,l2,0,pbk};res[9]=(int)(get_ms_clock()-prb_t0);prb_result(res);}
        if(pr_c1x4>0&&pr_c2x4>0)pr_k21x4=divs(pr_c2x4*4,pr_c1x4);                       /* c2x4 = 4 steps, c1x4 = per step x4 */
        prb_home(p0);
    }
    /* T6: range, then a coarse +/-2 sweep end to end (v16: finds the focus without the normal AF, which failed in
       CFP3C092 - T5 was skipped). The lens goes to the + end, then all the way to the - end reading every frame. */
    {   int k,M=0,pkc;uint32_t ta,tb,v;
        NotifyBox(2500,"CFAF probe: whole focus travel (ML may say 'soft limit' at the ends - that is expected)");
        prb_test=6;prb_size=2;
        ew_reset();
        for(k=0;k<600&&!prb_abort();k++){prb_cmd++;if(!lens_focus(1,2,1,0))break;if(ew_end())break;}   /* refusal or encoder = end */
        pr_end_a=STILL();
        gl_pos=0;gl_last=0;gl_n=0;gf_n=0;ref_v1=0;used_seq=cfd_seq;gl_mark();
        ta=get_ms_clock();
        ew_reset();
        for(k=0;k<1200&&!prb_abort();k++)
        {   prb_cmd++;if(!lens_focus(1,-2,1,0))break;
            if(ew_end()){M-=ew_n-1;gl_pos+=ew_n-1;break;}        /* the last few commands did not move it */
            gl_pos--;gl_mark();M++;
            if(gpoll()<0)break;
        }
        tb=get_ms_clock();
        g_pause(300);
        pr_end_b=STILL();
        pr_range=pr_end_a-pr_end_b;if(pr_range<0)pr_range=-pr_range;
        pkc=sweep_peak(ta,tb+400,0,&v,0);                    /* in +/-2 steps from the + end (negative) */
        prb_test=0;
        {int res[PRB_C]={6,2,0,1,M,0,pr_end_a,pr_end_b,pr_range,0,pkc};res[9]=(int)(get_ms_clock()-prb_t0);prb_result(res);}
        if(prb_abort()){r=-1;goto out;}
        /* back up to the coarse peak (seen a little late, so the lens passed it: one +/-2 further back) */
        if(v&&pkc<0)
        {   int n=(gl_pos<pkc?pkc-gl_pos:0)+1;
            for(k=0;k<n&&!prb_abort();k++){prb_cmd++;lens_focus(1,2,1,0);}
            /* T5: +/-1 glide sweeps up and down through it */
            NotifyBox(2000,"CFAF probe: glide sweeps through focus");
            if(prb_sweep()<0){r=-1;goto out;}
            {int res[PRB_C]={5,1,pr_lag,1,0,0,pr_up,pr_dn,pr_zone,0,pr_peak};res[9]=(int)(get_ms_clock()-prb_t0);prb_result(res);}
        }
        else NotifyBox(3000,"CFAF probe: no focus peak found on the whole travel (detail in the AF box?)");
    }
out:
    if(r>=0||!prb_abort())prb_home(pr_focus!=-99999?pr_focus:p0);
    msleep(300);prb_on=0;
    for(i=0;i<50&&prb_task_alive;i++)msleep(10);
    if(r>=0&&pr_c1x4>0)
    {   int row[10];
        row[0]=0;row[1]=0;row[2]=pr_c1x4;row[3]=pr_c2x4;row[4]=pbk;row[5]=pr_lag>=0?pr_lag:100;row[6]=pr_ms1;row[7]=pr_nz;row[8]=pr_range;row[9]=pr_k21x4;
        gp_save(row);gp_loaded=0;
    }
    prb_csv(r>=0);prb_last_ok=r>=0;
    if(r<0)NotifyBox(5000,"CFAF probe stopped (half-press / MF / menu STOP) - partial log saved");
    else NotifyBox(12000,"CFAF probe done: +-1 = %d.%d counts, +-2 = %d +-1 steps, backlash %d.%d, lag %d ms. GLIDE tuned.",
        pr_c1x4>>2,(pr_c1x4&3)*25,(pr_k21x4+2)>>2,pbk>>2,(pbk&3)*25,pr_lag);
}
static void prb_csv(int ok)
{
    char path[20]="ML/CFP00000.CSV";static const char hx[]="0123456789ABCDEF";uint32_t x;int i,j;
    x=get_ms_clock()&0xFFFFFu;for(i=0;i<5;i++){path[10-i]=hx[x&15u];x>>=4;}
    oh=FIO_CreateFile(path);if(oh<=0){oh=0;return;}
    txt("# CFAF v25 lens probe [" CAM_MODEL " " CAM_FW "]. lens_id,");num(lens_info.lens_id);txt(",focal_mm,");num(lens_info.focal_len);
    txt(",ok,");snum(ok);txt(",counts_pm1_T1,");snum(pc[1]);txt(",counts_pm2_T1,");snum(pc[2]);txt(",counts_pm3_T1,");snum(pc[3]);
    txt(",encoder_sign,");snum(psign);
    txt("\n# GLIDE,c1_x4,");snum(pr_c1x4);txt(",c2_per4,");snum(pr_c2x4);txt(",backlash_pm1_x4,");snum(pbk);txt(",lag_ms,");snum(pr_lag);
    txt(",ms_per_pm1,");snum(pr_ms1);txt(",noise_bp,");snum(pr_nz);txt(",range_counts,");snum(pr_range);txt(",pm1_per_pm2_x4,");snum(pr_k21x4);
    txt(",sweep_up_peak,");snum(pr_up);txt(",sweep_down_peak,");snum(pr_dn);txt(",zone72_width_pm1,");snum(pr_zone);txt(",peak_value,");snum(pr_peak);
    txt(",end_a,");snum(pr_end_a);txt(",end_b,");snum(pr_end_b);txt(",focus_pos,");snum(pr_focus);
    txt("\n# LAGSCAN (|up peak - down peak| in +/-1 steps for lag 0,10..300 ms)");for(i=0;i<31;i++){ch(',');snum(pr_lags[i]);}
    txt("\n# test 7 noise, 1 single steps, 2 waited runs (delay = extra pause ms), 3 not-waited runs (delay = ms between commands), 4 backlash, 5 glide sweep, 6 range, 9 homing\n");
    txt("# RESULT,test,size,delay,wait,steps,ms,encoder_moved,expected,longest_stall_ms,start_ms,ms_per_cmd\n");
    txt("# (test 4: moved = counts per 10 same-way, expected / stall = counts after reversal 1 / 2, last = backlash x4)\n");
    txt("# (test 5: delay = lag ms, moved / expected = up / down peak +/-1 position, stall = 72 pct zone width, last = peak value)\n");
    txt("# (test 6: moved / expected = encoder at the + end / - end, stall = range)\n");
    for(i=0;i<prr_n;i++){txt("# RESULT");for(j=0;j<PRB_C;j++){ch(',');snum(prr[i][j]);}ch('\n');}
    txt("ms,test,size,delay,wait,cmd,focus_pos,canon_v2v3,focus_done_count\n");
    for(i=0;i<prb_n;i++)
    {   num(prb_ms[i]);for(j=0;j<4;j++){ch(',');num(prb_tag[i][j]);}ch(',');num(prb_cmdn[i]);ch(',');snum(prb_pos[i]);
        ch(',');num(prb_val[i]);ch(',');num(prb_done[i]);ch('\n');
    }
    txt("# PROP_LV_LENS updates,");num(lensu_cnt);ch('\n');
    if(gf_n){txt("# T5 frames: ms,value,cmd_pos_at_frame (no lag)\n");for(i=0;i<gf_n;i++){txt("# F,");num(gf_t[i]-prb_t0);ch(',');num(gf_v[i]);ch(',');snum(gl_pos_at(gf_t[i]));ch('\n');}}
    flush();FIO_CloseFile(oh);oh=0;
}


/* ---------------- v17 lens library: learn / status / forget (menu CFAF Lens) ----------------
   Everything CFAF learns about a lens is kept on the card per lens + focal length and used at once:
   ML/CFAFGLD.TXT (Probe Lens: GLIDE motion) and ML/CFAFCAL.TXT (Calibrate Lens + learned sharp-zone width).
   A zoom learned at one focal length is used at the nearest learned one (within 15 mm) until learned there too.
   Swap lenses in the field: Learn Lens once per lens (and a few focal lengths on a zoom), nothing else to do. */
static CONFIG_INT("cfaf.learn",learn_request,0);
static CONFIG_INT("cfaf.lstat",lstat_request,0);
static CONFIG_INT("cfaf.forget",forget_request,0);
static void lens_status(int ms)
{
    int gi,ci,fb=cal_bucket(lens_info.focal_len);
    if(!gp_loaded)gp_load();if(!cal_loaded)cal_load();
    gi=gp_find_near();ci=cal_find_near();
    if(gi<0&&ci<0){NotifyBox(ms,"CFAF lens %d at %dmm: NOT LEARNED - Lens > Learn Lens (works anyway, with guesses)",lens_info.lens_id,lens_info.focal_len);return;}
    NotifyBox(ms,"CFAF lens %d at %dmm: motion %s%dmm (+-2 = %d +-1, slack %d), map %s%dmm (sharp zone %d steps%s)",
        lens_info.lens_id,lens_info.focal_len,
        gi<0?"none ":(gp[gi][1]==fb?"":"from "),gi<0?0:gp[gi][1],gi<0?0:(gp[gi][9]+2)>>2,gi<0?0:(gp[gi][4]+2)>>2,
        ci<0?"none ":(cal_fb[ci]==fb?"":"from "),ci<0?0:cal_fb[ci],ci<0?0:(cal_w4[ci]+2)>>2,(ci>=0&&cal_k3x4[ci])?", calibrated":"");
}
static void lens_forget(void)
{
    int i,j,n,fb=cal_bucket(lens_info.focal_len);
    if(!gp_loaded)gp_load();if(!cal_loaded)cal_load();
    for(i=0,n=0;i<gp_n;i++)if(!(gp[i][0]==(int)lens_info.lens_id&&gp[i][1]==fb)){for(j=0;j<10;j++)gp[n][j]=gp[i][j];n++;}
    gp_n=n;gp_write();
    for(i=0,n=0;i<cal_n;i++)if(!(cal_lens[i]==(int)lens_info.lens_id&&cal_fb[i]==fb))
    {   cal_lens[n]=cal_lens[i];cal_fb[n]=cal_fb[i];cal_w4[n]=cal_w4[i];cal_cnt[n]=cal_cnt[i];cal_k3x4[n]=cal_k3x4[i];cal_rev[n]=cal_rev[i];
        cal_b4[n]=cal_b4[i];cal_k1x4[n]=cal_k1x4[i];cal_t2[n]=cal_t2[i];cal_t3[n]=cal_t3[i];cal_nz[n]=cal_nz[i];n++;}
    cal_n=n;cal_save();c_mem=0;
    NotifyBox(4000,"CFAF: forgot lens %d at %dmm (other focal lengths and lenses kept)",lens_info.lens_id,lens_info.focal_len);
}
/* ---------------- continuous AF (menu CFAF Continuous) ----------------
   Watches Canon's sharpness every frame while nothing else runs. Reference = the value at the end of the last
   focus run (raised when the picture gets sharper by itself). When the median of the last 5 frames stays below
   the reference by the sensitivity drop for 0.5 s, it refocuses: no settling, the direction that worked last
   time first, +/-2 steps in short strides (less visible overshoot), the big jumps only if it is far out.
   After a run: 1 s pause (3 s after a failed one, and the reference becomes what it sees, so it does not hunt). */
static uint32_t c_seq=0,c_low_ms=0,c_cool=0,c_hist[5],c_v1lo=0,c_v1hi=0,c_mlo=0,c_mhi=0;static int c_n=0;
static void watch_reset(void){c_n=0;c_low_ms=0;c_v1lo=c_v1hi=0;}
static int c_fails=0;
/* a run that did not end OK (not let go by the user): put the lens back where it started, if the +/-2 count is
   still valid (no big jumps). 21 Oct logs: 25 continuous runs ended "no focus" at 25-70 pct of where they began
   (12676 -> 4740) - the picture was left worse than before. */
static void restore_start(void)
{
    int n=p2,i,dir;
    if(levels_used&8)return;                 /* +/-3 used: position count lost */
    if(!n)return;
    dir=n>0?-1:1;if(n<0)n=-n;
    for(i=0;i<n&&!worker_exit;i++){if(!lens_focus(1,dir*2,1,10)){msleep(150);lens_focus(1,dir*2,1,10);}}
    note(E_FINAL,dir,99,0);
}
/* quick AF let go before it finished (21 Oct: 50 of 70 half-press runs, mostly after 1-2.5 s, often with a much
   sharper position already seen: 1C8A 8526 -> 20486, 1CB2 2480 -> 38934): finish by going to the best +/-2
   position it has read, if the count is still valid and it is clearly better than where the lens is now */
static void goto_best_on_release(void)
{
    int n,i,dir;uint32_t now_v=p2>-PO&&p2<PO?pv[p2+PO]:0;
    if(levels_used&8)return;
    if(bp==p2||!bv)return;
    if(now_v&&!above(bv,now_v,1500))return;
    n=bp-p2;dir=n>0?1:-1;if(n<0)n=-n;
    if(n>20)return;
    for(i=0;i<n&&!worker_exit;i++){if(!lens_focus(1,dir*2,1,10)){msleep(150);lens_focus(1,dir*2,1,10);}}
    p2=bp;note(E_FINAL,dir,98,bv);
}
static void watch_after_run(void)
{
    uint32_t cool;
    if(stop_code==S_OK){c_ref=v_final;if(units)c_first=units>0?1:-1;c_fails=0;}
    else
    {   if(stop_code==S_NOHILL)c_ref=0;
        if(stop_code!=S_GATE)c_fails++;
    }
    /* back off after failures in a row (21 Oct: left on all night with the lens cap on = 6649 runs, one every
       ~4 s, each nudging the lens): 1 s after OK, then 3 s, 10 s, 30 s, 60 s */
    cool=stop_code==S_OK?1000u:(c_fails<=1?3000u:(c_fails==2?10000u:(c_fails==3?30000u:60000u)));
    if(calways_setting)cool=stop_code==S_OK?0u:1000u;            /* C-Mode ALWAYS: no pause, short one after a failure */
    c_cool=get_ms_clock()+cool;
    watch_reset();
}
static int watch(void)
{
    uint32_t v,m,a[5],now=get_ms_clock(),v1;int i,j,drop_bp,wait_ms;
    if(c_cool&&(int)(now-c_cool)<0)return 0;
    if(cfd_seq==c_seq)return 0;
    if((int)(now-cfd_ms)>300){watch_reset();return 0;}
    c_seq=cfd_seq;
    if(!cfd_v[1]||!(cfd_v[2]|cfd_v[3]))return 0;                 /* all-zero frame: ignore */
    v=cur_value();
    c_hist[c_n%5]=v;c_n++;
    if(c_n<5)return 0;
    for(i=0;i<5;i++)a[i]=c_hist[i];
    for(i=1;i<5;i++)for(j=i;j>0&&a[j-1]>a[j];j--){uint32_t t=a[j];a[j]=a[j-1];a[j-1]=t;}
    m=a[2];
    if(norm_setting&&m<400u){c_low_ms=0;c_kick=0;if(!c_ref)c_ref=m;return 0;}   /* no detail (sky, wall, cap): wait */
    /* v17: just switched on (menu, AF-point button, half-press toggle, module start) or nothing known: look now.
       v16 took whatever it saw first as "in focus" and only moved after it got 4 pct softer than THAT. */
    if(c_kick||(!c_ref&&calways_setting)){c_kick=0;c_run=1;hs_released=0;return 1;}
    if(!c_ref){c_ref=m;return 0;}                                 /* ON DROP: first look = reference */
    if(m>c_ref)c_ref+=(m-c_ref)>>3;                               /* sharper by itself: follow up slowly */
    drop_bp=csens_setting==0?3500:(csens_setting==2?1500:2500);
    wait_ms=csens_setting==0?1000:(csens_setting==2?300:600);
    v1=cfd_v[1];
    if(calways_setting)
    {   /* glide: refocus when it got softer by 4 pct (or 3x Canon's noise) for 0.25 s - an in-focus picture
           wobbles 2-3 pct frame to frame (CFAF815B-8162 refocused every ~4 s for that) */
        int thr=g_nz*3>400?g_nz*3:400;
        if(!glide_setting){c_run=1;hs_released=0;return 1;}
        if(!below(m,c_ref,thr)){c_low_ms=0;return 0;}
        if(!c_low_ms){c_low_ms=now;return 0;}
        if((int)(now-c_low_ms)<250)return 0;
        c_low_ms=0;c_run=1;hs_released=0;return 1;
    }
    if(below(m,c_ref,drop_bp))
    {
        if(!c_low_ms){c_low_ms=now;c_v1lo=c_v1hi=v1;c_mlo=c_mhi=m;}
        if(v1<c_v1lo)c_v1lo=v1;if(v1>c_v1hi)c_v1hi=v1;
        if(m<c_mlo)c_mlo=m;if(m>c_mhi)c_mhi=m;
        /* the soft picture must also be steady (within 25 pct): still moving = still panning, wait */
        if(above(c_mhi,c_mlo,2500)){c_low_ms=now;c_v1lo=c_v1hi=v1;c_mlo=c_mhi=m;}
        /* calm: Canon's brightness number steady (within 12 pct) while sharpness stays down - a pan or a
           person walking through changes it; then wait instead of chasing */
        if(above(c_v1hi,c_v1lo,1200)){c_low_ms=now;c_v1lo=c_v1hi=v1;}
        else if((int)(now-c_low_ms)>=wait_ms){c_run=1;hs_released=0;return 1;}
    }
    else c_low_ms=0;
    return 0;
}

/* ---------------- AF point and size (menu CFAF AF Point / CFAF AF Box Size) ----------------
   Moves Canon's own LiveView AF box the way ML's focus-box code does (prop_request_change on
   PROP_LV_AFFRAME), so Canon measures its focus value there. Size: the 5D3 has one box size in Live mode;
   CFAF asks Canon for a half / double size box - EXPERIMENTAL: if Canon keeps its size, CFAF says so. */
extern void prop_request_change(unsigned property,const void *addr,unsigned len);
static int afp_applied=-1,afs_applied=-1,aff_w0=0,aff_h0=0;
static int clampi(int v,int lo,int hi){if(hi<lo)hi=lo;return v<lo?lo:(v>hi?hi:v);}
static void apply_afframe(void)
{
    static int a[32];int i,W,H,w,h,cx,cy,wantx;uint32_t sq,t;
    if(afpoint_setting==afp_applied&&afsize_setting==afs_applied)return;
    if(!lv||gui_menu_shown()||aff[0]<=0||aff[4]<=0)return;          /* applied once the menu is closed */
    if(afp_applied<0&&!afpoint_setting&&!afsize_setting){afp_applied=0;afs_applied=0;return;}   /* nothing asked */
    for(i=0;i<32;i++)a[i]=aff_raw[i];
    W=a[0];H=a[1];
    if(afs_applied<=0||!aff_w0){aff_w0=a[4];aff_h0=a[5];}             /* Canon's own size, while CANON size is used */
    w=aff_w0;h=aff_h0;
    if(afsize_setting==1){w=w>>1;h=h>>1;}
    if(afsize_setting==2){w=w<<1;h=h<<1;if(w>W/2)w=W/2;if(h>H/2)h=H/2;}
    if(!afpoint_setting){cx=a[2]+(a[4]>>1);cy=a[3]+(a[5]>>1);}       /* keep where the joystick put it */
    else
    {   static const signed char gx[10]={0,2,1,2,3,1,3,1,2,3},gy[10]={0,2,1,1,1,2,2,3,3,3};   /* quarters */
        int k=afpoint_setting>9?1:afpoint_setting;
        cx=(int)divu((uint32_t)W*(uint32_t)gx[k],4u);cy=(int)divu((uint32_t)H*(uint32_t)gy[k],4u);
    }
    a[4]=w;a[5]=h;
    a[2]=clampi(cx-(w>>1),500,W-w);a[3]=clampi(cy-(h>>1),500,H-h);wantx=a[2];
    sq=aff_seq;prop_request_change(PROP_LV_AFFRAME,a,0);
    for(t=0;t<15&&aff_seq==sq;t++)msleep(20);
    if(aff_seq!=sq&&!is_manual_focus()&&(aff[2]-wantx>160||wantx-aff[2]>160))
    {   /* some cameras shift X in AF mode (ML shoot.c): correct once */
        a[2]=wantx-(aff[2]-wantx);sq=aff_seq;prop_request_change(PROP_LV_AFFRAME,a,0);
        for(t=0;t<15&&aff_seq==sq;t++)msleep(20);
    }
    if(afsize_setting&&aff[4]!=w&&aff[4]>0)
    {   /* Canon kept its size: put its box back on the intended centre */
        a[4]=aff[4];a[5]=aff[5];a[2]=clampi(cx-(a[4]>>1),500,W-a[4]);a[3]=clampi(cy-(a[5]>>1),500,H-a[5]);
        sq=aff_seq;prop_request_change(PROP_LV_AFFRAME,a,0);
        for(t=0;t<15&&aff_seq==sq;t++)msleep(20);
        /* v13: the 5D3 measures focus only inside its own fixed box, so a different-size box drawn by CFAF would
           not change what is measured - it would only mislead. Back to CANON size, say so once. */
        NotifyBox(4000,"CFAF: 5D3 measures only its fixed AF box - size set back to CANON");
        afsize_setting=0;
    }
    afp_applied=afpoint_setting;afs_applied=afsize_setting;
    draw_status(1);
}

module_prophandler_t *__module_prophandlers_cfaf[]={&cfd_block,&aff_block,&done_block,&lensu_block,0};

/* ---------------- AF-point button (top right, next to *): toggles continuous AF ----------------
   ML has no name for this button on the 5D3, so CFAF learns its raw code once (menu: CFAF AF-Point Button = LEARN):
   1.5 s "hands off" (codes seen then are background events and are ignored), then press the button 3 times in 5 s.
   The first code that came 2+ times is kept (press, not release). Later presses toggle continuous AF; Canon's own
   action for that button is blocked only in LiveView with the ML menu closed. */
#ifndef CBR_KEYPRESS_RAW
#define CBR_KEYPRESS_RAW 8
#endif
struct cfaf_event {int type;int param;void *obj;int arg;};
static volatile int learn_phase=0,btn_toggle=0;      /* 1 hands off, 2 collecting */
static int lc_code[16],lc_n[16],lc_bad[16],lc_cnt=0,lc_badcnt=0;
/* v21: half-shutter press / release, Canon's display-info refresh, internal: never learned, never blocked */
static int known_noise(int c){return c==0x4e||c==0x4f||c==103||c<0||c>0x200;}
static volatile uint32_t hs_evt_ms=0,pend_ms[3]={0,0,0};static volatile int last_code=-1,last_code_new=0;
static unsigned int cfaf_keypress_raw(unsigned int ctx)
{
    struct cfaf_event *e=(struct cfaf_event*)ctx;int c,i;
    if(!e)return 1;
    c=e->param;
    if(c==0x4e||c==0x4f)hs_evt_ms=get_ms_clock();
    if(btncodes_setting&&!known_noise(c)){last_code=c;last_code_new=1;}
    if(learn_phase==1){if(lc_badcnt<16&&!known_noise(c)){for(i=0;i<lc_badcnt;i++)if(lc_bad[i]==c)return 1;lc_bad[lc_badcnt++]=c;}return 1;}
    if(learn_phase==2)
    {   if(known_noise(c))return 1;
        for(i=0;i<lc_badcnt;i++)if(lc_bad[i]==c)return 1;
        for(i=0;i<lc_cnt;i++)if(lc_code[i]==c){lc_n[i]++;return 1;}
        if(lc_cnt<16){lc_code[lc_cnt]=c;lc_n[lc_cnt]=1;lc_cnt++;}
        return 1;
    }
    /* v21: learned buttons are NOT blocked any more and only act 0.2 s later if no half-press came with them.
       v13-v20 blocked the learned code: on your camera the learned code also arrived with the half-press, so the
       half-press was swallowed and toggled continuous off (logs: stopped_by 768 = half-press + switched off). */
    if(!lv||gui_menu_shown())return 1;
    if(afbtn_setting==1&&afcode>=0&&c==afcode)pend_ms[1]=get_ms_clock()|1;
    if(fbtn_setting==1&&fcode>=0&&c==fcode)
    {   if(worker_busy&&tap_run)cancel_request=1;                        /* pressed again while focusing: stop */
        else pend_ms[2]=get_ms_clock()|1;
    }
    return 1;
}
/* which: 1 = continuous button, 2 = focus button */
static void learn_button(int which)
{
    int i,best=-1,hit=0;
    lc_cnt=lc_badcnt=0;
    NotifyBox(1500,"CFAF: hands off the buttons...");
    learn_phase=1;msleep(1500);
    NotifyBox(5000,which==1?"CFAF: press the button for CONTINUOUS on/off 3 times":"CFAF: press the button for FOCUS 3 times");
    learn_phase=2;msleep(5000);
    learn_phase=0;
    for(i=0;i<lc_cnt;i++)if(lc_n[i]>=2&&lc_n[i]<=8){best=i;break;}
    if(best<0)
    {   NotifyBox(4000,"CFAF: no button seen 2+ times - try LEARN again (half-shutter cannot be learned)");
        if(which==1)afbtn_setting=afcode>=0?1:0;else fbtn_setting=fcode>=0?1:0;
        return;
    }
    if((which==1&&lc_code[best]==fcode&&fbtn_setting)||(which==2&&lc_code[best]==afcode&&afbtn_setting))
    {   NotifyBox(4000,"CFAF: that button (code %d) is already the other CFAF button - pick another",lc_code[best]);
        if(which==1)afbtn_setting=afcode>=0?1:0;else fbtn_setting=fcode>=0?1:0;
        return;
    }
    /* does the same code come with a half-press? (then it is only used when no half-press comes with it) */
    {   int code=lc_code[best];
        lc_cnt=lc_badcnt=0;
        NotifyBox(3000,"CFAF: now HALF-PRESS the shutter once (check)");
        learn_phase=2;msleep(3000);learn_phase=0;
        for(i=0;i<lc_cnt;i++)if(lc_code[i]==code)hit=1;
        if(which==1){afcode=code;afbtn_setting=1;}else{fcode=code;fbtn_setting=1;}
    }
    NotifyBox(5000,hit?"CFAF: learned code %d - it also comes with the half-press, so it only works without one":
                       "CFAF: learned code %d. It now %s",which==1?afcode:fcode,which==1?"switches continuous AF on/off":"focuses once (press again = stop)");
}

/* ---------------- worker / menu ---------------- */
static int af_btn_moved=0;
static void worker(void *unused)
{
    int hs_prev=1,cprev=0;
    (void)unused;
    while(!worker_exit)
    {   if(cont_setting&&!cprev){c_kick=1;c_ref=0;c_cool=0;c_fails=0;watch_reset();}   /* switched on: look at once */
        cprev=cont_setting;
        if(c_kick)c_cool=0;
        int go=0,hs=get_halfshutter_pressed();
        if(trigger_setting&&!af_btn_moved&&lv&&!hs){assign_af_button_to_star_button();af_btn_moved=1;}
        if(!trigger_setting&&af_btn_moved){restore_af_button_assignment();af_btn_moved=0;}   /* 1 and 2 both use the half-press */
        if(trigger_setting==1&&hs&&!hs_prev)
        {   /* QUICK AF: hold = focus. A tap (released within 0.2 s) does nothing and writes no log.
               With Continuous ON, continuous pauses while held and carries on from the new focus after. */
            int k,held=1;
            for(k=0;k<10;k++){msleep(20);if(!get_halfshutter_pressed()){held=0;break;}}
            if(held){go=1;hs_run=1;hs_released=0;hs_rel_ms=0;}
            hs=held;
        }
        if(trigger_setting==3&&hs&&!hs_prev&&!go)
        {   /* v21 TAP AF: a half-press (any length) starts one full focus; half-press again = stop */
            go=1;tap_run=2;tap_rel=0;hs_run=0;hs_released=0;
        }
        if(trigger_setting==2&&hs&&!hs_prev)
        {   /* TOGGLE CONTINUOUS: each half-press switches continuous AF on / off */
            int k,held=1;
            for(k=0;k<5;k++){msleep(20);if(!get_halfshutter_pressed()){held=0;break;}}
            if(held)
            {   cont_setting=!cont_setting;watch_reset();c_ref=0;c_kick=1;
                NotifyBox(2000,cont_setting?"CFAF continuous AF: ON (half-press toggle)":"CFAF continuous AF: OFF (half-press toggle)");
                draw_status(1);
            }
        }
        hs_prev=hs;
        {   static uint32_t ps=0;                       /* v19: keep LiveView / the screen awake while CFAF works */
            if((worker_busy||cont_setting)&&(int)(get_ms_clock()-ps)>2000){ps=get_ms_clock();powersave_prolong();}
        }
        if(afbtn_setting==2&&!gui_menu_shown()&&!worker_busy){msleep(300);if(!gui_menu_shown())learn_button(1);}
        if(fbtn_setting==2&&!gui_menu_shown()&&!worker_busy){msleep(300);if(!gui_menu_shown())learn_button(2);}
        if(btncodes_setting&&last_code_new){last_code_new=0;NotifyBox(1500,"CFAF: button code %d",last_code);}
        /* learned buttons act 0.2 s after the press, only if no half-press came with them (within 0.3 s) */
        {   int w;uint32_t now=get_ms_clock();
            for(w=1;w<=2;w++)if(pend_ms[w]&&(int)(now-pend_ms[w])>=200)
            {   uint32_t pm=pend_ms[w];int d=(int)(pm-hs_evt_ms);pend_ms[w]=0;
                if(hs_evt_ms&&d<300&&d>-300)continue;
                if(get_halfshutter_pressed())continue;
                if(w==1)
                {   cont_setting=!cont_setting;watch_reset();c_ref=0;c_kick=1;
                    NotifyBox(2500,cont_setting?"CFAF continuous AF: ON (learned button, code %d)":"CFAF continuous AF: OFF (learned button, code %d)",afcode);
                    draw_status(1);
                }
                else if(!go){go=1;tap_run=1;hs_run=0;hs_released=0;}
            }
        }
        if(!go&&lstat_request){lstat_request=0;lens_status(8000);}
        if(!go&&forget_request&&!gui_menu_shown()){forget_request=0;lens_forget();}
        if(!go&&learn_request&&!gui_menu_shown())
        {   /* Probe (how it moves, ~2.5 min, ends in focus) then Calibrate (sharp zone map, ~1 min), both saved */
            learn_request=0;worker_busy=1;cancel_request=0;hs_run=0;c_run=0;
            NotifyBox(4000,"CFAF Learn Lens %dmm: ~3-4 min. Tripod, detailed target, keep still. Half-press = stop",lens_info.focal_len);
            msleep(2500);
            probe_lens();
            if(prb_last_ok&&!cancel_request&&!worker_exit)
            {   msleep(2500);
                NotifyBox(3000,"CFAF Learn Lens: part 2 - mapping the sharp zone");
                msleep(1500);
                calibrate_lens();save_log();
            }
            msleep(3000);lens_status(10000);
            worker_busy=0;watch_reset();c_ref=0;c_kick=1;
            continue;
        }
        if(!go&&probe_request)
        {   probe_request=0;worker_busy=1;cancel_request=0;hs_run=0;c_run=0;
            NotifyBox(3000,"CFAF: probing how this lens moves (~1 min) - keep still, half-press = stop");
            msleep(1500);
            probe_lens();
            worker_busy=0;watch_reset();c_ref=0;
            continue;
        }
        if(!go&&cal_request)
        {   cal_request=0;worker_busy=1;cancel_request=0;hs_run=0;c_run=0;
            NotifyBox(3000,"CFAF: calibrating this lens at %dmm - keep the camera still",lens_info.focal_len);
            msleep(1500);
            calibrate_lens();
            save_log();
            worker_busy=0;watch_reset();c_ref=0;
            continue;
        }
        if(!go&&run_request){run_request=0;go=1;hs_run=0;hs_released=0;}
        if(!go&&cont_setting&&!hs&&lv&&!is_manual_focus()&&!is_continuous_af()&&lens_info.lens_exists)
            go=watch();
        else watch_reset();
        if(!go&&!hs)apply_afframe();
        draw_status(0);
        if(go)
        {
            worker_busy=1;cancel_request=0;
            draw_status(1);
            af_run();
            if(stop_code==S_OK)ok_until=get_ms_clock()+2500;
            if(stop_code!=S_OK&&stop_code!=S_GATE&&stop_code!=S_NODATA)restore_start();   /* never leave it worse */
            if(stop_code==S_GATE&&hs_released)
            {   if(levels_used&16)glide_handoff();else goto_best_on_release();   /* v24: GLIDE hand-off to continuous */
            }
            /* continuous: no log flood from repeated failures; in C-Mode ALWAYS only runs that moved the focus */
            if(!c_run||(calways_setting?(cmds>0&&(stop_code==S_OK||c_fails<4)):(stop_code==S_OK||c_fails<3)))save_log();
            if(stop_code==S_NODATA)NotifyBox(3000,"CFAF: no Canon focus data (needs the 5D3 in LiveView)");
            else if(stop_code==S_NOHILL&&!c_run)
            {
                if(cmds>=6&&!above(v_best,v_min,1500))      /* lens moved a lot, Canon's value moved < 15 pct */
                    NotifyBox(4000,"CFAF: Canon focus value not changing. Magic Zoom ON? AF box on detail?");
                else NotifyBox(2000,"CFAF: no focus found");
            }
            {   int was_hs=hs_run||tap_run,ok=stop_code==S_OK;
                watch_after_run();
                /* v18: after a quick AF (half-press) that was let go early or failed, continuous looks again at once
                   (it used to keep the old reference and wait for a 4 pct drop from it) */
                if(was_hs&&cont_setting&&!ok){c_kick=1;c_ref=0;}
            }
            worker_busy=0;hs_run=0;c_run=0;tap_run=0;
            draw_status(1);
        }
        msleep(20);
    }
}
/* v17 menu: sections. SET changes the value shown on a section line; Q opens its submenu (Magic Lantern standard). */
#define EOL {.priv=(void*)-1}
static int adv_dummy=0;
static struct menu_entry menu[] = {
    {.name="CFAF Focus Now",.priv=&run_request,.max=1,.choices=CHOICES("OFF","RUN"),
     .help="Focus once now, using Canon's own focus data (Magic Zoom's green). Log ML/CFAFxxxx.CSV.",
     .help2="Q: quick AF settings (motion, speed, big jumps) - used by the half-shutter and the focus button too.",
     .children=(struct menu_entry[]){
        {.name="Q-Motion",.priv=&qglide_setting,.max=1,.choices=CHOICES("STEPS","GLIDE"),
         .help="GLIDE: quick AF passes the top both ways; far out it uses +/-2, and +/-3 jumps when",
         .help2="Calibrate showed they land right. STEPS: the older step / stop / read search."},
        {.name="Speed",.priv=&speed_setting,.max=2,.choices=CHOICES("FAST","NORMAL","CAREFUL"),
         .help="STEPS: CAREFUL averages 2 Canon values per reading (steadier, slower)."},
        {.name="Big Jumps",.priv=&big_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="STEPS: far out of focus, find the sharp zone with big +/-3 jumps, then settle with +/-2."},
        EOL}},
    {.name="CFAF Continuous",.priv=&cont_setting,.max=1,.choices=CHOICES("OFF","ON"),
     .help="Continuous AF: keeps the AF box sharp by itself. Starts looking as soon as it is switched on.",
     .help2="Q: continuous settings (Glide, Mode, Speed, AF-point button ...).",
     .children=(struct menu_entry[]){
        {.name="C-Motion",.priv=&glide_setting,.max=1,.choices=CHOICES("STEPS","GLIDE"),
         .help="GLIDE: fine +/-1 rapid-fire moves, reads every frame, passes the top both ways (smooth).",
         .help2="STEPS: the older step / stop / read search."},
        {.name="C-Mode",.priv=&calways_setting,.max=1,.choices=CHOICES("ON DROP","ALWAYS"),
         .help="ALWAYS: runs all the time - any 4 pct softening (0.25 s) starts a glide, a miss is retried after 1 s.",
         .help2="ON DROP: only when sharpness falls by C-Sensitivity and stays down (calmer, for steady shots)."},
        {.name="C-Sensitivity",.priv=&csens_setting,.max=2,.choices=CHOICES("LOW","MEDIUM","HIGH"),
         .help="ON DROP mode: refocus when sharpness falls 35 / 25 / 15 pct and stays down for 1 / 0.6 / 0.3 s."},
        {.name="C-Speed",.priv=&cspeed_setting,.max=2,.choices=CHOICES("SLOW (CINE)","MEDIUM","FAST"),
         .help="SLOW: a pause after every step (gentle pull). MEDIUM / FAST: +/-2 steps while far out of focus.",
         .help2="STEPS motion: pauses of 0.3 / 0.12 / 0 s per +/-2 step."},
        {.name="C-Big Jumps",.priv=&cbig_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="STEPS motion only: ON allows +/-3 jumps when far out of focus. GLIDE never uses them."},
        EOL}},
    {.name="CFAF Buttons",.priv=&trigger_setting,.max=3,.choices=CHOICES("HALF: NOTHING","HALF: HOLD AF","HALF: TOGGLE CONT","HALF: TAP AF"),
     .help="Half-shutter: HOLD AF = focus while held. TAP AF = one press focuses fully (again = stop).",
     .help2="TOGGLE CONT = continuous on/off. Q: learn your own Focus and Continuous buttons.",
     .children=(struct menu_entry[]){
        {.name="Focus Button",.priv=&fbtn_setting,.max=2,.choices=CHOICES("OFF","ON","LEARN"),
         .help="A button of your choice focuses once (press again = stop), like TAP AF.",
         .help2="LEARN, leave the menu, hands off 1.5 s, press the button 3 times, then half-press once."},
        {.name="Continuous Button",.priv=&afbtn_setting,.max=2,.choices=CHOICES("OFF","ON","LEARN"),
         .help="A button of your choice switches continuous AF on / off (e.g. the AF-point button next to *).",
         .help2="LEARN, leave the menu, hands off 1.5 s, press the button 3 times, then half-press once."},
        {.name="Release Hand-off",.priv=&handoff_setting,.max=2,.choices=CHOICES("OFF","DIRECTION","DIR + GO BACK"),
         .help="HOLD AF let go early: DIRECTION = continuous starts the way it was getting sharper.",
         .help2="DIR + GO BACK also returns to a clearly (25 pct) sharper spot it passed. OFF = as v23."},
        {.name="Show Button Codes",.priv=&btncodes_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="Shows the code of every button you press (outside the menu) - to see what the camera sends."},
        EOL}},
    {.name="CFAF AF Point",.priv=&afpoint_setting,.max=9,
     .choices=CHOICES("CANON (JOYSTICK)","CENTRE","TOP LEFT","TOP","TOP RIGHT","LEFT","RIGHT","BOTTOM LEFT","BOTTOM","BOTTOM RIGHT"),
     .help="Moves Canon's AF box (where Canon measures focus) to this point when you leave the menu.",
     .help2="Q: AF box options. CANON: leave it where the joystick puts it.",
     .children=(struct menu_entry[]){
        {.name="Show AF Box",.priv=&afshow_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="Draws Canon's AF box: white idle, yellow while focusing, green for 2.5 s after a good focus."},
        {.name="AF Box Size",.priv=&afsize_setting,.max=2,.choices=CHOICES("CANON","SMALL (1/2)","LARGE (2x)"),
         .help="EXPERIMENTAL: asks Canon for a smaller / larger box. The 5D3 keeps its one size, then this",
         .help2="goes back to CANON (a drawn box of another size would not change what Canon measures)."},
        EOL}},
    {.name="CFAF Lens",.priv=&learn_request,.max=1,.choices=CHOICES("Q: OPTIONS","LEARN NOW"),
     .help="LEARN NOW (tripod, detailed target, ~3-4 min): Probe + Calibrate this lens at this focal length.",
     .help2="Saved on the card and used at once - swap lenses in the field. Q: status, single steps, forget.",
     .children=(struct menu_entry[]){
        {.name="Lens Status",.priv=&lstat_request,.max=1,.choices=CHOICES("-","SHOW"),
         .help="Shows what CFAF knows about the lens on the camera at this focal length."},
        {.name="Learn Lens",.priv=&learn_request,.max=1,.choices=CHOICES("OFF","RUN"),
         .help="Probe (how the motor moves, ~2.5 min, ends in focus) + Calibrate (sharp zone, ~1 min).",
         .help2="Tripod, LiveView, movie mode, lens on AF, a detailed target at a middle distance. Half-press = stop."},
        {.name="Probe Only",.priv=&probe_request,.max=1,.choices=CHOICES("OFF","RUN"),
         .help="Motion only: step sizes, speed, slack, Canon's delay, travel. Tunes GLIDE (ML/CFAFGLD.TXT).",
         .help2="ML says 'soft limit reached' at the two end stops during it - expected. Log ML/CFPxxxxx.CSV."},
        {.name="Calibrate Only",.priv=&cal_request,.max=1,.choices=CHOICES("OFF","RUN"),
         .help="Sharp zone width, +/-3 size, backlash (ML/CFAFCAL.TXT). Used by quick AF / STEPS.",
         .help2="Start on a subject at a middle distance (not at closest focus / infinity): fewer end stops."},
        {.name="Forget This Lens",.priv=&forget_request,.max=1,.choices=CHOICES("OFF","FORGET"),
         .help="Deletes what CFAF learned for this lens at this focal length (after you leave the menu)."},
        EOL}},
    {.name="CFAF Advanced",.priv=&adv_dummy,.max=0,.choices=CHOICES("Q: OPEN"),
     .help="Q: exposure compensation, two channels, indicator, log, stop.",
     .children=(struct menu_entry[]){
        {.name="Exposure Comp",.priv=&norm_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="ON: sharpness = Canon focus value / Canon brightness value, so exposure changes are not",
         .help2="mistaken for focus changes."},
        {.name="Two Channels",.priv=&agree_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="ON: a spot only counts as sharper when both of Canon's focus numbers (v2 and v3) agree."},
        {.name="Indicator",.priv=&ind_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="Top-left: CAF green = continuous AF on, CAF> = refocusing, AF> = quick AF running."},
        {.name="Log",.priv=&log_setting,.max=1,.choices=CHOICES("OFF","ON"),
         .help="Write ML/CFAFxxxx.CSV after every run."},
        {.name="Stop",.priv=&cancel_request,.max=1,.choices=CHOICES("OFF","STOP"),
         .help="Stop a running focus / probe / calibration at the next step."},
        EOL}},
};
static unsigned int cfaf_init(void)
{
    if(is_camera(CAM_MODEL,CAM_FW))
    {
        run_request=cancel_request=0;worker_exit=worker_busy=0;log_serial=0;
        menu_add("Focus",menu,(int)(sizeof(menu)/sizeof(menu[0])));
        task_create("cfaf",29,16384,worker,0);
    }
    return 0;
}
static unsigned int cfaf_deinit(void)
{
    int n;
    worker_exit=1;cancel_request=1;run_request=0;
    for(n=0;n<120&&worker_busy;n++)msleep(50);
    if(worker_busy)return 1;
    if(af_btn_moved){restore_af_button_assignment();af_btn_moved=0;}
    menu_remove("Focus",menu,(int)(sizeof(menu)/sizeof(menu[0])));
    return 0;
}
MODULE_INFO_START()
  MODULE_INIT(cfaf_init)
  MODULE_DEINIT(cfaf_deinit)
  MODULE_LONGNAME("CFAF Canon Focus AF")
MODULE_INFO_END()
MODULE_CBRS_START()
  MODULE_CBR(CBR_KEYPRESS_RAW, cfaf_keypress_raw, 0)
MODULE_CBRS_END()
MODULE_CONFIGS_START()
  MODULE_CONFIG(trigger_setting)
  MODULE_CONFIG(speed_setting)
  MODULE_CONFIG(log_setting)
  MODULE_CONFIG(big_setting)
  MODULE_CONFIG(norm_setting)
  MODULE_CONFIG(cont_setting)
  MODULE_CONFIG(csens_setting)
  MODULE_CONFIG(cspeed_setting)
  MODULE_CONFIG(glide_setting)
  MODULE_CONFIG(qglide_setting)
  MODULE_CONFIG(calways_setting)
  MODULE_CONFIG(cbig_setting)
  MODULE_CONFIG(agree_setting)
  MODULE_CONFIG(afpoint_setting)
  MODULE_CONFIG(afsize_setting)
  MODULE_CONFIG(afshow_setting)
  MODULE_CONFIG(afbtn_setting)
  MODULE_CONFIG(afcode)
  MODULE_CONFIG(fbtn_setting)
  MODULE_CONFIG(fcode)
  MODULE_CONFIG(handoff_setting)
  MODULE_CONFIG(ind_setting)
MODULE_CONFIGS_END()
MODULE_STRINGS_START()
  MODULE_STRING("Name","CFAF Canon Focus AF")
  MODULE_STRING("Author","experimental")
  MODULE_STRING("License","GPL")
  MODULE_STRING("Summary","Autofocus from Canon's own LiveView focus data (" CAM_MODEL ")")
  MODULE_STRING("Description","Coarse-to-fine: +/-3 and +/-2 steps by Canon's value, then a fine +/-1 scan and the centre of the top.")
MODULE_STRINGS_END()
