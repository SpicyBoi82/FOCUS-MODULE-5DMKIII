CFAF v25 - Canon Focus AF for the Canon 5D Mark III (firmware 1.1.3), Magic Lantern module
==========================================================================================
A new focus routine written from scratch. It uses ONLY Canon's own focus data (the same numbers that make
Magic Zoom go green), never the LiveView picture, so the 5D3's ~170 ms picture lag cannot fool it.
It replaces V17C for testing; V17C (FZ17C.MO) is not used by it.

INSTALL
  1. Copy CFAF.MO to ML/MODULES/ on the card.
  2. Either remove FZ17C.MO from ML/MODULES/, or keep it and set "V17C Trigger" to MENU ONLY.
     (Both on HALF-SHUTTER would fight over the lens.)  CAMF must be OFF.
  3. Restart the camera, enable CFAF in Modules, restart again.
  4. Menu "Focus" tab: CFAF Calibrate Lens / CFAF Run / CFAF Half-Shutter / CFAF Speed / CFAF Big Jumps / CFAF Exposure Comp /
     CFAF Continuous / CFAF C-Sensitivity / CFAF C-Speed / CFAF Indicator / CFAF Log / CFAF Stop.

USE
  - LiveView, lens on AF, movie mode or photo LiveView.
  - CFAF Trigger = HALF-SHUTTER (default): press and HOLD the shutter half-way until the lens stops.
    Letting go stops it. Canon's own AF moves to the * button while this is on.
  - CFAF Run = RUN does the same from the menu.

CFAF v25 - WHY v24 WAS WORSE, AND THE FIX
-----------------------------------------
In your v24 logs (Sigma at 16 mm) the "go back to the sharper spot" part of the hand-off fired on almost every
half-press release (CFAF13CE, 13D5, 13D6) and each time the next continuous run started much softer
(13CE best 41589 -> 13CF started at 5988). Two reasons:
  1. You let go when it LOOKS sharp - but right at and after the release Canon's brightness number jumps
     wildly for about a second (13CE: 9287 -> 28224 -> 595 -> 372, i.e. up to 30x). Sharpness is divided
     by it, so the value "now" looked much lower than the best and CFAF moved the lens away from the good spot.
  2. The spot it went back to was shifted by the Sigma's Canon-delay figure (300 ms, from a probe that was
     unreliable), i.e. a few steps off a narrow top.
The simulator has no such brightness jump at a release, so it looked good there. v25:
  * only frames from BEFORE the release are used;
  * Buttons > Q > Release Hand-off: DIRECTION (default) = continuous only starts the way it was getting sharper,
    the lens stays where you let go (like v23); DIR + GO BACK = also go back, but only to a 25 pct sharper spot,
    with at most a 150 ms delay; OFF = exactly v23.

CFAF v24 - HALF-PRESS HAND-OFF TO CONTINUOUS
--------------------------------------------
Your way of working: hold the half-press (HOLD AF) until it looks close, let go, continuous finishes it.
When you let go, quick AF no longer throws away what it saw:
  1. If it had already passed a clearly sharper spot (15 pct or more sharper than where it is when you let go),
     it glides straight back to that spot first.
  2. Continuous then starts gliding the way that was getting sharper - no look the wrong way first.
Simulator, half-press let go after 1.5 / 2.5 / 4 s: runs ending sharp (>= 95 pct) went from 56 / 43 / 46 to
70 / 87 / 79 out of ~300 before continuous even starts. Keep Buttons = HALF: HOLD AF for this.
(Log: event 9 with arg 97 = went back to the sharper spot, 96 = only the direction was handed on.)

CFAF v23 - LEARNS WHILE YOU USE IT (EVERY FOCAL LENGTH OF A ZOOM)
-----------------------------------------------------------------
Your v22 logs: the 50 STM (learned) and the Sigma at 16 mm (learned) now move in +/-2 and finish fast
(quick AF 0E17: soft -> sharp in 5.5 s; the far jumps were used in 0E1B). The Sigma at 46-73 mm still crept in
+/-1 (06BE: 121 steps, 10 s) - it only has data for 16 mm and a doubtful 50/60 mm, so it guessed "narrow zone".
  * GLIDE now learns the sharp-zone width itself every time it passes a top (quick AF or continuous) and saves
    it for that lens + focal length (ML/CFAFCAL.TXT, at most one card write a minute). Simulator: the learned
    width is within ~10 pct of the true one. So every focal length you use gets learned just by using it, and
    the step size (+/-1 or +/-2) follows. Bad old values get averaged out over a few focuses.
  * The motor data from Probe (step sizes, speed, slack) is now used from the nearest probed focal length at any
    distance (was: only within 15 mm) - the Sigma at 92-300 mm uses its 60 mm motor data instead of defaults.
  * Settled readings are a little quicker when Canon's delay is short (17-55, 50 STM).
WOULD MORE LEARNING HELP THE SIGMA? Yes:
  * Learn Lens (tripod) at a few focal lengths: 18, 35, 70, 135, 300 - this also measures the +/-3 jumps
    (the big time saver far out) which are only used where Calibrate measured them.
  * First at 50 / 60 mm: Lens > Forget This Lens, then Learn Lens again (those were measured while the lens was
    misbehaving at its end stop).
  * Without a tripod session it now also learns the zone width just by focusing at each focal length.

CFAF v22 - QUICK AF IN BIGGER STEPS ON WIDE-FOCUS LENSES
-------------------------------------------------------
Your v21 logs (50 STM and Sigma, 51 runs): quick AF moved only in the smallest +/-1 steps. On the 50 STM a
+/-1 step is tiny (3 position units; the whole travel is ~4200 = ~1400 of them) and its sharp zone is ~40 of
them wide, so a quick AF from soft took 100-150 steps (CFAF06C5: 147 steps, 14 s) - and every quick AF in
the logs was let go before it finished (HOLD AF stops when you let go).
  * A lens whose sharp zone is wide (Calibrate: half-width >= 4 +/-2 steps - the 50 STM) now glides in +/-2
    steps (~9 times the distance per step), for quick AF and continuous. Narrow-zone lenses (17-55 at 55 mm)
    keep the fine +/-1. Very far out the +/-3 jumps are used where Calibrate showed they land right.
  * Continuous runs that stopped with "Canon scale changed" (06C6, 06CA-06CE) now carry on (GLIDE).
  * Tip: Buttons = HALF: TAP AF - one half-press focuses all the way, you do not have to hold it.
  " AF>" on screen = quick AF running (CAF> = continuous refocusing, CAF = continuous on and idle).

CFAF v21 - YOUR OWN BUTTONS FOR FOCUS AND CONTINUOUS, HALF-PRESS GIVEN BACK
--------------------------------------------------------------------------
WHAT BROKE THE HALF-PRESS (most likely): the code CFAF learned for continuous on/off also arrives as part of a
half-press on your camera, and v13-v20 swallowed that code. So a half-press was eaten and also switched
continuous off (your logs: stopped_by 768 = half-press + continuous switched off, 512 = switched off).
v21:
  * Learned buttons are never swallowed any more, and a learned button only acts if no half-press came
    with it (checked 0.2 s later). The half-press always works.
  * When learning, CFAF also asks for one half-press and tells you if the learned code comes with it.

MENU: CFAF Buttons (Focus tab) - the line shows what the HALF-SHUTTER does, Q opens the buttons:
  HALF: NOTHING       Canon's own half-press
  HALF: HOLD AF       focus while you hold it (as before)
  HALF: TOGGLE CONT   each half-press switches continuous on/off
  HALF: TAP AF        NEW: one half-press (any length) focuses all the way; half-press again = stop
  Q > Focus Button      OFF / ON / LEARN - your own button that focuses once (press again = stop)
  Q > Continuous Button OFF / ON / LEARN - your own button for continuous on/off (was "AF-Point Button";
                        it keeps the button you learned, but re-learn it once with v21 so the half-press check runs)
  Q > Show Button Codes  shows the code of each button you press (outside the menu)
  LEARN: pick LEARN, leave the menu, hands off for 1.5 s, press your button 3 times, then half-press once.
  The quick AF settings (Q-Motion, Speed, Big Jumps) moved under CFAF Focus Now > Q.

QUICK AF FASTER FAR OUT: v19/v20 meant to use +/-2 steps while far out of focus, but a mistake made it use them
  only while the picture was getting softer, so CFAF0D57 (50 STM) and 0F5C (Sigma) crawled ~160 +/-1 steps.
  Fixed: quick AF uses +/-2 below a quarter of a good value (+/-3 on lenses whose +/-3 lands right).
  Continuous keeps +/-1 (in the simulator +/-2 in continuous overshot narrow tops) unless C-Speed = FAST.

50 STM (lens 4156) learned well: +-1 = 3 counts, Canon delay 40 ms, sharp zone ~40 +-1 steps, travel 4199.

CFAF v20 - END STOPS FOUND BY THE LENS POSITION (SIGMA NEVER SAYS "NO")
-----------------------------------------------------------------------
Your new readings (still made with v18) show why the Sigma 18-300 keeps "freezing": it never refuses a focus
command at its end stops. In the probe CFP32745 it reached one end of its travel after ~40 +/-2 steps and
CFAF kept sending ~1000 more (each one "accepted", the lens just sat there; Magic Lantern showed "soft limit").
Right after that the lens stopped reporting its position (6897 in every later log and probe), and the next
two probes came out empty (+-1 = 0 counts - not saved, so no harm to your lens data).
  * v20 watches the lens position report: if it was working in that run and has not changed for 6 commands
    and 0.9 s while the lens is told to move, that is an end stop - CFAF stops pushing at once.
    Used everywhere: Probe (travel test), Calibrate, quick AF, continuous.
  * The good 60 mm probe of that session gave: +-1 = 17 counts, +-2 = 185, 95 ms per +-1, travel 7443,
    focus at ~3100 on that scale. Its Canon-delay test missed the focus (the sweep was sent back by the
    1000 wasted commands), so do Learn Lens again with v20 - first flip the AF/MF switch (or camera off/on)
    so the position report works again.
  * Your v18 continuous runs on the Sigma were all good (16 mm and 60 mm, up to ~30000).
  * Quick AF in these logs is still the v18 step search (slow, 35-40 s). v19/v20 quick AF glides.

CFAF v19 - QUICK AF GLIDES TOO, FAR SEARCH WITH +/-3, SCREEN STAYS ON
--------------------------------------------------------------------
Your Sigma 18-300 logs at 63 mm (CFAF1BB5-1BBC): continuous worked (9734 -> 30140), quick AF did not.
Quick AF started far out of focus (Canon value 250-650, i.e. nearly flat) and walked +/-2 steps of 0.25 s
each - on the Sigma the whole focus travel is ~120 of those (30 s). With Big Jumps OFF it never got there
and ran out of time / gave up.
  * Quick AF now uses GLIDE as well (Half-Shutter > Q > Q-Motion = GLIDE, STEPS = the old search).
    Same two-way top finding as continuous; it may use the whole focus travel (up to 40 s).
  * Very far out (under a quarter of a normal in-focus value) it jumps with +/-3 - but only on a lens
    whose +/-3 Calibrate measured as landing right (your Sigma at 60 mm: one +/-3 = ~5 +/-2 steps, back
    within half a step, 0.57 s = ~2.5x faster than +/-2). Then +/-2, then fine steps near the top.
  * If it jumps over a narrow top, the return pass finds the higher top and passes it once more, so the
    middle is taken over the real top.
  * If the start is already the top (lower both ways), quick AF says OK and stays there.
  Simulator, 7 lens profiles, 308 quick AF runs: 98.4 pct >= 95 sharp, 0 false OK (STEPS 98.4 pct, 1 false).
SCREEN / LIVEVIEW GOING OFF: CFAF now keeps LiveView awake (Magic Lantern / Canon power saving) while it
  focuses, probes, calibrates, or while continuous AF is on. If LiveView pauses, Canon stops sending focus
  data and everything stops.
SIGMA ENCODER: after its calibration the Sigma's position report froze again (1661 in every later log) while
  the lens still moved - CFAF does not need it for focusing, but Probe Lens does: if a probe shows
  "+-1 = 0 counts", flip the lens AF/MF switch (or camera off/on) and probe again. Do not re-probe the Sigma at
  60 mm before that: the last good 60 mm probe saw a very jumpy target (noise 47 pct, something moving?).

CFAF v18 - SIGMA 18-300 FIX, CONTINUOUS STAYS ON
-----------------------------------------------
SIGMA 18-300 (lens id 491) "would not focus after calibrating": in your logs, from CFAF21C5 on the lens took
commands but did not move - Canon's sharpness stayed flat over 40-70 commands and the lens position report
froze at 865. That started during Calibrate at 52 mm, which ran the lens into its end stop 43 times in a row
(the calibration kept walking after the lens refused). The Sigma seems to stop answering after that.
  * Calibrate now ends a walk at the first refusal - no more hammering the end stop.
  * If continuous AF sees a lens that does not move, it says so: "the lens is not moving ... AF/MF switch
    off and on, or camera off/on" (that is what brings it back).
  * The Sigma's motor is slow: 196 ms per +/-1 step (the 17-55: 27 ms), but a +/-2 takes about the same time.
    When the probe measured a slow motor (>= 120 ms per +/-1), GLIDE moves in +/-2 steps: ~4x faster on it.
  * Its bad 50 mm calibration (sharp zone 0.75 steps - not real): use Lens > Forget This Lens at 50 mm,
    then Learn Lens again there (the lens on, after an AF/MF switch off/on).

CONTINUOUS SWITCHING OFF / NOT COMING BACK:
  * After a half-press quick AF that you let go early (most of yours) continuous now looks again straight away.
  * Every on/off now says what did it: "(AF-point button, code N)" or "(half-press toggle)".
    If it says AF-point button when you pressed a different button (e.g. the AF-ON button), that button was
    learned instead: Continuous > AF-Point Button > LEARN again and press the button next to the * only.
  * The log summary now has stopped_by: 128 = half-press let go, 256 = half-press during continuous,
    512 = continuous switched off, 64 = Stop/menu, 1/2/4/8 = LiveView / movie mode / MF / Canon servo.

CFAF v17 - ONE LENS LIBRARY, NEW MENU, CONTINUOUS STARTS AT ONCE
----------------------------------------------------------------
MENU (Focus tab) - 6 lines. SET changes the value on the line, Q opens its submenu:
  CFAF Focus Now      RUN = focus once
  CFAF Continuous     OFF / ON     Q: C-Motion (GLIDE/STEPS), C-Mode (ALWAYS/ON DROP), C-Sensitivity,
                                      C-Speed, C-Big Jumps, AF-Point Button
  CFAF Half-Shutter   NOTHING / QUICK AF / TOGGLE CONT AF     Q: Speed, Big Jumps
  CFAF AF Point       where Canon measures                    Q: Show AF Box, AF Box Size
  CFAF Lens           LEARN NOW                               Q: Lens Status, Learn Lens, Probe Only,
                                                                 Calibrate Only, Forget This Lens
  CFAF Advanced       Q: Exposure Comp, Two Channels, Indicator, Log, Stop
  (Your old settings are kept.)

LENS LIBRARY - learn in the field, use at once, no new version needed:
  * CFAF Lens = LEARN NOW (or Q > Learn Lens), leave the menu. ~3-4 minutes on a tripod, something detailed
    at a middle distance, movie mode, lens on AF. It runs Probe (how the motor moves, Canon's delay, slack,
    travel; ends in focus) and then Calibrate (sharp zone map). Half-press stops it.
  * Results go to the card (ML/CFAFGLD.TXT and ML/CFAFCAL.TXT, one line per lens + focal length) and are
    used straight away by every focus after that. Nothing to send to anybody.
  * Zooms: learn a few focal lengths (e.g. 17, 35, 55). Until a focal length is learned, the nearest learned
    one (within 15 mm) of the same lens is used.
  * Lens Status shows what is known for the lens on the camera; Forget This Lens deletes this focal length.
  * Not learned yet: continuous AF says so once and works with safe guesses.
  * Logs (ML/CFAF*.CSV, ML/CFP*.CSV) are still written if Log is ON - only needed if you want me to look.

CONTINUOUS STARTS AT ONCE: v16 took whatever it saw first as "in focus" and only moved once the picture got
4 pct softer than that - so switching it on with a soft picture did nothing. Now switching continuous on
(menu, AF-point button, half-press toggle) starts a glide straight away, and in ALWAYS mode a run that did
not reach a sharp top is retried every second until it does.
ALWAYS no longer re-glides on frame-to-frame noise of an in-focus picture (logs 815B-8162 re-focused every
~4 s): it needs a 4 pct (or 3x Canon's noise) drop for 0.25 s.
If the landing is still under 75 pct of the best it saw, it now also checks -4..+4 steps around it
(CFAF8171 landed at 71 pct).
GLIDE no longer stops when Canon's brightness number jumps 3x mid-run (CFAF8169/816C/816E on the
WD-40 bottle stopped that way); it carries on with the new scale.

CFAF v16 - GLIDE FINDS THE TOP FROM BOTH SIDES
----------------------------------------------
What went wrong in your video / CFAF8F28 (17-55 at 55 mm, f/2.8): GLIDE climbed 115 fine steps, passed a very
narrow peak (Canon 8972 -> 11063 -> 4710 in two frames = the "WD-40" sharp moment), then went back to where
it guessed the peak was using a 100 ms delay guess (your probe's sweep test had not run). That was 4 steps
off a peak only ~3 steps wide, the value there was 43 pct of the best, and v15 still said OK because it was
better than where it started. Big Jumps had nothing to do with it.

v16 GLIDE:
* after passing the top it glides back THROUGH it the other way at the same speed. Canon's delay shifts the
  two peaks in opposite directions, so the middle of the two is the real top - no delay guess needed
  (it learns the delay too: glide_lag_ms in the log);
* lands there with a soft stop, and if the value is under 85 pct of the best it saw it checks +/-1, +/-2;
* only says OK at >= 75 pct of the best it saw. Otherwise it stays at the best place (not OK) and the next
  run carries on (C-Mode ALWAYS: after 1 s);
* far below a good sharpness it moves in +/-2 steps (8F28 took 9.7 s in +/-1), +/-1 near the top;
* C-Mode ALWAYS + GLIDE now reacts to a 4 pct softening (v15 waited for 8 pct).
Simulator (7 lens profiles, 308 continuous runs): >= 95 pct sharp in 93-97 pct of runs, no false "OK",
whatever Canon's delay (v15: 66-88 pct, STEPS: 65-80 pct).

"Run all the time": CFAF Continuous = ON plus CFAF C-Mode = ALWAYS (scroll down for CFAF C-Motion = GLIDE).
Continuous can also be switched with the AF-point button (CFAF AF-Point Button, LEARN once).

Logs: in C-Mode ALWAYS failed runs that moved the lens are now logged too (first 4 in a row).

Probe v16: the "glide sweep" no longer needs the normal AF (it failed in your probe CFP3C092, so the sweep was
skipped). T6 goes to the + end, then sweeps the WHOLE travel to the - end reading every frame (coarse focus
peak), goes back to that peak and does the +/-1 glide sweeps there. ML shows "Focus: soft limit reached" at
the two ends - that is the lens at its end stop, expected, harmless. It stops at the first refusal now.
Calibrate Lens: no second try at an end stop (one "soft limit" message instead of two or more). To avoid them
in Calibrate Lens, start it on a subject at a middle distance (not at closest focus or infinity): it walks
out of focus both ways, and near an end it runs into the end stop.

CFAF v15 - GLIDE CONTINUOUS AF + BIGGER LENS PROBE
--------------------------------------------------
GLIDE (Focus menu -> CFAF C-Motion = GLIDE, the new default; STEPS = the old v14 behaviour)
  Continuous AF now moves the way you liked in the probe: fine +/-1 steps fired back to back (one every
  ~30-55 ms on the 17-55), reading Canon's sharpness on every frame while the lens moves:
  * starts gently (ease in), glides the direction that worked last time;
  * if it only gets softer it turns round (taking up the lens's slack first);
  * when sharpness has clearly dropped past the best it saw, it glides back to the best spot and slows
    down for the last steps (ease out);
  * far out of focus (under half of the last good sharpness) it uses +/-2 steps until it starts rising;
  * C-Speed SLOW (CINE) adds a short pause to every step = slower, gentler glide; FAST allows +/-2.
  * In C-Mode ALWAYS it only moves when the picture got ~8 pct softer (no constant wobble).
  * If it improved but did not reach a top, it stays there and carries on next time (no jump back).
  Quick AF on the half-shutter is unchanged (it still uses the step search).

RUN CFAF PROBE LENS FOR EACH LENS (and the 17-55 at 17 / 35 / 55 mm) - GLIDE needs it.
  GLIDE has to know how late Canon's sharpness number is compared with the lens. In the simulator a wrong
  delay drops hits from ~89 to ~73 pct; the probe measures it. Without a probe it guesses 50 ms.
  The probe now takes ~2.5 minutes (tripod, LiveView, MOVIE mode, lens on AF, something detailed to focus on):
  T7 noise of Canon's value with the lens still
  T1 single +/-1 / +/-2 / +/-3 steps (now waits 0.6 s - the lens position is only reported ~4x a second)
  T2 runs of steps with pauses, T3 steps without waiting (lost steps)
  T4 slack (backlash) when the +/-1 steps change direction
  T5 focuses normally, then GLIDE sweeps up and down through focus: the delay that makes both sweeps agree
     = Canon's lag; also the width of the sharp zone in +/-1 steps
  T6 the full travel to both end stops (the lens goes to macro and infinity and back)
  It ends IN FOCUS on the target (back to where T5 found focus), shows the results and saves them in
  ML/CFAFGLD.TXT - GLIDE uses them straight away. Send the ML/CFP*.CSV files too.
  The log of every focus run now also says which glide settings were used (glide_* columns in the summary).

CFAF v14 - CFAF PROBE LENS (how does this lens really move?)
------------------------------------------------------------
Your logs already showed the 5D3 reports the lens's focus ENCODER position (column focus_pos):
about 22-26 counts per +/-2 step on both the 17-55 and the 50 STM. The probe uses it to measure the lens
directly instead of guessing from Canon's sharpness value.

How to run: tripod, LiveView, lens on AF (switch on the lens), Canon Servo AF off.
  Focus menu -> CFAF Probe Lens -> RUN, close the menu. Takes about 1 minute. Half-press = stop.
  It ends where it started (it drives back by the encoder).
  Run it once per lens (and for the 17-55 at 17 / 35 / 55 mm if you can), then send ML/CFP*.CSV files.

What it measures:
  T1  single +/-1, +/-2, +/-3 steps: encoder counts per step, how long the motor takes, backlash after reversing
  T2  runs of steps with extra pauses 0 / 40 / 100 ms: speed and the longest stall (= visible jerk)
  T3  steps sent WITHOUT waiting for Canon's "done" (20 / 50 / 100 ms apart): do they merge into one smooth
      glide, and are steps lost? (Magic Lantern itself keeps Canon's command queue short, so this is safe.)
At the end it shows counts per step and backlash. Nothing else in CFAF changes yet - the next version uses
your probe results for smoother continuous moves (ease in / ease out) and to land exactly by the encoder.

CFAF v13 - AF-POINT BUTTON TOGGLE, GENTLER CONTINUOUS, AF BOX SIZE
-------------------------------------------------------------------
* AF-point button (top right on the back, next to *) now switches continuous AF ON / OFF.
  Magic Lantern has no name for that button on the 5D3, so CFAF learns it once:
    Focus menu -> CFAF AF-Point Button -> LEARN, close the menu,
    keep your hands off for 1.5 s ("hands off" message), then press the AF-point button 3 times
    while "press the AF-point button" is shown (5 s).
  It says "button learned (code N)" and the setting becomes TOGGLES CONTINUOUS (saved).
  Canon's own action for that button is blocked only in LiveView with the ML menu closed.
  If it says "no button seen", try LEARN again. Set it to OFF to give the button back to Canon.
* Continuous AF with C-Big Jumps OFF: your last logs used no +/-3 jumps at all - the "big jumps"
  were +/-2 walks in strides of 2 that ran past the top (the 17-55's sharp zone is only ~2 steps).
  Now: strides of 1 once the value is rising fast, and the walk stops at the first drop past the top
  (instead of after 2 flat readings). Long strides only on a slow rise / wide learned zone (50 STM).
* AF Box Size: the 5D3 measures focus only inside its own fixed box (576x768 on the sensor).
  A Magic Lantern box drawn at another size would NOT change what Canon measures, so CFAF does not
  fake one. If Canon refuses SMALL / LARGE, CFAF says so once and goes back to CANON.
  The drawn box is always Canon's real measuring box. AF Point still works.

CFAF v12 - AF POINT, AF BOX SIZE, AF BOX ON SCREEN
  Canon's focus number is measured inside Canon's own LiveView AF box. CFAF now reads that box
  (PROP_LV_AFFRAME, like ML's focus-box code) and:
  - CFAF Show AF Box (ON): draws it - white idle, yellow while focusing, green for 2.5 s after a good focus.
  - CFAF AF Point: CANON (JOYSTICK) / CENTRE / TOP LEFT / TOP / TOP RIGHT / LEFT / RIGHT / BOTTOM LEFT /
    BOTTOM / BOTTOM RIGHT (quarter points of the frame). Applied when you leave the menu; the joystick still
    moves it afterwards.
  - CFAF AF Box Size: CANON / SMALL (1/2) / LARGE (2x) - EXPERIMENTAL. The 5D3 has one box size in Live mode;
    CFAF asks Canon for another size. If Canon keeps its size a message says so and the box stays where you
    put it. Small = only the subject counts; large = steadier but background counts too.
  Each CSV summary now has afbox_x/y/w/h and sensor_w/h, so we can see what Canon really did.
  New imports (ML core functions): prop_request_change, bmp_draw_rect. If CFAF.MO fails to load on your
  ML build, tell me - those two are the only new ones.

CFAF v11 - NEW OPTIONS
  - CFAF C-Mode  ON DROP (default) / ALWAYS
      ON DROP: continuous AF refocuses only when sharpness falls (C-Sensitivity) and the picture is steady.
      ALWAYS:  it keeps checking with no pauses - a small step each way, then again (servo-like). Small
               movements will show in video. Only runs that actually moved the focus write a log.
  - CFAF C-Big Jumps  OFF (default) / ON
      OFF: continuous AF only makes small +/-2 moves: no +/-3 jumps, no long searches. If the picture is far
           out of focus it does nothing (use the half-press quick AF). Continuous looks are smaller too.
      ON:  if the picture is less than half as sharp as at the last focus it may search with big jumps.
  - CFAF Two Channels  ON (default) / OFF
      Canon sends two focus numbers (v2, v3). ON: a position only counts as sharper when neither number got
      worse - the FZ16Z12G rule for its two measures, against noise / false peaks. Costs no time.
      Every CSV row now has v2_share_x1024 (v2's part of v2+v3, 512 = equal) so we can see whether the two
      really measure different detail on your lenses. In the simulator it neither helped nor hurt.

CFAF v10 - CALIBRATE YOUR LENSES (menu CFAF Calibrate Lens)
  How:  tripod, a detailed target that fills the AF box (CAMCAL_TARGET on a monitor works), good exposure,
        Magic Zoom ON, set the zoom, then CFAF Calibrate Lens = RUN. Keep still for 20-70 s.
        On a zoom do it at a few focal lengths (e.g. 17, 24, 35, 55 on the 17-55). Primes: once.
  What it measures, for this lens + focal length:
   - the width of the sharp zone in +/-2 steps (sweeps through it single step forward and back),
   - backlash (the forward and backward sweeps' peaks are shifted by it),
   - how far one +/-3 moves (in +/-2 steps), and whether a +/-3 there-and-back lands where it started,
   - how far one +/-1 moves, the time per command, and Canon's noise.
  Result: a message on screen, a line in ML/CFAFCAL.TXT, and ML/CFCxxxxx.CSV with both sweeps (send it to me).
  From then on every focus with that lens uses it:
   - probe / stride / finish sized to the zone (as v9's self-learning, but measured properly at once),
   - backlash taken up automatically after every reversal,
   - lenses whose +/-3 comes back within 1 step (maybe the 50 STM) cover long distances in +/-3 jumps.
  ML/CFAFCAL.TXT columns: lens_id, focal, zone_halfwidth x4, count, +/-3 size x4, +/-3 return error x4,
  backlash x4, +/-1 size x4, ms per +/-2, ms per +/-3, noise (bp). Delete a line (or the file) to redo.
  Sim check (sizes known): zone width within ~10 pct, +/-3 size within ~15 pct.

CFAF v9 - SELF-CALIBRATION PER LENS (from the 23 Oct logs, 17-55 and 50 STM)
  - Every lens / focal length has a different "sharp zone" measured in focus steps. On the 50 mm STM one +/-2 step
    changes Canon's value by < 1 pct near focus and the zone is ~30+ steps wide: CFAF climbed 24-44 steps at
    +7-15 pct each (5105, 5106) and you let go before the top. On the 18-135 at 85 mm the zone is ~2 steps.
  - CFAF now LEARNS this by itself: after every good focus it measures the zone width for that lens + focal
    length and stores it in ML/CFAFCAL.TXT (lens_id, focal, width x4, count). Next time it:
      * looks half a zone width each side at once (not 1 step) to check "already in focus",
      * keeps long strides on the slope of a wide zone, short ones on a narrow zone,
      * on a wide zone fits a parabola through its readings and goes straight to the top.
    It needs a few good focuses per lens and focal range (zoom 17/18/19.../30/35/40/45/50/55) to learn.
    Delete ML/CFAFCAL.TXT to forget. Sim: 50 STM-like lens in focus 6.1 -> 5.5 s, a bit out 10.8 -> 9.6 s.
  - The 50 STM is still slow: its +/-2 step is tiny, and each step takes ~0.1 s.

CFAF v8 - FROM THE 21 OCT LOGS (EF-S 17-55, handheld, 12:44-13:26, plus the lens-cap night)
  - Lens cap on all night with Continuous ON: Canon sends zero frames, CFAF tried every ~4 s and moved the lens one
    step each time (6649 logs). Now: zero frames are ignored, a picture with no detail never triggers, and after
    failures in a row continuous waits longer (3 s, 10 s, 30 s, 60 s) and stops writing logs for them.
  - Handheld: most continuous runs stopped as "Canon scale changed" (v1 swung 500-60000 as the scene changed).
    With Exposure Comp ON only a 3x change stops a run now (v7c). A failed continuous run now puts the lens back
    where it started (25 runs had left it at 25-70 pct of its starting sharpness).
  - Continuous only refocuses when the soft picture is steady (sharpness within 25 pct and brightness within
    12 pct for the wait time) - while you are still moving the camera it waits.
  - Quick AF let go early (50 of 70 half-presses, mostly after 1-2.5 s, often after it had already seen a much
    sharper spot): on release it now goes straight to the sharpest +/-2 position it found.

CFAF v7c - MAGIC ZOOM OFF (logs CFAF6A5F-7C8D, 21 Oct)
  - With Magic Zoom off (7C88 onwards) Canon's brightness number v1 jumped from ~12k to ~44-50k and the focus value
    hardly changed while the lens moved across its whole range (7C8B-7C8D: 1938-2340, under 15 pct). Near focus it
    still worked (7C88, 7C89 at 98-99 pct); from far out there was nothing to follow. It looks like Canon measures
    a much bigger area without Magic Zoom, so a small subject barely changes the number. KEEP MAGIC ZOOM ON.
    CFAF now says "Canon focus value not changing. Magic Zoom ON? AF box on detail?" when that happens.
  - Canon sometimes sends all-zero frames (0B79, 0B7A, 0CB2-0CB4: v1 = 0) - these stopped 5 continuous runs as
    "scale changed". Zero frames are now skipped.
  - CAMGAIN brightening changed v1 by 30-60 pct inside a run and stopped 5 runs as "scale changed" (6A60, 0B7F,
    0B81, 7C84, 7C86). With Exposure Comp ON only a 3x change counts now.

CFAF v7 - HOW TO SET IT UP
  Indicator (top-left, CFAF Indicator ON):  CAF (green) = continuous AF is on and watching
                                            CAF> (yellow) = continuous AF is refocusing
                                            AF>  (yellow) = quick AF (half-press) is running
  Ways to use it:
   A. Quick AF only:              Continuous OFF, Half-Shutter QUICK AF  -> hold half-press to focus.
   B. Continuous all the time,    Continuous ON,  Half-Shutter QUICK AF  -> it keeps focus by itself; hold the
      quick AF when you need it:                                            half-press for a full quick focus,
                                                                            let go and it goes back to continuous.
   C. Half-press switches         Half-Shutter TOGGLE CONT AF            -> each half-press turns continuous
      continuous on / off:                                                   on/off (message + indicator).
  Continuous AF settings:
   - C-Sensitivity LOW / MEDIUM / HIGH: refocus when sharpness falls 35 / 25 / 15 pct and stays down, calm,
     for 1 / 0.6 / 0.3 s. "Calm" = Canon's brightness number steady (a pan or someone walking through resets it).
   - C-Speed SLOW (CINE) / MEDIUM / FAST: pause per focus step 0.3 / 0.12 / 0 s - SLOW gives a smooth pull.
     SLOW and MEDIUM also skip the final tiny steps (no jitter at the end).
   - A small dip with nothing better either side: it stays put (no hunting while filming).

CFAF v7 - FROM THE V6 LOGS (CFAFB12C-B132)
  - B132 "overshot like crazy": the big jumps went 1547 -> 2349 -> 6937 -> 2034 - one jump too many, right over
    the sharp zone, then 13 steps back. Now the jumps stop as soon as the reading is 1.4x the blurred floor
    (that is the edge of the sharp zone) and it walks on with +/-2. Sim: far-out starts 2-3 s quicker.
  - No continuous runs were in the logs (trigger "continuous" never appeared) - hence the indicator.

CFAF v6 - CONTINUOUS AF (menu CFAF Continuous, default OFF)
  Like CAMF, but with Canon's focus data and CFAF's focusing:
  - Watches Canon's sharpness on every LiveView frame while nothing else is running.
  - Reference = the sharpness at the end of the last focus (follows up slowly if the picture gets sharper).
  - When the median of the last 5 frames stays below the reference by 35 / 25 / 15 pct (C-Sensitivity LOW /
    MEDIUM / HIGH) for 0.5 s, it refocuses by itself: no waiting for Canon to settle, the direction that worked
    last time first, +/-2 steps in short strides (smaller visible overshoot); big jumps only if it is far out.
  - After a refocus it waits 1 s (3 s after a failed one, and then simply takes what it sees as the new
    reference, so it does not keep hunting on a blank wall).
  - Half-press still does a normal CFAF run; continuous pauses while the shutter is held.
  - With Exposure Comp ON, brightness changes (CAMGAIN) do not trigger a refocus.
  - Each continuous refocus writes a log too (trigger = continuous) if CFAF Log is ON.
  Do not use with CAMF ON (both would drive the lens).

CFAF v5 - AFTER THE V4 LOGS (CFAF3D97-3DA1, 85 mm)
  - 8 of 12 runs ended at 94-99 pct of the best seen; far-out ones took 8.7-15.7 s.
  - EXPOSURE COMP (menu, default ON): sharpness is now Canon's focus value divided by Canon's brightness value
    (v1, smoothed). In 3D9D the value sank 10 pct while v1 sank 13 pct - far out of focus - and CFAF took the
    dip on both sides as "in focus". The ratio did not move. With a gradual exposure change (CAMGAIN) the sim
    goes from 64 pct good / 71 wrong OKs (OFF) to 97 pct / 0 (ON).
  - The ratio also tells near from far: in focus it was 1.5-7 in every log, far out 0.2-0.9. A start below 0.5
    never takes small dips as "in focus" - it goes to the big jumps; a result below 0.6 is never called OK.
  - 3D99: the first big jumps returned in 0.03-0.2 s (the lens was at its end and did not move), then it jumped
    "back" too far and settled on a side bump (ratio 0.7). Jumps under 0.2 s now count as "not moving": after 2
    it turns round, and jumping back only counts the jumps that really moved.
  - The final +/-1 polish is shorter (max 3 steps; it gained 0.4-3 pct in the logs).

CFAF v4 - AFTER THE V3 LOGS (CFAF65AA-65B6, 85 mm)
  - FIXED a wrong "OK": in 65AC, 65AD and 65B1 the big jumps found the sharp zone (29652 / 17586 / 31202) and
    passed it, but the +/-2 steps back started by reading LOWER (the zone was a whole jump behind), so it
    settled on a blurred spot and still said OK (30-58 pct of the best). Now, after passing the zone, it walks
    back with +/-2 until the reading is at least half way up to the best jump value, ignoring early drops,
    and only then settles. And it can never say OK when it ends far below the best value it saw.
  - End of the focus range during big jumps: a +/-3 that returns in a fraction of the time of a real one and
    changes nothing = the end (65AB: 10 such jumps, then you let go). It now turns round after 3.
  - Once clearly on the slope (value 2x the blurred floor) it climbs in short strides: less overshoot and less
    walking back on narrow 85 mm tops (65AA, 65B2, 65AE walked 5-6 steps past and back).
  - Far out of focus still takes ~8-12 s at 85 mm: each +/-2 step of the 18-135 takes ~0.22 s and a +/-3 jump
    0.5-1.1 s. Keep holding the half-press until it stops. (In-focus starts ~2-3 s.)

CFAF v3 - AFTER THE V2 LOGS (CFAF6F7B-6F84: every finished run 96-99 pct, Magic Zoom green)
  - Big jumps (menu CFAF Big Jumps, default ON): far out of focus it now jumps with +/-3 like V17C did, toward
    the side whose readings were slightly higher, until the value rises and falls again (the sharp zone is then
    behind it, within ~2 jumps). Then it counts +/-2 steps again from there and settles as before.
    +/-3 never comes back to the same place, so it is used only to FIND the sharp zone, never to settle.
    If the jumps only make it worse (the start was already on a wide sharp top) it jumps back.
  - Picks the search side from the slight tilt of the blurred readings (in 6F80 and 6F7C the higher side was
    the right one) instead of always trying the side it happens to be on.
  - Narrow tops (85 mm: the next +/-2 step is only ~83 pct): a few +/-1 steps at the end toward the better side.
  - A half-press shorter than 0.2 s (a tap) does nothing and writes no log (4 of the 11 v2 logs were taps).
  - Exposure: keep the picture properly exposed (CAMGAIN on, or a bright manual exposure, whites not clipped).
    In the sim, doubling the noise (what a dark picture does) drops good results from ~98 to ~89 pct.
  Simulator: 98.5 pct of runs >= 95 pct sharp, 0 false OKs. Far-out starts ~1-1.5 s faster with Big Jumps in the
  sim; on the real 18-135 the gain may be bigger or smaller - please try ON and OFF on far-out starts.

CFAF v2 - WHAT CHANGED AFTER YOUR FIRST LOGS (CFAF1550-1885)
  - Start values were junk: right after the half-press Canon re-meters for a few frames (CFAF1881 / 1882
    started from 726 / 669 although the scene read ~9000). That made the noise threshold 10 pct, so drops past
    the focus were not seen ("keeps going past"), and 1882 even accepted a blurry spot.
    v2 waits until Canon's numbers are steady (4 frames in a row) before it starts.
  - +/-1 is useless on the 50 mm (0.2 pct per step) and +/-3 does not come back to the same place
    (1551: one +/-3 back landed at 6343 instead of 17396). +/-2 comes back cleanly (31560 -> 31117).
    v2 moves ONLY in +/-2 steps and counts them, so it can always return to the best spot.

HOW IT WORKS (v2)
  1. Waits for Canon's numbers to settle, takes the start value and the noise.
  2. Steps + one +/-2 at a time, reading after each. Keeps going while it gets sharper (longer strides on a
     slow climb, shorter when the climb flattens). Stops as soon as it is clearly past the best.
  3. If + never got sharper, does the same toward -.
  4. Both sides flat = far out of focus: long strides (4-6 steps per reading) to find the hill.
  5. Goes back to the best step, checks both neighbours, moves while a neighbour is better, stops there.
  In focus at the start: ~2-3 s. Far out: up to ~10-15 s (the 81 mm +/-2 takes ~0.2 s each).
  Messages: "no Canon focus data" (not a 5D3 / not in LiveView), "no focus found" (nothing rose or fell).

SIMULATOR (rebuilt from your logs: +/-2 = the step, 50 mm ~80 ms and 81 mm ~220 ms per step, junk frames
after the half-press; hills 3-20 steps wide; 220 runs from in focus to 40 steps out):
  97.7 pct end >= 95 pct sharp, 0 false "OK" results; in-focus starts ~2-2.9 s, median 5.9 s.

TEST PLEASE (tripod against the CAMCAL target on the monitor, as before)
  For 35 mm, 50 mm and 85 mm:
   a. start already in focus (Magic Zoom green), half-press and hold until it stops  x3
   b. start a little out (turn the ring a bit)                                       x3
   c. start far out (near the minimum focus distance or infinity)                    x3
  Say for each whether Magic Zoom ended green, and send the ML/CFAFxxxx.CSV files.
  The first line of each CSV is a SUMMARY: final_pct_of_best near 100 and stop 0 = good.
  Stop codes: 0 OK, 1 released/stopped, 2 Canon data stopped, 3 Canon changed scale, 4 no focus found,
  5 too many commands/too long (20 s), 6 no Canon data.
  Keep holding the half-press until the lens stops - far-out starts can take 10+ s.
