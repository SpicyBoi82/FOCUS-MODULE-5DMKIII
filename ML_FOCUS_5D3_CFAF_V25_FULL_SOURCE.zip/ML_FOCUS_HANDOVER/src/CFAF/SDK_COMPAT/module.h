#ifndef _module_h_
#define _module_h_
#include <stdint.h>
#define MODULE_MAGIC 0x5A
#define MODULE_MAJOR 8
#define MODULE_MINOR 0
#define MODULE_PATCH 0
#define CBR_KEYPRESS 7
#define CBR_VSYNC 6
#define MODULE_KEY_PRESS_HALFSHUTTER 1
#define MODULE_KEY_UNPRESS_HALFSHUTTER 2
#define MODULE_KEY_PRESS_SET 9
#define MODULE_STRINGS_SECTION __attribute__((section(".module_strings"),unused))
typedef struct { const unsigned char api_magic,api_major,api_minor,api_patch; const char *name,*long_name; unsigned int (*init)(void),(*deinit)(void); } module_info_t;
typedef struct { const char *name,*value; } module_strpair_t;
typedef struct {const char *name,*symbol;unsigned int type;union { unsigned int (*handler)(unsigned int); void *named_handler; };unsigned int ctx;} module_cbr_t;
struct config_var;
typedef struct {const char *name;const struct config_var *ref;} module_config_t;
#define PASTE(a,b) PASTE_IMPL(a,b)
#define PASTE_IMPL(a,b) a##b
#define MODULE_INFO_START() module_info_t PASTE(__module_info_,MODULE_NAME) = { .api_magic=MODULE_MAGIC,.api_major=MODULE_MAJOR,.api_minor=MODULE_MINOR,.api_patch=MODULE_PATCH,.name=STR(MODULE_NAME),
#define MODULE_INIT(func) .init = &func,
#define MODULE_DEINIT(func) .deinit = &func,
#define MODULE_LONGNAME(name) .long_name = name,
#define MODULE_INFO_END() }; /* note: string registration separate */
#define STR(x) STR_(x)
#define STR_(x) #x
#define MODULE_STRINGS_START() module_strpair_t PASTE(__module_strings_,MODULE_NAME)[] MODULE_STRINGS_SECTION = {
#define MODULE_STRING(field,value) {field,value},
#define MODULE_STRINGS_END() {(const char*)0,(const char*)0} };
#define MODULE_CBRS_START() module_cbr_t PASTE(__module_cbr_,MODULE_NAME)[] = {
#define MODULE_CBR(cb_type,cbr,context) {.name=#cb_type,.symbol=#cbr,.type=cb_type,.handler=cbr,.ctx=context},
#define MODULE_CBRS_END() {(void*)0,(void*)0,0,(void*)0,0} };
#define MODULE_CONFIGS_START() module_config_t PASTE(__module_config_,MODULE_NAME)[] = {
#define MODULE_CONFIG(cfg) {.name=#cfg,.ref=&__config_##cfg},
#define MODULE_CONFIGS_END() {(void*)0,(void*)0} };
/* r6: property handlers. ML's loader looks up __module_prophandlers_<modname> (NULL-terminated) and registers each
   entry with prop_add_handler(); no import needed. Same layout as ML src/module.h. */
typedef struct { const char *name; void (*handler)(unsigned int property,void *priv,uint32_t *addr,unsigned int len); const unsigned int property; const unsigned int property_length; } module_prophandler_t;
#endif
