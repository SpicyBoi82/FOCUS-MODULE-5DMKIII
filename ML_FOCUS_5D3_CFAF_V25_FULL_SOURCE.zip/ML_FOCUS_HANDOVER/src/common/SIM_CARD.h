/* SIM_CARD.h - host stand-in for the camera's card, shared by the three simulators (never built into a .MO).
 *   ML/LPxxxx.TXT (lens profiles)  -> $SIMCARD/LPxxxx.TXT   (only when the SIMCARD env variable names a folder)
 *   any other file (the CSV logs)  -> the file named by $LOGOUT (mode SIMCARD_LOG_MODE), else not written
 * Without SIMCARD no profile exists, so the modules behave exactly as without CAMCAL data. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef SIMCARD_LOG_MODE
#define SIMCARD_LOG_MODE "w"
#endif
static FILE *sc_f[8];
static FILE *sc_host(const char *name,const char *mode)
{
    if(!strncmp(name,"ML/LP",5))
    {
        char p[1024];const char *d=getenv("SIMCARD");
        if(!d)return 0;
        snprintf(p,sizeof p,"%s/%s",d,name+3);
        return fopen(p,mode);
    }
    if(*mode=='r'||!getenv("LOGOUT"))return 0;
    return fopen(getenv("LOGOUT"),SIMCARD_LOG_MODE);
}
static int sc_slot(FILE *f){int i;if(!f)return 0;for(i=1;i<8;i++)if(!sc_f[i]){sc_f[i]=f;return 100+i;}fclose(f);return 0;}
static FILE *sc_get(int h){h-=100;return (h>=1&&h<8)?sc_f[h]:0;}
int FIO_CreateFile(const char *a){return sc_slot(sc_host(a,"w"));}
int FIO_OpenFile(const char *a,unsigned m){(void)m;return sc_slot(sc_host(a,"r"));}
int FIO_WriteFile(int h,const void *b,unsigned n){FILE *f=sc_get(h);return f?(int)fwrite(b,1,n,f):0;}
int FIO_ReadFile(int h,void *b,unsigned n){FILE *f=sc_get(h);return f?(int)fread(b,1,n,f):0;}
int FIO_CloseFile(int h){FILE *f=sc_get(h);if(f){fclose(f);sc_f[h-100]=0;}return 1;}
