/* REPLAY.h - real sharpness curves for the simulators (never built into a .MO).
 * A curve file (tests/curves/*.txt) holds measured sharpness against focus position, from the user's real logs:
 *   #! focal 85            lens settings the simulator applies (any of: focal lens_id backlash k3 noise lo hi)
 *   # free text
 *   pos,fv                 positions in +/-1 units with the PEAK AT 0; fv = the modules' sharpness value
 *   -23,28808
 * Between samples the curve is linear; outside them it stays at the last value. replay_frac1000(p) returns
 * the sharpness at position p relative to the peak, 0..1000. The simulators turn it into picture contrast. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int rp_n=0,rp_pos[2048],rp_val[2048],rp_max=1;
static int rp_focal=0,rp_lensid=0,rp_backlash=-1,rp_k3=-1,rp_noise=-1,rp_lo=-100000,rp_hi=100000;
static int replay_load(const char *path)
{
    FILE *f=fopen(path,"r");char line[512];
    if(!f){fprintf(stderr,"cannot open curve %s\n",path);exit(2);}
    rp_n=0;rp_max=1;
    while(fgets(line,sizeof line,f))
    {
        int a,b;char key[64];
        if(line[0]=='#'&&line[1]=='!'&&sscanf(line+2,"%63s %d",key,&a)==2)
        {
            if(!strcmp(key,"focal"))rp_focal=a;else if(!strcmp(key,"lens_id"))rp_lensid=a;
            else if(!strcmp(key,"backlash"))rp_backlash=a;else if(!strcmp(key,"k3"))rp_k3=a;
            else if(!strcmp(key,"noise"))rp_noise=a;else if(!strcmp(key,"lo"))rp_lo=a;else if(!strcmp(key,"hi"))rp_hi=a;
            continue;
        }
        if(line[0]=='#')continue;
        if(sscanf(line,"%d,%d",&a,&b)==2&&rp_n<2048)
        {
            int i=rp_n++;
            while(i>0&&rp_pos[i-1]>a){rp_pos[i]=rp_pos[i-1];rp_val[i]=rp_val[i-1];i--;}
            rp_pos[i]=a;rp_val[i]=b;if(b>rp_max)rp_max=b;
        }
    }
    fclose(f);
    if(getenv("RP_BACKLASH"))rp_backlash=atoi(getenv("RP_BACKLASH"));   /* test variants of the same curve */
    if(getenv("RP_K3"))rp_k3=atoi(getenv("RP_K3"));
    if(rp_n<2){fprintf(stderr,"curve %s has fewer than 2 points\n",path);exit(2);}
    return rp_n;
}
static int replay_frac1000(int p)
{
    int i;long v;
    if(p<=rp_pos[0])v=rp_val[0];
    else if(p>=rp_pos[rp_n-1])v=rp_val[rp_n-1];
    else
    {
        for(i=1;i<rp_n&&rp_pos[i]<p;i++);
        if(rp_pos[i]==p)v=rp_val[i];
        else v=rp_val[i-1]+(long)(rp_val[i]-rp_val[i-1])*(p-rp_pos[i-1])/(rp_pos[i]-rp_pos[i-1]);
    }
    return (int)(v*1000/rp_max);
}
