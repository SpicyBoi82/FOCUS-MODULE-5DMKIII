/* =====================================================================================================
 * LENS_PROFILE.h - shared by CAMCAL (writes), V17C/FZ17C and CAMF (read). ONE copy, #included by all three.
 *
 * File on the card: ML/LPxxxx.TXT   (xxxx = Canon lens_id in hex, e.g. 18-135 IS USM id 36912 -> LP9030.TXT)
 * One line per focal length that CAMCAL has calibrated successfully (latest run replaces that focal):
 *
 *   # CAMCAL lens profile ...            (comment lines start with '#')
 *   focal_mm,backlash_x10,fwhm_x10,width70_x10,step3_x10,step3_sat,noise_bp,lag_x10,frame_ms,repeat_x10,serial
 *   64,20,0,607,0,0,56,-1,33,1,29414
 *
 *   backlash_x10  peak position travelling + minus travelling -, in +/-1 units x10
 *   fwhm_x10      focus peak full width at half maximum, units x10 (0 = wider than the sweep could measure)
 *   width70_x10   full width at 70% of the peak, units x10 (0 = not measured)
 *   step3_x10     real size of ONE +/-3 command in +/-1 units x10 (0 = not measurable); step3_sat=1: "at least"
 *   noise_bp      frame-to-frame sharpness noise at focus, basis points (100 = 1%)
 *   lag_x10       frames between a command and the picture change x10 (-1 = not measurable)
 *   frame_ms      time between new LiveView pictures;  repeat_x10  peak repeatability;  serial = CSV number
 *
 * The user may edit this text file by hand (e.g. to delete a bad line). Readers ignore lines they cannot parse.
 * Rules for this code: no libc, no division by variables, static buffers only (see START_HERE_CHATGPT.md).
 * ===================================================================================================== */
#ifndef LENS_PROFILE_H
#define LENS_PROFILE_H
extern int FIO_OpenFile(const char*,unsigned);         /* ML: FILE* (0 or -1 on error)  */
extern int FIO_ReadFile(int,void*,unsigned);
#define LP_O_RDONLY_SYNC 010000u                       /* O_RDONLY | O_SYNC */
#define LP_MAXL 24
#define LP_NF 11
struct lprof { int focal,back10,fwhm10,w70_10,step3_10,step3_sat,noise_bp,lag10,fp_ms,rep10,serial; };
static struct lprof lp_tab[LP_MAXL];
static int lp_n=0;
static char lp_buf[2048];                              /* <= 8192: ML's FIO_ReadFile copies via DMA memory */

static void lp_path(char *p)                           /* "ML/LPxxxx.TXT" */
{
    static const char hx[]="0123456789ABCDEF";
    unsigned id=(unsigned)lens_info.lens_id;int i;
    const char *a="ML/LP";
    for(i=0;a[i];i++)p[i]=a[i];
    p[5]=hx[(id>>12)&15u];p[6]=hx[(id>>8)&15u];p[7]=hx[(id>>4)&15u];p[8]=hx[id&15u];
    p[9]='.';p[10]='T';p[11]='X';p[12]='T';p[13]=0;
}
/* parse one line of up to LP_NF comma-separated integers; returns how many were read */
static int lp_parse(const char *s,int n,int *v)
{
    int k=0,i=0;
    while(i<n&&k<LP_NF)
    {
        int neg=0,val=0,dig=0;
        while(i<n&&(s[i]==' '||s[i]=='\t'))i++;
        if(i<n&&s[i]=='-'){neg=1;i++;}
        while(i<n&&s[i]>='0'&&s[i]<='9'){val=val*10+(s[i]-'0');i++;dig=1;if(val>100000000)val=100000000;}
        if(!dig)break;
        v[k++]=neg?-val:val;
        while(i<n&&(s[i]==' '||s[i]=='\t'))i++;
        if(i<n&&s[i]==','){i++;continue;}
        break;
    }
    return k;
}
/* load the profile of the attached lens into lp_tab; returns the number of focal entries (0 = none) */
static int lp_load(void)
{
    char path[16];int h,len,i,start;
    lp_n=0;
    if(!lens_info.lens_exists||!lens_info.lens_id)return 0;   /* lens_id 0 = unknown lens: never share a file */
    lp_path(path);
    h=FIO_OpenFile(path,LP_O_RDONLY_SYNC);
    if(h==0||h==-1)return 0;
    len=FIO_ReadFile(h,lp_buf,sizeof(lp_buf)-1);
    FIO_CloseFile(h);
    if(len<=0)return 0;
    if(len>(int)sizeof(lp_buf)-1)len=(int)sizeof(lp_buf)-1;
    lp_buf[len]=0;
    for(start=0,i=0;i<=len;i++)
    {
        if(i==len||lp_buf[i]=='\n'||lp_buf[i]=='\r')
        {
            int v[LP_NF],k,n=i-start;
            if(n>0&&lp_buf[start]>='0'&&lp_buf[start]<='9'&&lp_n<LP_MAXL)
            {
                k=lp_parse(lp_buf+start,n,v);
                if(k>=8&&v[0]>0&&v[0]<2000)
                {
                    struct lprof *p=&lp_tab[lp_n];int j;
                    for(j=k;j<LP_NF;j++)v[j]=0;
                    p->focal=v[0];p->back10=v[1];p->fwhm10=v[2];p->w70_10=v[3];p->step3_10=v[4];p->step3_sat=v[5];
                    p->noise_bp=v[6];p->lag10=v[7];p->fp_ms=v[8];p->rep10=v[9];p->serial=v[10];
                    for(j=0;j<lp_n;j++)if(lp_tab[j].focal==p->focal){lp_tab[j]=*p;break;}  /* later line wins */
                    if(j==lp_n)lp_n++;
                }
            }
            start=i+1;
        }
    }
    return lp_n;
}
/* entry with the nearest focal length; *near=1 when it is within max(3 mm, focal/8): close enough for the
   peak WIDTH (which changes a lot with focal length). Backlash may be taken from any focal of the same lens. */
static const struct lprof *lp_find(int focal,int *near)
{
    int i,bi=-1,bd=1<<30;
    *near=0;
    for(i=0;i<lp_n;i++){int d=lp_tab[i].focal-focal;if(d<0)d=-d;if(d<bd){bd=d;bi=i;}}
    if(bi<0)return 0;
    {int lim=focal>>3;if(lim<3)lim=3;*near=(bd<=lim);}
    return &lp_tab[bi];
}
/* backlash in whole +/-1 units, rounded UP (the comp pad must cover it); -1 = no profile */
static int lp_backlash_units(const struct lprof *p)
{
    int b;
    if(!p)return -1;
    b=p->back10;if(b<0)b=0;
    return (b+9)/10;
}
#endif
