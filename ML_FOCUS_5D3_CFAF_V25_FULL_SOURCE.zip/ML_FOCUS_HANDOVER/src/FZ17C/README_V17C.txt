[Handover note: this is the 70D user guide of this module. The same module is built for the 5D Mark III 1.1.3
 (see ../../5D3_QUICK_START.txt). Build everything with ../../build.sh - the per-module BUILD_*.sh scripts were
 replaced by it. On the 5D3 read "Movie Servo AF" as Canon continuous AF and "mode dial" as the Live View switch.
 Versions now: CAMCAL C5 (lens profile + Canon focus-data probe), V17C r8 (Canon AF data, below) and CAMF C3
 (pauses while half-pressed); Backlash Comp AUTO reads the profile. See ../../START_HERE_CHATGPT.md section 2.]

V17C r8 (18 Oct 2026) - after r7 runs FZ7C1C87-1C95 (18-135 at 35 / 85 mm)
 - 85 mm: one +/-3 is huge (C93/C8F crawled 60-80 units back after one +/-3 past the peak). When the big steps
   pass the peak, V17C now jumps BACK the same number of +/-3 and scans finely around there.
 - The lens refuses some commands right after a big move (C95, C8E, C8C, C8A): a refused +/-1 is retried once
   after 150 ms; a refused +/-3 is first checked (did the picture change? then it moved - C93) and else retried
   once. Only then is it an end stop.
 - Canon + narrow peak: strides capped at 2.
 - Sim with a lens that refuses for 150 ms after a +/-3 (BUSY=150 REFMOVE=1): r7 48 pct >= 95 pct sharp, r8 98 pct;
   with a 60-unit +/-3 (K3=60): r7 38 pct, r8 98 pct. YUV path unchanged.

V17C r7 (18 Oct 2026) - after the first r6 camera runs (FZ7CA293-A2A0, 18-135 at 27 / 76 mm)
 - In-focus starts at 76 mm were thrown away: r6 jumped +/-3 first (long, not reversible). r7 always starts
   with a small exact look (+/-3, then +/-6 if flat) when using Canon data; a start that is already the
   sharpest is only fine-tuned there. Sim: in-focus starts 189/189 stay sharp, ~3.5 s.
 - Faster: 1 Canon value per sample (2 on CAREFUL), still skipping 2 new frames after a move (the logs show
   Canon's value ~half-way at the end of a move and settled one frame later; skipping only 1 failed in the
   sim when Canon lags > 1 frame). Mean 4.3 s (r6 4.8 s) in the sim.
 - Narrow peak with Canon: a profile line with only a 70 pct width no longer switches it off (the 85 mm line
   made 76 mm "broad" -> strides of 8).

V17C r6 (18 Oct 2026) - Canon's own focus data as the sharpness
 - New menu "V17C Sharpness": CANON AF DATA (default) / YUV PREVIEW. Canon AF data = PROP_LV_FOCUS_DATA
   v2+v3, the value behind Magic Zoom's green on the 5D3 (every frame). The 70D never sends it: there, and when
   it isn't arriving, V17C uses the YUV preview metric exactly as r5 (simulator results identical).
 - Why: CFD39301 (5D3, 74 mm): Canon's peak arrives 4 frames (~170 ms) before the preview metric, is about half
   as wide, 11-14x sharp/blur vs 5.5-7.5x. The old fixed 75-90 ms settle read pre-move preview pictures on the
   5D3. Simulator with the 5D3's preview lag: YUV r5 46.7 pct of runs >= 95 pct sharp; Canon r6 98.0 pct
   (YUV with an ideal 40 ms lag: 98.1).
 - Waits for NEW Canon values after a move (1 frame FASTEST, 2 otherwise), then 1-3 values.
 - Canon changes scale when its own AF / exposure state changes: v1 outside 0.7-1.43x of the start = stop 14,
   back home, one restart with a fresh baseline. Canon data stopping for 300 ms = stop 15, restart with YUV.
 - Always checks one unit either side of the landing (Canon peak is narrow).
 - Refuses a "peak" on the flat blurred floor: no hill (best < 1.3x lowest and not clearly sharper than the
   start) or landing < 70 pct of the best value seen = stop 12, back to the start.
 - CSV header: source_first/source_last, restarts, canon_events, canon_ref_v1. Columns: src, canon_ab,
   canon_v1, canon_events. Events 42 source, 43 restart.
 - Simulator: CFD=1 (Canon on), CFDLAG=ms, LAG=ms (preview), CFDJUMP=ms (scale jump), CFDSTOP=ms (data stops).
   The simulated Canon curve is the YUV model at half width - an assumption until camera logs exist.
   85 mm replay (real curve squeezed to ~1.5 units wide) stays weak: 9.7 pct; real 85 mm Canon data needed.

FZ17C.MO - V17C r3 hybrid contrast AF   (Canon 70D fw 1.1.2, ML ABI 8)
Replace your FZ17C.MO with this one. Same menu, settings and log name (ML/FZ7Cxxxx.CSV);
menu and log header say "V17C r3". Not yet camera tested.

WHAT CHANGED (from your r2 test, FZ7C34FD / 34FE / 34FF / 3500)
1. 85mm and longer: strides are capped at 4 units. Your 85mm logs show the focus peak is only
   about 2 small steps wide; a stride of 8 on flat blur could step right over it.
2. Flat blur: when the picture has not got any sharper yet, one noisy dip no longer counts as
   "passed the peak" - it needs two drops in a row. Same in the big-step phase for small dips
   (a big drop still counts at once). Your 9.4 s 85mm run was thrown off by exactly such a dip.
3. Start at a stop: if the first big-step probe reads exactly like the start, it probably did
   not move (the lens "accepts" a big step at a stop without moving). Then V17C also looks
   after the first step back. In your 18mm run that skipped point was the focus itself, which
   is why it then crawled 37 units back. This costs one extra picture, only in that situation.

TRIED AND LEFT OUT
 Three ways of lengthening the stride during long climbs (for the 18mm crawl). None helped on
 average in the simulator and some made other lenses slower, so fix 3 addresses the cause instead.

SIMULATOR (source/SIM_AF.c, HOST_TEST_RESULTS.txt)
 18-135 and 17-55: still 100% of runs at >=95% of peak sharpness, including the "accepts at
 the stop" behaviour and any big-step size. 85mm (narrow peak): 3.8 -> 3.3 s and 4.5 -> 3.7 s.
 Elsewhere within ~0.25 s of r2. Accepted-but-soft landings across the whole test set: 2 -> 1
 (BALANCED) and 4 -> 1 (FASTEST), all on the 50mm STM starting very far out of focus.

PLEASE TEST
 Movie Servo AF OFF, lens on AF. Some runs at 85-135mm from blurry starts, a couple starting at
 the close-focus stop at 18mm, and a couple starting already in focus. Send the FZ7Cxxxx logs.
