/* Host simulator: FZ17A vs FZ17B on lens profiles taken from the user's own logs.
 *   gcc -O2 -w -I SDK_COMPAT -DSRC='"FZ17B.c"' -DRUN=search_v17b SIM_AF.c -o simB
 *   gcc -O2 -w -I SDK_COMPAT -DSRC='"../FZ17A/FZ17A.c"' -DRUN=search_jump -DIS_A SIM_AF.c -o simA
 * Plant (assumptions marked):
 *   - position in +/-1 command units; travel/end stops, backlash and +/-1 timing from LMP lens-mapper logs;
 *   - ONE +/-3 command = K3 units (old AF logs: ~2 at 135mm, 7-25 at 18mm), +/-2 = K2 units (assumed 2);
 *   - sharpness = two-scale Lorentzian (fine detail of half-width w + coarse detail 4w wide)  [assumption];
 *   - LiveView frame every 33 ms showing the lens as it was LAG_MS earlier; per-frame noise  [assumption];
 *   - waited command takes 20 ms + 3 ms/unit + requested delay.                                [from logs, approx] */
#define UNIT_TEST
#include SRC
#include "../common/SIM_CARD.h"
#include "../common/REPLAY.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static uint8_t imagebuf[720*480*2];
static struct vram_info_probe mock={imagebuf,720,1440,480};
static uint32_t clk=1000;
int lv=1; struct lens_info_probe lens_info={0};
static int phys=0,target=0,limit_lo=-100,limit_hi=100,backlash=0,slack=0,pdir=0,width=4,noise_pct=0,K2=2,K3=3,K3ASYM=0,LAG_MS=40,ncmd=0;
#define HN 4096
static uint32_t ht[HN];static int hp[HN],hn=0;
static void hist(void){if(hn<HN){ht[hn]=clk;hp[hn]=phys;hn++;}else{memmove(ht,ht+1,(HN-1)*4);memmove(hp,hp+1,(HN-1)*4);ht[HN-1]=clk;hp[HN-1]=phys;}}
static int phys_at(uint32_t t){int i;for(i=hn-1;i>=0;i--)if(ht[i]<=t)return hp[i];return hn?hp[0]:phys;}
static int contrast_at(int p){int b=absi(p-target);long w1=width,w2=4*width;
    if(rp_n)return 4+146*replay_frac1000(p-target)/1000;   /* real curve from a camera log */
    return (int)(6+100*w1*w1/(w1*w1+(long)b*b)+44*w2*w2/(w2*w2+(long)b*b));}
static uint32_t nseed=1;
static int frnd(uint32_t fi){uint32_t x=fi*2654435761u^nseed*40503u;x^=x>>13;x*=0x5bd1e995u;x^=x>>15;return (int)(x%2001)-1000;}
static void render(uint32_t fi){
    int x,y,c=contrast_at(phys_at(fi*33-LAG_MS));
    if(noise_pct)c+=c*noise_pct*frnd(fi)/100000;
    if(c<4)c=4;if(c>220)c=220;
    for(y=100;y<380;y++)for(x=150;x<570;x++){int s=((x/7+y/9)&1)?1:-1;imagebuf[y*1440+x*2+1]=(uint8_t)(120+s*c/2);}
}
static uint32_t last_fi=0xFFFFFFFFu;
struct vram_info_probe *get_yuv422_vram(void){uint32_t fi;clk+=2;fi=clk/33;if(fi!=last_fi){render(fi);last_fi=fi;}return &mock;}
/* r6: simulated Canon PROP_LV_FOCUS_DATA (env CFD=1): one value per 33 ms frame showing the lens CFDLAG ms
   earlier; peak half as wide as the YUV curve (CFD39301: ~0.5x FWHM, 11-14x sharp/blur ratio, noise ~0.9 pct
   = ~1.6x the YUV noise). Replay curves: frac(2x). An assumption until real driven-lens data exists.
   CFDJUMP=t: Canon scale (v1 and values x3) jumps at sim time t ms after the start (scale-change restart test).
   CFDSTOP=t: Canon data stops at t (fallback test). */
static int CFD=0,CFDLAG=40,CFDJUMP=0,CFDSTOP=0;static uint32_t cfd_last_fi=0xFFFFFFFFu,sim_t0=0;
static int canon_at(int p){int b=absi(p-target);double w=width*0.5,w2=width*2.0;if(w<0.5)w=0.5;
    if(rp_n)return 600+14000*replay_frac1000(2*(p-target))/1000;
    /* same two-scale shape as the YUV model (fine + coarse detail), every width halved */
    return (int)(600+9600*w*w/(w*w+(double)b*b)+4400*w2*w2/(w2*w2+(double)b*b));}
static void sim_cfd(void){
    uint32_t fi=clk/33,b[8]={0};int c,jump;
    if(!CFD||fi==cfd_last_fi)return;
    if(CFDSTOP&&clk-sim_t0>=(uint32_t)CFDSTOP)return;
    cfd_last_fi=fi;
    c=canon_at(phys_at(fi*33-CFDLAG));
    if(noise_pct)c+=c*noise_pct*16/10*frnd(fi^0x5555)/100000;
    jump=CFDJUMP&&clk-sim_t0>=(uint32_t)CFDJUMP;
    if(jump)c*=3;
    b[0]=0x1D003A;b[1]=jump?33000:5800;b[2]=c/2;b[3]=c-c/2;b[4]=c*130;b[7]=65195;
    cfd_handler(PROP_LV_FOCUS_DATA,0,b,32);
}
int is_camera(const char*m,const char*f){return 1;}
int is_movie_mode(void){return 1;} uint32_t get_ms_clock(void){return clk;}
void msleep(int ms){clk+=(uint32_t)ms;sim_cfd();}
int task_create(const char*a,int b,int c,void(*d)(void*),void*e){return 1;}
void menu_add(const char*a,struct menu_entry*b,int c){} void menu_remove(const char*a,struct menu_entry*b,int c){}
int is_manual_focus(void){return 0;} int is_continuous_af(void){return 0;}
void NotifyBox(int t,const char*f,...){}
int get_halfshutter_pressed(void){return 0;} void assign_af_button_to_star_button(void){} void restore_af_button_assignment(void){}
static void unit(int dir){
    if(backlash){if(dir!=pdir){slack=backlash;pdir=dir;} if(slack>0){slack--;return;}} else pdir=dir;
    if(!((dir>0&&phys+dir>limit_hi)||(dir<0&&phys+dir<limit_lo)))phys+=dir;
}
/* r8: BUSY=ms - like the real 5D3 + 18-135, a command within BUSY ms after a +/-3 finished is refused;
   REFMOVE=1 - such a refused +/-3 still moves (FZ7C1C93). */
static int BUSY=0,REFMOVE=0;static uint32_t last_big_end=0;
int lens_focus(int a,int b,int wait,int d){
    int n=absi(b),dir=b>0?1:-1,u,i;
    if(a!=1||!b||n>3)return 0;
    if(BUSY&&last_big_end&&clk-last_big_end<(uint32_t)BUSY){
        if(REFMOVE&&n==3){u=K3+(dir<0?K3ASYM:0);for(i=0;i<u;i++)unit(dir);clk+=20+3*u;hist();last_big_end=clk;}
        clk+=10;return 0;}
    if((dir>0&&phys>=limit_hi)||(dir<0&&phys<=limit_lo)){
        static int ghost=0;
        if(getenv("GHOST")&&n==3&&(ghost++&1)==0){clk+=40;return 1;}   /* real lens: some +/-3 'accepted' at the stop, no motion */
        clk+=15;return 0;}
    u=n==3?K3+(dir<0?K3ASYM:0):(n==2?K2:1);
    for(i=0;i<u;i++)unit(dir);
    clk+=20+3*u+(uint32_t)d;hist();ncmd++;if(n==3)last_big_end=clk;return 1;
}
/* r6: the worker runs search_v17c and restarts it once after a Canon scale change / data loss - same here */
#ifdef IS_A
#define RUN_R6 RUN
#else
static int RUN_R6(void){
    int ok=RUN();
    if((stop_code==S_SCALE||stop_code==S_LOST)&&!restarts){if(stop_code==S_LOST)cfd_forbid=1;restarts=1;note(E_RESTART,stop_code);restart_search_state();ok=RUN();}
    return ok;
}
#endif
struct prof{const char*name;int lo,hi,w,B,K3;};
static struct prof P[]={
 {"18-135@135 2m  ",-12,36,1,2,2},{"18-135@135 2m  ",-12,36,2,1,2},
 {"18-135@135 0.5m",-38,10,1,2,2},{"18-135@135 0.5m",-38,10,2,2,2},
 {"18-135@64  2m  ",-22,51,2,2,3},{"18-135@64  2m  ",-22,51,3,1,3},
 {"18-135@18  2m  ",-30,75,10,2,7},{"18-135@18  2m  ",-30,75,15,2,25},{"18-135@18  2m  ",-30,75,20,2,25},
 {"18-135@18  0.6m",-75,30,10,2,25},{"18-135@18  0.6m",-75,30,15,1,7},
 {"17-55 @55  2m  ",-25,66,2,1,3},{"17-55 @55  2m  ",-25,66,3,0,3},
 {"50STM      2m  ",-110,590,15,2,3},{"50STM      2m  ",-110,590,25,3,3},
 {"18-135@50 1.5m ",-30,32,4,2,20},{"18-135@50 1.5m ",-30,32,6,2,20},
 {"18-135@85 1m   ",-25,30,1,2,15},{"18-135@85 1m   ",-12,43,1,2,15},
 {"18-135@18 34FD ",-45,60,12,2,40},{"18-135@18 34FD ",-45,60,15,2,40}};   /* recreation of FZ7C34FD: big steps jump over the peak */   /* 85mm: peak ~2 units wide (FZ7C3500) */   /* recreation of FZ7C2B5B: start near close focus */
#define NP (int)(sizeof P/sizeof P[0])
static void set_focal(int pi){const char*a=strchr(P[pi].name,'@');lens_info.focal_len=a?atoi(a+1):50;if(rp_n){lens_info.focal_len=rp_focal;lens_info.lens_id=rp_lensid;}}
static void setup(void){
#ifdef IS_A
    speed_setting=1;comp_setting=1;reach_setting=0;focus_region=0;
#else
    speed_setting=getenv("SPEED")?atoi(getenv("SPEED")):1;comp_setting=getenv("COMP")?atoi(getenv("COMP")):3;big_setting=1;focus_region=0;
#endif
}
int main(int argc,char**argv){
    int pi,si,z,seed,nz[3]={0,2,4};
    if(getenv("CFD"))CFD=atoi(getenv("CFD"));
    if(getenv("CFDLAG"))CFDLAG=atoi(getenv("CFDLAG"));
    if(getenv("LAG"))LAG_MS=atoi(getenv("LAG"));
    if(getenv("CFDJUMP"))CFDJUMP=atoi(getenv("CFDJUMP"));
    if(getenv("CFDSTOP"))CFDSTOP=atoi(getenv("CFDSTOP"));
    if(getenv("BUSY"))BUSY=atoi(getenv("BUSY"));
    if(getenv("REFMOVE"))REFMOVE=atoi(getenv("REFMOVE"));
    int verbose=(argc>1&&!strcmp(argv[1],"v"))||getenv("VERBOSE"),np=NP;
    if(argc>2&&!strcmp(argv[1],"replay")){   /* real curve (tests/curves); COMP=6 = AUTO backlash comp from the profile */
        static char nm[64];const char *b=strrchr(argv[2],'/');
        replay_load(argv[2]);snprintf(nm,sizeof nm,"%-15.15s",b?b+1:argv[2]);
        P[0].name=nm;P[0].lo=rp_lo>-100000?rp_lo:-150;P[0].hi=rp_hi<100000?rp_hi:150;P[0].w=3;
        P[0].B=rp_backlash>=0?rp_backlash:2;P[0].K3=rp_k3>0?rp_k3:3;np=1;
    }
    if(argc>4&&!strcmp(argv[1],"one")){   /* one pi start noise seed  (LOGOUT=file for the CSV) */
        int ok;uint32_t t0;pi=atoi(argv[2]);
        limit_lo=P[pi].lo;limit_hi=P[pi].hi;width=P[pi].w;backlash=P[pi].B;K3=getenv("K3")?atoi(getenv("K3")):P[pi].K3;noise_pct=atoi(argv[4]);
        nseed=argc>5?atoi(argv[5]):1;if(argc>6)clk=atoi(argv[6]);target=0;phys=atoi(argv[3]);lens_info.lens_exists=1;set_focal(pi);setup();
        sim_t0=clk;if(CFD)msleep(70);reset_trace();hist();t0=clk;
        ok=RUN_R6();
#ifndef IS_A
        save_trace();
#endif
        printf("ok=%d err=%d ms=%u cmds=%d stop=%d src_first=%d src_last=%d restarts=%d\n",ok,absi(phys-target),clk-t0,ncmd,stop_code,first_source,use_cfd,restarts);return 0;}
    for(pi=0;pi<np;pi++){
        long tot=0,ok1=0,okh=0,good95=0,fails=0,msum=0,mmax=0,cmds=0;double shs=0;
        int fw=2*P[pi].w,starts[8],ns=0,k;
        int cand[8]={0,fw,-fw,3*fw,-3*fw,P[pi].hi-2,P[pi].lo+2,(P[pi].hi+P[pi].lo)/2};
        for(k=0;k<8;k++){int s=cand[k];if(s>P[pi].hi)s=P[pi].hi;if(s<P[pi].lo)s=P[pi].lo;starts[ns++]=s;}
        for(si=0;si<ns;si++)for(z=0;z<3;z++)for(seed=0;seed<3;seed++){
            int fd[2];pipe(fd);fflush(stdout);
            if(fork()==0){
                int ok;uint32_t t0;double sh;int err;
                close(fd[0]);
                limit_lo=P[pi].lo;limit_hi=P[pi].hi;width=P[pi].w;backlash=P[pi].B;K3=P[pi].K3;
                if(getenv("K3"))K3=atoi(getenv("K3"));
                noise_pct=nz[z];nseed=seed*7+si*13+pi*101+1;target=0;phys=starts[si];slack=0;pdir=0;hn=0;
                clk=1000+seed*17+si*5;last_fi=0xFFFFFFFFu;last_big_end=0;lens_info.lens_exists=1;lens_info.job_state=0;
                worker_exit=cancel_request=0;set_focal(pi);setup();
                sim_t0=clk;cfd_last_fi=0xFFFFFFFFu;if(CFD)msleep(70);     /* r6: Canon data flowing before the run */
                reset_trace();hist();t0=clk;
                ok=RUN_R6();
                err=absi(phys-target);sh=(double)(contrast_at(phys)-6)/(contrast_at(target)-6);
                if(getenv("DEBUGEND"))fprintf(stderr,"start %d phys %d canon_at %d contrast_at %d lastcab %u slack %d\n",starts[si],phys,canon_at(phys),contrast_at(phys),cfd_v[2]+cfd_v[3],slack);
                if(getenv("TRACEPI")&&atoi(getenv("TRACEPI"))==pi&&getenv("TRACEST")&&atoi(getenv("TRACEST"))==starts[si]&&getenv("TRACEZ")&&atoi(getenv("TRACEZ"))==z&&getenv("TRACESEED")&&atoi(getenv("TRACESEED"))==seed)save_trace();   /* dev: CSV of one run via LOGOUT */
                if(verbose)printf("%s w=%d start=%4d noise=%d seed=%u clk0=%u -> ok=%d err=%d sharp=%.2f ms=%u stop=%d\n",P[pi].name,P[pi].w,starts[si],nz[z],nseed,t0,ok,err,sh,clk-t0,stop_code);
                fflush(stdout);{char b[128];int n=snprintf(b,sizeof b,"%d %d %f %u %d\n",ok,err,sh,clk-t0,ncmd);write(fd[1],b,n);}
                _exit(0);
            }
            close(fd[1]);
            {char b[128]={0};int n=read(fd[0],b,127),ok,err,cm;float sh;unsigned ms;close(fd[0]);wait(0);
             if(n>0&&sscanf(b,"%d %d %f %u %d",&ok,&err,&sh,&ms,&cm)==5){
                tot++;if(!ok)fails++;if(err<=1)ok1++;if(err*2<=fw)okh++;if(sh>=0.95)good95++;shs+=sh;msum+=ms;if(ms>mmax)mmax=ms;cmds+=cm;}}
        }
        printf("%s w=%2d(FWHM~%2d) B=%d K3=%2d | runs %3ld  sharp>=95%%: %5.1f%%  mean sharp %.2f  err<=1u: %5.1f%%  fail %3ld | mean %5.0f ms (max %5ld)  cmds %.0f\n",
            P[pi].name,P[pi].w,fw,P[pi].B,P[pi].K3,tot,100.0*good95/tot,shs/tot,100.0*ok1/tot,fails,(double)msum/tot,mmax,(double)cmds/tot);
    }
    return 0;
}
