/*
 * FZ17C - Canon EOS 70D 1.1.2 and 5D Mark III 1.1.3 (-DCAM_5D3) - V17C r6 hybrid contrast AF.
 *
 * r8 (18 Oct 2026, after r7 runs FZ7C1C87-1C95, 18-135 at 35 / 85 mm; Canon data only, YUV path unchanged):
 *   - at 85 mm one +/-3 is huge (C93/C8F crawled back 60-80 +/-1 units after one +/-3 past the peak): when the
 *     big steps pass the peak, jump BACK the same number of +/-3 and scan finely around there (+/-1 from 10 units
 *     below) instead of crawling back unit by unit;
 *   - the lens sometimes refuses a command right after a big move (C95: the first +1 after a -3 refused -> taken
 *     as an end stop -> walked the wrong way; C93: a "refused" +3 had moved). A refused +/-1 is retried once after
 *     150 ms; a refused +/-3 is first checked (did the picture change? then it moved) and else retried once;
 *   - narrow peak + Canon: strides capped at 2 (Canon's peak is about half as wide).
 *
 * r7 (18 Oct 2026, after the first r6 camera runs FZ7CA293-A2A0, 5D3 + 18-135 at 27/76 mm):
 *   - with Canon data the run ALWAYS starts with a small exact look around the start (+/-3, then +/-6 if
 *     that is flat): a start that is already the sharpest is only fine-tuned there. r6 jumped +/-3 first
 *     from in-focus starts at 76 mm (A29D/A29F/A2A0) and never got back - a +/-3 there is long and not
 *     reversible;
 *   - faster Canon samples: skip 1 new Canon frame after a move (was 2) and use 1 value (2 on CAREFUL):
 *     r6 needed ~170 ms per sample at 24p, runs took 6-11 s and were let go;
 *   - narrow peak with Canon: profile FWHM <= 16 units, else >= 70 mm; a profile that only has a 70 pct
 *     width ("broad") no longer switches it off (the 85 mm profile line did that at 76 mm -> strides of 8).
 *
 * r6 (18 Oct 2026): Canon's own LiveView focus measurement as the sharpness source (new menu "V17C Sharpness",
 *   default CANON AF DATA). On the 5D3 Canon sends PROP_LV_FOCUS_DATA every frame (the data behind Magic Zoom's
 *   green); the user's CFD39301 log showed its peak 4 frames (~170 ms) EARLIER than our preview metric, about
 *   half as wide, with twice the sharp/blur ratio. V17C r6:
 *   - uses fv = (v2+v3)<<5 when Canon data is arriving at the start of a run, else the YUV metric (70D: always);
 *   - waits for NEW Canon values after each move (settle = 1-2 Canon frames) instead of a fixed 75-90 ms
 *     (on the 5D3 the preview needs ~4 frames, so the old settle read stale pictures);
 *   - Canon changes its scale when its own AF / exposure state changes (CFD39301 at 16 s and 18 s): v1 jumping
 *     outside 0.7-1.43x of the run's start value stops the run (stop 14), returns home and restarts ONCE with a
 *     fresh baseline; Canon data stopping for 300 ms (stop 15) restarts once with the YUV metric;
 *   - "narrow peak" with Canon data: profile FWHM (measured with YUV) <= 16 units, or >= 50 mm without one;
 *   - CSV: source, restarts, Canon values per row. The YUV path is unchanged (70D identical to r5).
 *
 * r5 (16 Oct 2026): half-shutter trigger (new menu "V17C Trigger", default HALF-SHUTTER): press and hold the
 *   shutter half-way = one fast AF run; let go = stop at once, lens stays where it is. Canon AF is moved to the
 *   * button while this mode is on. CAMF C3 pauses while the half-press is held.
 *
 * r4 (16 Oct 2026): reads the lens profile CAMCAL writes (ML/LPxxxx.TXT, src/common/LENS_PROFILE.h).
 *   - "narrow peak" (stride cap 4 + small first probe) comes from the measured peak width when there is a
 *     profile for this lens near this focal length; otherwise the r3 focal-length rule (>= 70 mm);
 *   - Backlash Comp has a new AUTO setting (now the default): measured backlash rounded up +1, 3 without profile;
 *   - CSV header shows whether a profile was used. Without a profile r4 behaves exactly like r3.
 *
 * r3 (after FZ7C34FD-3500):
 *   - if the + probe looks exactly like the start (it may not have moved: a +/-3 'accepted' at a
 *     stop), look after the first -3 too, so the big steps cannot skip the peak (FZ7C34FD: the
 *     skipped point was the focus, and the climb back crawled 37 units);
 *   - at 70mm and longer strides are capped at 4 (85mm peak is ~2 units wide);
 *   - on flat blur (no rise yet, stride already grown) one dip is not enough: two in a row;
 *     likewise in the big-step phase a small dip needs a second drop (a big one counts at once).
 *
 * r2 (after the first camera test, FZ7C2B59-2B5E):
 *   - at 70mm and longer a small exact +/-4 look around the start comes first: if the start is
 *     already the sharpest it fine-tunes right there; a clear slope sends the big steps straight
 *     that way. (At the wide end a +/-3 is ~25 units and the hill is broad: big steps first.)
 *   - if both +/-3 probes are under 35% of the start (narrow hill), jump back to about the start
 *     and look there instead of crawling back from one big step away;
 *   - ANY refused +/-3 counts as the end stop (the lens 'accepts' some at the stop).
 *
 *   FAST PART  (V17A style): +/-3 probes and a +/-3 climb get close to the peak quickly.
 *              One +/-3 is a different size at every focal length (about 25 +/-1 units at
 *              19mm in the user's own FZ17A/FZ17B logs), so these positions are never reused.
 *   EXACT PART (V17B style): from just past the peak, climb back with +/-1 commands only
 *              (adaptive stride), re-scan if needed, parabola, land arriving the same way
 *              the samples were taken, verify against the best sample, polish +/-1.
 *
 * Dark-frame check fixed: only an almost all-black centre is rejected (the old 50% rule
 * threw away the in-focus frames of a subject on a black background).
 * Tells the user on screen when Canon Movie Servo AF / MF switch etc. block it.
 * Sharpness is the YUV preview metric of V17A. NOT camera tested.
 */
#define MODULE
#define MODULE_NAME fz17c
#include <stdint.h>
#include "module.h"
#include "dryos.h"
#include "menu.h"
#include "config.h"


/* ===================== CAMERA PROFILE (the ONLY camera-specific part of this file) =====================
 * Default build = Canon EOS 70D fw 1.1.2.   Build with -DCAM_5D3 = Canon EOS 5D Mark III fw 1.1.3.
 * Both: Magic Lantern module API 8, DIGIC 5, LiveView YUV422 preview, CBR_VSYNC once per LiveView frame.
 * Only text and the is_camera() check differ. Keep the 70D strings byte-identical (proves 70D unchanged). */
#if defined(CAM_5D3)
#define CAM_MODEL        "5D3"
#define CAM_FW           "1.1.3"
#define CAM_CSV_TAG      " [5D3 1.1.3]"
#define CAM_SERVO        "continuous AF"          /* 5D3 has no Movie Servo AF; ML reports none in movie mode */
#define CAM_SERVO_MUST   "Canon continuous AF must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (Live View switch to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, lens on AF, continuous AF OFF"
#else   /* default: 70D */
#define CAM_MODEL        "70D"
#define CAM_FW           "1.1.2"
#define CAM_CSV_TAG      ""
#define CAM_SERVO        "Movie Servo AF"
#define CAM_SERVO_MUST   "Movie Servo must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (mode dial to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, AF lens, Movie Servo OFF"
#endif
/* ======================================================================================================== */
extern int is_camera(const char*,const char*);
extern int get_halfshutter_pressed(void);              /* r5: half-shutter trigger (ML core, as in dot_tune) */
extern void assign_af_button_to_star_button(void);     /* r5: move Canon AF off the half-press while we own it */
extern void restore_af_button_assignment(void);
extern int is_movie_mode(void);
extern uint32_t get_ms_clock(void);
extern void msleep(int);
extern int task_create(const char*,int,int,void(*)(void*),void*);
extern int FIO_CreateFile(const char*);
extern int FIO_WriteFile(int,const void*,unsigned);
extern int FIO_CloseFile(int);
extern void menu_remove(const char*,struct menu_entry*,int);
extern int lv;
extern int is_manual_focus(void);
extern int is_continuous_af(void);
extern int lens_focus(int,int,int,int);
extern void NotifyBox(int timeout,const char *fmt,...);
struct vram_info_probe { uint8_t *vram; int width,pitch,height; };
extern struct vram_info_probe *get_yuv422_vram(void);
struct lens_info_probe
{
    void *token;
    char name[32];
    unsigned focal_len;
    unsigned focus_dist;
    unsigned IS;
    unsigned aperture;
    int ae;
    unsigned shutter;
    unsigned iso;
    unsigned iso_auto;
    unsigned iso_analog_raw;
    int iso_digital_ev;
    unsigned iso_equiv_raw;
    unsigned hyperfocal;
    unsigned dof_near;
    unsigned dof_far;
    unsigned job_state;
    unsigned wb_mode;
    unsigned kelvin;
    unsigned WBGain_R;
    unsigned WBGain_G;
    unsigned WBGain_B;
    int8_t wbs_gm;
    int8_t wbs_ba;
    unsigned picstyle;
    uint8_t raw_aperture;
    uint8_t raw_shutter;
    uint8_t raw_iso;
    uint8_t raw_iso_auto;
    uint8_t raw_picstyle;
    uint8_t raw_aperture_min;
    uint8_t raw_aperture_max;
    int flash_ae;
    uint16_t lens_id;
    uint16_t dof_flags;
    int dof_diffraction_blur;
    int focus_pos;
    uint8_t lens_exists;
};
extern struct lens_info_probe lens_info;
#include "../common/LENS_PROFILE.h"      /* r4: per-lens numbers measured by CAMCAL (ML/LPxxxx.TXT) */

/* ---- r6: Canon's LiveView focus data (PROP_LV_FOCUS_DATA 0x80050026, 8 ints, every frame on the 5D3; never on
   the 70D). ML core uses v2+v3 as Magic Zoom's focus value. Handler runs in PropMgrTask: copy and return. ---- */
#define PROP_LV_FOCUS_DATA 0x80050026u
static volatile uint32_t cfd_seq=0,cfd_ms=0;
static volatile uint32_t cfd_v[8];
static void cfd_handler(unsigned int property,void *priv,uint32_t *buf,unsigned int len)
{
    unsigned n=len>>2,i;
    (void)property;(void)priv;
    if(!buf)return;
    if(n>8)n=8;
    for(i=0;i<n;i++)cfd_v[i]=buf[i];
    cfd_ms=get_ms_clock();cfd_seq++;
}
static module_prophandler_t cfd_block={"PROP_LV_FOCUS_DATA",cfd_handler,PROP_LV_FOCUS_DATA,0};
module_prophandler_t *__module_prophandlers_fz17c[]={&cfd_block,0};

/* Bounded movement limits are COMMAND units, not measured physical travel.
 * Extended search is conditional on fresh, rising optical evidence. */

#define TRACE_MAX 300
#define FRAME_MAX 7
#define TIGHT_W 80
#define TIGHT_H 60
#define MED_W 120
#define MED_H 80
#define WIDE_W 180
#define WIDE_H 120
#define TIGHT_SAMPLES 1200u
#define TIGHT_PAIRS 2400u
#define SCAN_MAX 64
#define SMAX_FINE 8          /* largest stride made of +/-1 commands */
#define FINE_REACH 40        /* +/-1 units one climb may travel without any rise */
#define UNITS_MAX 480        /* +/-1 units per run */
#define JUMPS_MAX 40         /* +/-3 commands per run */
#define TIME_MAX_MS 16000

enum { E_START=1,E_SAMPLE=2,E_MOVE=3,E_JUMP=4,E_PROBE=5,E_RETURN=6,E_DIRECTION=7,
       E_NEW_BEST=8,E_DROP=9,E_BRACKET=10,E_REFINE=11,E_VERIFY=12,E_ACCEPT=13,E_ABORT=14,
       E_CLIP_ADVISORY=16,E_RETRY=17,E_NO_HILL=18,E_MEASURE=19,E_STOP_HIT=30,
       E_RESTORE=34,E_STRIDE=35,E_COARSE=36,E_HOME_LOST=37,E_POLISH=38,E_LAND=39,E_RW_DISAGREE=40,
       E_WORSE=41,E_SOURCE=42,E_RESTART=43 };
enum { S_OK=0,S_GATE=1,S_MOTOR=2,S_IMAGE=3,S_BUDGET=4,S_NO_BRACKET=5,
       S_REPRO=6,S_WEAK=7,S_LIMIT=8,S_EDGE=9,S_NO_DIRECTION=10,S_CANCEL=11,
       S_NO_HILL=12,S_WORSE=13,S_SCALE=14,S_LOST=15 };
enum { I_OK=0,I_NO_DESC=1,I_NULL_PTR=2,I_BAD_ADDR=3,I_BAD_GEOM=4,
       I_EMPTY=5,I_TOO_DARK=6,I_TOO_BRIGHT=7,I_UNSTABLE=8,
       I_NO_CONTRAST=9,I_CANCEL=10,I_CANON_LOST=11,I_CANON_SCALE=12 };
enum { P_BASE=1,P_PROBE=2,P_CLIMB=3,P_FINE=4,P_COARSE=5,P_REFINE=6,P_LAND=7,P_POLISH=8,P_RESTORE=9 };

static CONFIG_INT("fz17c.run",af_request,0);
static CONFIG_INT("fz17c.measure",measure_request,0);
static CONFIG_INT("fz17c.cancel",cancel_request,0);
static CONFIG_INT("fz17c.trigger",trigger_setting,1);  /* r5: 0 menu only, 1 half-shutter (hold to focus) */
static volatile int hs_run=0,hs_released=0;            /* r5: this run was started by a half-press / was let go */
static CONFIG_INT("fz17c.region",focus_region,0);
static CONFIG_INT("fz17c.speed",speed_setting,1);  /* 0 fastest 1 balanced 2 careful */
static CONFIG_INT("fz17c.comp",comp_setting,6);    /* backlash pad in +/-1 units: 0,1,2,3,4,6, 6=AUTO (r4 default: profile, else 3) */
static CONFIG_INT("fz17c.big",big_setting,1);      /* approach: 1 = +/-3 big steps (fast), 0 = +/-1 only (V17B) */
static CONFIG_INT("fz17c.source",source_setting,1); /* r6: 0 YUV preview, 1 Canon AF data when it arrives (default) */
static int use_cfd=0,cfd_forbid=0,restarts=0,first_source=0;   /* r6 */
static uint32_t cfd_used=0,cfd_ref_v1=0,cfd_seq0=0,run_max=0,run_min=0;   /* r6: range of Canon values seen this attempt */
static volatile int worker_busy=0,worker_exit=0;
static uint32_t run_start,log_serial;
static int offset_units,total_units,move_count,last_direction;
static int stop_code,image_reason,last_motor_rc,confidence;
static int best_offset,trace_count,trace_dropped;
static int last_buf_w,last_buf_h,last_buf_pitch;
static uint32_t last_buf_addr;
static int phase,stride_now,home_known,net3,jumps,restored;
static uint32_t last_fv;

struct score {
    uint32_t raw,wide,luma,raw_t,raw_m,raw_w,wide_t,wide_m,wide_w;
    uint32_t raw_noise,wide_noise;
    uint32_t clipped,dark,samples;
};
static struct score current;
static void clear_score(struct score *s)
{
    volatile uint32_t *p=(volatile uint32_t*)s;
    unsigned i;
    for(i=0;i<sizeof(*s)/sizeof(uint32_t);i++)p[i]=0;
}
struct point {
    uint32_t ms;
    struct score v;
    int event,off,best,span,dir,units,moves,stop,reason,gate,rc;
    int lens_focus_pos,lens_focus_dist,buf_w,buf_h,buf_pitch;
    uint32_t buf_addr;
    int phase,stride,home,jumps;uint32_t fv;
    uint32_t cab,cv1,cseq;int src;          /* r6: Canon v2+v3, v1, event count, source in use */
};
static struct point trace[TRACE_MAX];

/* Volatile loop prevents an accidental ARM libgcc memset dependency. */
static int absi(int v) { return v<0?-v:v; }
static uint32_t maxu(uint32_t a,uint32_t b) { return a>b?a:b; }
static uint32_t divu(uint32_t n,uint32_t d)
{
    uint32_t q=0,b=1;
    if (!d) return 0;
    while (d<n && !(d&0x80000000u)) {d<<=1;b<<=1;}
    while (b) {if(n>=d){n-=d;q|=b;}d>>=1;b>>=1;}
    return q;
}
#ifdef UNIT_TEST
static int valid_addr(uint32_t a){return a!=0;}
#else
static int valid_addr(uint32_t a){return a>=0x1000u && a<0x80000000u && !(a&3u);}
#endif
static int gate(void)
{
    int g=0;
    if (!lv)g|=1;
    if (!is_movie_mode())g|=2;
    if (is_manual_focus())g|=4;
    if (is_continuous_af())g|=8;
    if (!lens_info.lens_exists)g|=16;
    if (lens_info.job_state)g|=32;
    if (cancel_request||worker_exit)g|=64;
    if (hs_run&&!get_halfshutter_pressed()){hs_released=1;g|=64;}   /* r5: half-shutter let go = stop where it is */
    return g;
}
static void note(int ev,int span)
{
    struct point *p;
    if(trace_count>=TRACE_MAX){trace_dropped++;return;}
    p=&trace[trace_count++];
    p->ms=get_ms_clock()-run_start;p->v=current;
    p->event=ev;p->off=offset_units;p->best=best_offset;
    p->span=span;p->dir=last_direction;p->units=total_units;
    p->moves=move_count;p->stop=stop_code;p->reason=image_reason;
    p->gate=gate();p->rc=last_motor_rc;
    p->lens_focus_pos=lens_info.focus_pos;
    p->lens_focus_dist=(int)lens_info.focus_dist;
    p->buf_addr=last_buf_addr;p->buf_w=last_buf_w;
    p->buf_h=last_buf_h;p->buf_pitch=last_buf_pitch;
    p->phase=phase;p->stride=stride_now;p->home=home_known;p->jumps=jumps;p->fv=last_fv;
    p->cab=cfd_v[2]+cfd_v[3];p->cv1=cfd_v[1];p->cseq=cfd_seq-cfd_seq0;p->src=use_cfd;
}
/* Per-frame metric reproduces V16Z's +/-2 and +/-6-pixel luma gradients,
 * with nested wide/medium/tight focus regions and fixed 40:35:25 weights.
 * The display geometry and buffer are re-read for EVERY frame. */
static int sample_frame(struct score *v)
{
    struct vram_info_probe *vi=get_yuv422_vram();
    uint8_t *buf;
    uint32_t raw[3]={0,0,0},wg[3]={0,0,0},lum[3]={0,0,0};
    uint32_t count[3]={0,0,0},pairs[3]={0,0,0};
    uint32_t normal_raw[3],normal_wide[3];
    int x,y,cx,cy,x0,x1,y0,y1,w,h,pitch,k;
    v->raw=v->wide=v->luma=0;
    v->raw_t=v->raw_m=v->raw_w=0;
    v->wide_t=v->wide_m=v->wide_w=0;
    v->raw_noise=v->wide_noise=0;
    v->clipped=v->dark=v->samples=0;
    image_reason=I_OK;
    if (!vi){image_reason=I_NO_DESC;return 0;}
    buf=vi->vram;w=vi->width;h=vi->height;pitch=vi->pitch;
    last_buf_addr=(uint32_t)buf;last_buf_w=w;last_buf_h=h;last_buf_pitch=pitch;
    if (!buf){image_reason=I_NULL_PTR;return 0;}
    if (!valid_addr((uint32_t)buf)){image_reason=I_BAD_ADDR;return 0;}
    if(w<240 || h<180 || pitch<w*2 || pitch>8192){image_reason=I_BAD_GEOM;return 0;}
    cx=w/2;cy=h/2;
    x0=cx-WIDE_W;x1=cx+WIDE_W;y0=cy-WIDE_H;y1=cy+WIDE_H;
    if(x0<8)x0=8;if(y0<8)y0=8;
    if(x1>w-9)x1=w-9;if(y1>h-9)y1=h-9;
    for(y=y0;y<y1;y+=4)
    {
        uint8_t *r=buf+y*pitch,*up=buf+(y-2)*pitch,*dn=buf+(y+2)*pitch;
        uint8_t *wu=buf+(y-6)*pitch,*wd=buf+(y+6)*pitch;
        for(x=x0;x<x1;x+=4)
        {
            int off=(x<<1)+1;
            int yc=r[off],yl=r[((x-2)<<1)+1],yr=r[((x+2)<<1)+1];
            int yu=up[off],yd=dn[off];
            int wl=r[((x-6)<<1)+1],wr=r[((x+6)<<1)+1];
            int vw=wu[off],vx=wd[off];
            uint32_t g=(uint32_t)(absi(yr-yl)+absi(yd-yu));
            uint32_t gw=0,ng=0;
            if(wl>3&&wl<252&&wr>3&&wr<252){gw+=(uint32_t)absi(wr-wl);ng++;}
            if(vw>3&&vw<252&&vx>3&&vx<252){gw+=(uint32_t)absi(vx-vw);ng++;}
            /* 0 wide, 1 medium, 2 tight: nested region statistics. */
            for(k=0;k<3;k++)
            {
                if(k==1 && (x<cx-MED_W||x>=cx+MED_W||y<cy-MED_H||y>=cy+MED_H)) continue;
                if(k==2 && (x<cx-TIGHT_W||x>=cx+TIGHT_W||y<cy-TIGHT_H||y>=cy+TIGHT_H)) continue;
                raw[k]+=g;wg[k]+=gw;lum[k]+=(uint32_t)yc;
                count[k]++;pairs[k]+=ng;
            }
            if(x>=cx-TIGHT_W&&x<cx+TIGHT_W&&y>=cy-TIGHT_H&&y<cy+TIGHT_H)
            {
                v->samples++;if(yc<=16)v->dark++;if(yc>=235)v->clipped++;
            }
        }
    }
    if (!count[2]||!pairs[2]){image_reason=I_EMPTY;return 0;}
    for(k=0;k<3;k++)
    {
        uint32_t mean=count[k]?divu(lum[k],count[k]):1u;
        uint32_t rscore=count[k]?divu(raw[k],count[k])*TIGHT_SAMPLES:0;
        uint32_t wscore=pairs[k]?divu(wg[k],pairs[k])*TIGHT_PAIRS:0;
        normal_raw[k]=divu(rscore*256u,mean?mean:1u);
        normal_wide[k]=divu(wscore*256u,mean?mean:1u);
    }
    v->raw=raw[2];v->wide=wg[2];v->luma=divu(lum[2],count[2]);
    v->raw_t=normal_raw[2];v->raw_m=normal_raw[1];v->raw_w=normal_raw[0];
    v->wide_t=normal_wide[2];v->wide_m=normal_wide[1];v->wide_w=normal_wide[0];
    if (v->luma<12){image_reason=I_TOO_DARK;return 0;}
    if (v->luma>242){image_reason=I_TOO_BRIGHT;return 0;}
    /* only reject an (almost) all-black centre: a sharp subject on black has MORE near-black pixels in focus */
    if (v->dark > v->samples - v->samples/10){image_reason=I_TOO_DARK;return 0;}
    if(!v->raw||!v->wide){image_reason=I_NO_CONTRAST;return 0;}
    return 1;
}
static void sort_scores(uint32_t *a,int n)
{
    int i,j;for(i=1;i<n;i++){uint32_t k=a[i];j=i-1;while(j>=0&&a[j]>k){a[j+1]=a[j];j--;}a[j+1]=k;}
}
static uint32_t median(uint32_t *a,int n)
{
    uint32_t b[FRAME_MAX];int i;
    for(i=0;i<n;i++)b[i]=a[i];sort_scores(b,n);return b[n/2];
}
static uint32_t mad(uint32_t *a,int n,uint32_t med)
{
    uint32_t b[FRAME_MAX];int i;
    for(i=0;i<n;i++)b[i]=a[i]>med?a[i]-med:med-a[i];
    sort_scores(b,n);return b[n/2];
}
static int measure_bundle(struct score *v,int n)
{
    struct score f;uint32_t rs[FRAME_MAX],ws[FRAME_MAX],ls[FRAME_MAX];
    uint32_t rt[FRAME_MAX],rm[FRAME_MAX],rw[FRAME_MAX];
    uint32_t wt[FRAME_MAX],wm[FRAME_MAX],ww[FRAME_MAX];
    int i,retry;
    uint32_t clip=0,dark=0,samples=0;
    for(i=0;i<n;i++)
    {
        if (gate()) {image_reason=I_CANCEL;return 0;}
        for(retry=0;retry<6;retry++)
        {
            if(sample_frame(&f))break;
            if(gate()){image_reason=I_CANCEL;return 0;}
            msleep(35);
        }
        if(retry==6)return 0;
        rs[i]=f.raw;ws[i]=f.wide;ls[i]=f.luma;
        rt[i]=f.raw_t;rm[i]=f.raw_m;rw[i]=f.raw_w;
        wt[i]=f.wide_t;wm[i]=f.wide_m;ww[i]=f.wide_w;
        clip+=f.clipped;dark+=f.dark;samples+=f.samples;
        if(i!=n-1)msleep(35);
    }
    v->raw=median(rs,n);v->wide=median(ws,n);v->luma=median(ls,n);
    v->raw_t=median(rt,n);v->raw_m=median(rm,n);v->raw_w=median(rw,n);
    v->wide_t=median(wt,n);v->wide_m=median(wm,n);v->wide_w=median(ww,n);
    v->raw_noise=mad(rs,n,v->raw);v->wide_noise=mad(ws,n,v->wide);
    v->clipped=clip;v->dark=dark;v->samples=samples;
    return 1;
}
static int measure_optical(int stable)
{
    struct score b[3];uint32_t r[3],w[3];int i,rounds=stable?3:1,fail=0;
    msleep(stable?100:85);
    for(i=0;i<rounds;i++)
    {
        if(i)msleep(90);
        if(!measure_bundle(&b[i],stable?7:5)){fail=1;break;}
        r[i]=b[i].raw;w[i]=b[i].wide;
    }
    if (fail){stop_code=S_IMAGE;note(E_ABORT,0);return 0;}
    current=b[0];
    if(stable)
    {
        current.raw=median(r,3);current.wide=median(w,3);
        current.raw_noise=maxu(b[0].raw_noise,maxu(b[1].raw_noise,b[2].raw_noise));
        current.wide_noise=maxu(b[0].wide_noise,maxu(b[1].wide_noise,b[2].wide_noise));
        current.raw_noise=maxu(current.raw_noise,mad(r,3,current.raw));
        current.wide_noise=maxu(current.wide_noise,mad(w,3,current.wide));
        current.luma=median((uint32_t[3]){b[0].luma,b[1].luma,b[2].luma},3);
        current.raw_t=median((uint32_t[3]){b[0].raw_t,b[1].raw_t,b[2].raw_t},3);
        current.raw_m=median((uint32_t[3]){b[0].raw_m,b[1].raw_m,b[2].raw_m},3);
        current.raw_w=median((uint32_t[3]){b[0].raw_w,b[1].raw_w,b[2].raw_w},3);
        current.wide_t=median((uint32_t[3]){b[0].wide_t,b[1].wide_t,b[2].wide_t},3);
        current.wide_m=median((uint32_t[3]){b[0].wide_m,b[1].wide_m,b[2].wide_m},3);
        current.wide_w=median((uint32_t[3]){b[0].wide_w,b[1].wide_w,b[2].wide_w},3);
        current.clipped=b[0].clipped+b[1].clipped+b[2].clipped;
        current.dark=b[0].dark+b[1].dark+b[2].dark;
        current.samples=b[0].samples+b[1].samples+b[2].samples;
    }
    /* Bright highlights are advisory; true temporal jitter remains fatal. */
    if (current.raw_noise > current.raw/20u+1u ||
        current.wide_noise > current.wide/20u+1u)
    {
        image_reason=I_UNSTABLE;
        if(!stable){note(E_RETRY,0);msleep(135);return measure_optical(1);}
        stop_code=S_IMAGE;note(E_ABORT,0);return 0;
    }
    image_reason=I_OK;
    if(current.samples && current.clipped>current.samples/10u)note(E_CLIP_ADVISORY,0);
    note(E_SAMPLE,stable);return 1;
}

/* The original 40% wide region can favour a detailed background over a
 * low-texture can in the centre. Default to centre-weighted measurements,
 * but retain the old balanced mode for comparison and diagnostic tests. */
static uint32_t blend_raw(void)
{
    if(focus_region) return divu(current.raw_w*40u+current.raw_m*35u+current.raw_t*25u,100u);
    return divu(current.raw_w*15u+current.raw_m*30u+current.raw_t*55u,100u);
}
static uint32_t blend_wide(void)
{
    if(focus_region) return divu(current.wide_w*40u+current.wide_m*35u+current.wide_t*25u,100u);
    return divu(current.wide_w*15u+current.wide_m*30u+current.wide_t*55u,100u);
}
static int above_bp(uint32_t a,uint32_t b,int bp)
{
    if (!b)return a>0;
    return (uint64_t)a*10000u >= (uint64_t)b*(uint32_t)(10000+bp);
}static void abort_now(int code)
{
    if(!stop_code)stop_code=code;note(E_ABORT,code);
}
/* One waited focus command. Default = the convention the V5-V7 parfocal and
 * V16/V17 modules use on this camera: num_steps=1, direction in the sign of
 * step_size. Build with -DFZ_SIGN_IN_NUM_STEPS for the other form. */
static int focus_cmd(int dir,int mag,int delay)
{
#ifdef FZ_SIGN_IN_NUM_STEPS
    return lens_focus(dir,mag,1,delay);
#else
    return lens_focus(1,dir*mag,1,delay);
#endif
}
/* Signed division rounded to nearest; uses divu so no libgcc import. */
static int divs(int a,int b)
{
    int neg=0;uint32_t ua,ub,q;
    if(!b)return 0;
    if(a<0){a=-a;neg^=1;}
    if(b<0){b=-b;neg^=1;}
    ua=(uint32_t)a;ub=(uint32_t)b;
    q=divu(ua*2u+ub,ub*2u);
    return neg?-(int)q:(int)q;
}
static int clampi(int v,int lo,int hi){return v<lo?lo:(v>hi?hi:v);}

/* Single scalar focus value (V17A): fine (+/-2px) plus coarse (+/-6px) gradient,
 * both luma-normalised and region-weighted. */
static uint32_t fv_from(const struct score *v)
{
    uint32_t r,w;
    if(focus_region)
    {
        r=divu(v->raw_w*40u+v->raw_m*35u+v->raw_t*25u,100u);
        w=divu(v->wide_w*40u+v->wide_m*35u+v->wide_t*25u,100u);
    }
    else
    {
        r=divu(v->raw_w*15u+v->raw_m*30u+v->raw_t*55u,100u);
        w=divu(v->wide_w*15u+v->wide_m*30u+v->wide_t*55u,100u);
    }
    return r+w;
}
static int frames_per_probe(void){return speed_setting>=2?3:(speed_setting==1?2:1);}
/* LiveView shows the lens about one frame late: wait at least ~2 frames after a move before reading */
static int settle_ms(void){return speed_setting>=2?90:75;}

/* ---- r6: Canon source ---- */
static int cfd_fresh(void){return cfd_seq&&(int)(get_ms_clock()-cfd_ms)<250;}
/* new Canon frames to discard after a move before a value counts (motion may be inside the one in progress) */
static int cfd_skip(void){return 2;}   /* r7: 1 was too few when Canon lags more than one frame (sim) */
/* next NEW Canon value as fv. 0 = abort (gate, data stopped = S_LOST, scale jump = S_SCALE) */
static int cfd_next(uint32_t *fv)
{
    uint32_t t0=get_ms_clock(),v,v1;
    while(cfd_seq==cfd_used)
    {
        if(gate()){image_reason=I_CANCEL;abort_now(S_GATE);return 0;}
        if((int)(get_ms_clock()-t0)>300){image_reason=I_CANON_LOST;abort_now(S_LOST);return 0;}
        msleep(5);
    }
    cfd_used=cfd_seq;
    v=cfd_v[2]+cfd_v[3];v1=cfd_v[1];
    if(cfd_ref_v1&&(v1*10u<cfd_ref_v1*7u||v1*7u>cfd_ref_v1*10u))
    {   /* Canon switched its measurement scale (its own AF / exposure state): values no longer comparable */
        image_reason=I_CANON_SCALE;abort_now(S_SCALE);return 0;
    }
    if(v>(1u<<24))v=1u<<24;
    *fv=v<<5;                                   /* same magnitude range as the YUV metric (fits the >>6 maths) */
    return 1;
}
static void cfd_wait_new(int k)
{
    uint32_t t0=get_ms_clock(),s=cfd_seq;
    while((int)(cfd_seq-s)<k&&(int)(get_ms_clock()-t0)<300&&!gate())msleep(5);
    (void)s;cfd_used=cfd_seq;   /* the value read next must be newer than the ones skipped */
}

static int tol_bp;
static uint32_t f_start,final_fv;
static int target10,arrive_dir,polished,rw_disagree,off_c0,off_c1;

/* settle, then read n frames (1: as is, 2: mean, 3+: median) */
static int take(uint32_t *fv,int extra)
{
    struct score f;uint32_t v[5];int n=(use_cfd?(speed_setting>=2?2:1):frames_per_probe())+extra,i,retry;   /* r7: 1 Canon value */
    if(n>5)n=5;
    if(use_cfd)
    {   /* r6: Canon values - skip the frame(s) that may contain the move, then n new ones (no fixed sleeps) */
        cfd_wait_new(cfd_skip());
        for(i=0;i<n;i++)if(!cfd_next(&v[i]))return 0;
        if(sample_frame(&f))current=f;          /* preview only for the log (luma etc.); it lags ~4 frames */
        if(n==1)*fv=v[0];
        else if(n==2)*fv=(v[0]>>1)+(v[1]>>1);
        else *fv=median(v,n);
        if(*fv>run_max)run_max=*fv;
        if(!run_min||*fv<run_min)run_min=*fv;
        image_reason=I_OK;last_fv=*fv;
        note(E_SAMPLE,n);
        return 1;
    }
    msleep(settle_ms());
    for(i=0;i<n;i++)
    {
        if(gate()){image_reason=I_CANCEL;abort_now(S_GATE);return 0;}
        for(retry=0;retry<4;retry++)
        {
            if(sample_frame(&f))break;
            if(gate()){image_reason=I_CANCEL;abort_now(S_GATE);return 0;}
            msleep(35);
        }
        if(retry==4){abort_now(S_IMAGE);return 0;}
        current=f;v[i]=fv_from(&f);
        if(i!=n-1)msleep(34);
    }
    if(n==1)*fv=v[0];
    else if(n==2)*fv=(v[0]>>1)+(v[1]>>1);
    else *fv=median(v,n);
    image_reason=I_OK;last_fv=*fv;
    note(E_SAMPLE,n);
    return 1;
}
/* 3 frames at the start: baseline value and noise-derived threshold (V17A rule). */
static int baseline(uint32_t *f0)
{
    struct score f;uint32_t v[3],lo,hi,med,noise;int i,retry;
    if(use_cfd)
    {   /* r6: 3 new Canon values; their v1 is the scale reference for the whole run */
        uint32_t w[3];
        cfd_ref_v1=0;cfd_wait_new(1);
        for(i=0;i<3;i++){if(!cfd_next(&v[i]))return 0;w[i]=cfd_v[1];}
        cfd_ref_v1=median(w,3);if(!cfd_ref_v1)cfd_ref_v1=1;
        run_max=run_min=median(v,3);
        if(sample_frame(&f))current=f;
        goto stats;
    }
    msleep(60);
    for(i=0;i<3;i++)
    {
        if(gate()){image_reason=I_CANCEL;abort_now(S_GATE);return 0;}
        for(retry=0;retry<6;retry++)
        {
            if(sample_frame(&f))break;
            if(gate()){image_reason=I_CANCEL;abort_now(S_GATE);return 0;}
            msleep(35);
        }
        if(retry==6){abort_now(S_IMAGE);return 0;}
        current=f;v[i]=fv_from(&f);
        if(i!=2)msleep(34);
    }
stats:
    med=median(v,3);lo=hi=v[0];
    for(i=1;i<3;i++){if(v[i]<lo)lo=v[i];if(v[i]>hi)hi=v[i];}
    noise=divu(hi-lo,divu(med,10000u)+1u);          /* spread in basis points */
    if(noise>4000u)noise=4000u;
    tol_bp=(int)(noise*2u+80u);
    if(tol_bp<250)tol_bp=250;
    if(tol_bp>1200)tol_bp=1200;
    image_reason=I_OK;*f0=med;last_fv=med;
    note(E_SAMPLE,tol_bp);
    return 1;
}

/* ---------------- motion: +/-1 only for anything that is measured ---------------- */
/* r4: lens profile state (loaded at the start of every AF run) */
static const struct lprof *prof=0;static int prof_near=0;
static void prof_setup(void){prof=0;prof_near=0;if(lp_load())prof=lp_find((int)lens_info.focal_len,&prof_near);}
/* setting 6 = AUTO: CAMCAL's measured backlash rounded up PLUS ONE unit of margin (at least 2); 3 units without a profile
   (the r3 default). Replay of the real 50/85 mm curves: a pad exactly equal to the backlash (2) landed one unit
   short more often than 3 (sharp>=95%: 98.6% -> 91.7% at 50 mm). */
static int comp_units(void)
{
    static const int t[6]={0,1,2,3,4,6};
    if(comp_setting>=6){int b=lp_backlash_units(prof);return b<0?3:clampi(b+1,2,6);}
    return t[clampi(comp_setting,0,5)];
}
static int budget_ok(void)
{
    if(gate()){abort_now(S_GATE);return 0;}
    if(total_units>=UNITS_MAX){abort_now(S_BUDGET);return 0;}
    if((int)(get_ms_clock()-run_start)>TIME_MAX_MS){abort_now(S_BUDGET);return 0;}
    return 1;
}
static int at_stop;    /* direction of the last refused command, 0 = none */
/* one waited +/-1: 1 moved, 0 refused (end stop), -1 abort */
static int step1(int dir)
{
    int rc;
    if(!budget_ok())return -1;
    rc=focus_cmd(dir,1,(last_direction&&dir!=last_direction)?60:10);
    if(!rc&&use_cfd){msleep(150);rc=focus_cmd(dir,1,10);if(rc)note(E_RETRY,dir);}   /* r8: busy after a big move, not a stop */
    last_motor_rc=rc;
    if(!rc){at_stop=dir;return 0;}
    at_stop=0;last_direction=dir;offset_units+=dir;total_units++;move_count++;
    return 1;
}
/* k waited +/-1 in dir; returns units moved (stops at an end stop), -1 abort */
static int moves(int dir,int k)
{
    int i,r=1;
    for(i=0;i<k;i++){r=step1(dir);if(r<0)return -1;if(r==0)break;}
    if(i)note(E_MOVE,dir*i);
    if(r==0)note(E_STOP_HIT,dir);
    return i;
}
/* go to command position t, arriving travelling `arrive` (backlash pad = comp units) */
static int goto_pos(int t,int arrive)
{
    int pad=comp_units();
    if(offset_units==t&&(last_direction==arrive||!pad))return 1;
    if(pad&&!(last_direction==arrive&&(t-offset_units)*arrive>0))
    {
        int pre=t-arrive*pad;
        if(pre!=offset_units&&moves(pre>offset_units?1:-1,absi(pre-offset_units))<0)return -1;
    }
    if(t!=offset_units&&moves(t>offset_units?1:-1,absi(t-offset_units))<0)return -1;
    return 1;
}

/* ---------------- one scan: samples taken travelling one direction ---------------- */
static int sx[SCAN_MAX],sn,sdir;static uint32_t sf[SCAN_MAX],sr[SCAN_MAX],sw[SCAN_MAX];
static void scan_add(uint32_t f)
{
    if(sn<SCAN_MAX){sx[sn]=offset_units;sf[sn]=f;sr[sn]=use_cfd?f:blend_raw();sw[sn]=use_cfd?f:blend_wide();sn++;}   /* r6: no raw/wide split for Canon */
}
static int scan_best(void){int i,b=0;for(i=1;i<sn;i++)if(sf[i]>sf[b])b=i;return b;}
static int stride_at(int b)
{
    int s=0;
    if(b>0)s=absi(sx[b]-sx[b-1]);
    if(b<sn-1&&absi(sx[b+1]-sx[b])>s)s=absi(sx[b+1]-sx[b]);
    return s?s:1;
}

enum { C_ABORT=-1,C_PASSED=1,C_STOP=2,C_FLAT=3 };
/* Climb in dir with a stride of s +/-1 units. Flat -> stride doubles (until the first rise).
 * Ends when the picture has clearly dropped below the best sample (peak passed),
 * at an end stop, or after `reach` units without any rise. */
static int no_double=0;   /* re-scans keep their stride: a flat hill top must not make them overshoot */
static uint32_t aim_fv=0; /* sharpness already seen near the peak (from the +/-3 phase); 0 = unknown */
/* r3: at 70mm and longer the focus peak is only ~2 units wide (FZ7C3500 at 85mm): a stride of 8
   could step right over it, so strides are capped at 4 there */
/* r4: "narrow peak" decides the stride cap and the small first probe. With a CAMCAL profile for this lens
   at (about) this focal length it comes from the MEASURED peak width (FWHM <= 8 units); without one, the r3
   rule from the 70D + 18-135 logs is kept (70 mm and longer = narrow). */
static int narrow_peak(void)
{
    /* r6: Canon's peak is about half as wide as the YUV one (CFD39301) and the profile widths are YUV widths */
    int lim=use_cfd?160:80,fl=70;
    if(prof&&prof_near&&prof->fwhm10>0)return prof->fwhm10<=lim;
    if(!use_cfd&&prof&&prof_near&&prof->fwhm10==0&&prof->w70_10>0)return 0;   /* wider than CAMCAL could sweep (YUV only, r7) */
    return (int)lens_info.focal_len>=fl;
}
static int smax(void){return narrow_peak()?(use_cfd?2:4):SMAX_FINE;}   /* r8: 2 with Canon's narrower peak */
static int climb(int dir,int s,int reach)
{
    uint32_t f,best;int moved=0,rises=0,drops=0,r,b;
    sn=0;sdir=dir;stride_now=s;
    if(last_direction!=dir&&comp_units())      /* take up the slack before the first sample */
    {
        r=moves(dir,comp_units());if(r<0)return C_ABORT;
        if(r==0)return C_STOP;
    }
    if(!take(&f,0))return C_ABORT;
    scan_add(f);best=f;
    for(;;)
    {
        if(moved>=reach&&!rises)return C_FLAT;
        r=moves(dir,s);if(r<0)return C_ABORT;
        if(r==0)return C_STOP;
        moved+=r;
        if(!take(&f,0))return C_ABORT;
        scan_add(f);
        if(sn>=SCAN_MAX)return C_STOP;
        b=scan_best();
        if(above_bp(f,best,tol_bp))
        {
            uint32_t prev=sf[sn-2];
            best=f;rises++;drops=0;best_offset=offset_units;note(E_NEW_BEST,s);
            if(aim_fv&&f<aim_fv&&f>prev)
            {   /* after the +/-3 phase we know roughly how sharp the top is: estimate the units still to go
                   from the last rise, and take half of that as the next stride */
                int togo=(int)divu((aim_fv-f)*(uint32_t)s,f-prev),ns=togo/2;
                ns=clampi(ns,2,smax());
                if(ns!=s){s=ns;stride_now=s;note(E_STRIDE,s);}
            }
            else if(aim_fv&&f>=aim_fv&&s>2){s=2;stride_now=s;note(E_STRIDE,s);}
        }
        else if(!above_bp(f,sf[b],-tol_bp))
        {
            drops++;
            /* one clear drop is enough with a big stride or a big fall; else two in a row */
            /* r3: no rise yet and the stride has already grown on flat blur: a single dip is usually
               noise (FZ7C3500) - then two drops in a row are needed */
            if(drops>=2||((rises||s<4)&&(s>=3||!above_bp(f,sf[b],-2*tol_bp)))){note(E_DROP,drops);return C_PASSED;}
        }
        else
        {
            drops=0;
            if(f>best)best=f;
            if(!rises&&!no_double&&s<smax()){s*=2;if(s>smax())s=smax();stride_now=s;note(E_STRIDE,s);}
        }
    }
}

/* +/-3 search for a far-off hill. The +/-1 count means nothing afterwards (home lost). */
static int coarse(int dir)
{
    uint32_t f,best;int rises=0,turned=0,rc,i;
    home_known=0;note(E_HOME_LOST,dir);
    if(!take(&f,0))return C_ABORT;
    best=f;
    for(i=0;i<JUMPS_MAX&&jumps<JUMPS_MAX;i++)
    {
        if(!budget_ok())return C_ABORT;
        rc=focus_cmd(dir,3,(last_direction&&dir!=last_direction)?120:10);
        last_motor_rc=rc;
        if(!rc)
        {
            note(E_STOP_HIT,dir*3);
            if(rises)return C_PASSED;              /* the hill is behind us, next to the stop */
            if(turned)return C_FLAT;
            dir=-dir;turned=1;continue;
        }
        last_direction=dir;jumps++;net3+=dir;note(E_JUMP,dir*3);
        if(!take(&f,0))return C_ABORT;
        if(above_bp(f,best,tol_bp)){best=f;rises++;note(E_NEW_BEST,3);}
        else if(rises&&!above_bp(f,best,-tol_bp)){note(E_DROP,3);return C_PASSED;}
        else if(f>best)best=f;
    }
    return C_FLAT;
}

/* 3-point parabola through scan samples b-1,b,b+1 (positions may be unevenly spaced): vertex x10 */
static int vertex10(int b)
{
    int x0=sx[b-1],x1=sx[b],x2=sx[b+1];
    int y0=(int)(sf[b-1]>>6),y1=(int)(sf[b]>>6),y2=(int)(sf[b+1]>>6);
    int a1=x1-x0,a2=x1-x2;
    int num=a1*a1*(y1-y2)-a2*a2*(y1-y0);
    int den=a1*(y1-y2)-a2*(y1-y0);
    int v10,lo,hi;
    if(den==0)return x1*10;
    v10=x1*10-divs(5*num,den);
    lo=(x0<x2?x0:x2)*10;hi=(x0<x2?x2:x0)*10;
    return clampi(v10,lo,hi);
}

/* Is the hill at least ~6 strides wide at half height? For y = c - k(x-x0)^2 sampled at spacing h,
   FWHM ~ 2h*sqrt((c-floor)/(-D)) with D the second difference, so FWHM >= 4.9h <=> c-floor >= 6(-D).
   Then a parabola through the three samples is already accurate; no unit-by-unit re-scan needed. */
static int wide_vs_stride(int b)
{
    int i,h1=sx[b]-sx[b-1],h2=sx[b+1]-sx[b];uint32_t mn=sf[0];int y0,y1,y2,D;
    if(h1!=h2)return 0;
    for(i=1;i<sn;i++)if(sf[i]<mn)mn=sf[i];
    y0=(int)(sf[b-1]>>6);y1=(int)(sf[b]>>6);y2=(int)(sf[b+1]>>6);
    D=y0-2*y1+y2;
    if(D>=0)return 0;
    return (y1-(int)(mn>>6))>=6*(-D);         /* FWHM >= ~5 strides */
}
/* land at t arriving travelling `arr`; measure with one extra frame */
static int land_measure(int t,int arr,uint32_t *f)
{
    phase=phase==P_POLISH?P_POLISH:P_LAND;
    if(goto_pos(t,arr)<0)return -1;
    if(!take(f,1))return -1;
    note(E_LAND,t);
    return 1;
}


/* ---------------- V17C fast part: +/-3 jumps, positions never reused ---------------- */
static int jump3(int dir)       /* 1 moved, 0 refused (end stop), -1 abort */
{
    int rc;
    if(jumps>=JUMPS_MAX)return 0;             /* out of big steps: behaves like a stop */
    if(!budget_ok())return -1;
    rc=focus_cmd(dir,3,(last_direction&&dir!=last_direction)?60:10);
    if(!rc&&use_cfd&&last_fv)
    {   /* r8: refused right after a move? Look first: a picture change means it moved anyway (C93), else retry once */
        uint32_t before=last_fv,f;
        msleep(150);
        if(!take(&f,0))return -1;
        if(!above_bp(f,before,-3*tol_bp)||above_bp(f,before,3*tol_bp)){rc=1;note(E_RETRY,dir*30);}
        else {rc=focus_cmd(dir,3,10);if(rc)note(E_RETRY,dir*3);}
    }
    last_motor_rc=rc;
    if(!rc){note(E_STOP_HIT,dir*3);return 0;}
    if(home_known){home_known=0;note(E_HOME_LOST,0);}
    last_direction=dir;jumps++;net3+=dir;note(E_JUMP,dir*3);
    return 1;
}
/* 1: the peak was passed - climb back in *d with +/-1
   2: both +/-3 probes under 35% of the start (narrow hill) - jumped back to about the start; look there
   3: both +/-3 probes worse than the start (broad hill) - climb in *d=+1 from -J
   0: no hill seen with big steps (continue with the +/-1 search)       -1: abort
   hint: direction already known from the small probe (0 = unknown); fhint = the sharper small-probe value */
static int approach_big(int hint,uint32_t fhint,int *d)
{
    uint32_t fp=0,fm=0,f,best;int rp=0,rm=0,dir,rises=0,flats=0,turned=0,i,r,per=1,cdrops=0,since_best=0;
    int up_p=0,up_m=0,dn_p,dn_m;
    if(hint)
    {   /* the small probe already showed which way is uphill: no two-sided +/-3 probe needed */
        dir=hint;
        if(dir>0)up_p=1;else up_m=1;
        best=fhint>f_start?fhint:f_start;aim_fv=0;
    }
    else
    {
        rp=jump3(1);if(rp<0)return -1;
        if(rp){if(!take(&fp,0))return -1;note(E_PROBE,3);}
        rm=jump3(-1);if(rm<0)return -1;
        if(rp&&rm&&above_bp(fp,f_start,-tol_bp)&&!above_bp(fp,f_start,tol_bp))
        {   /* r3: the + probe looks just like the start - it may not have moved at all (the lens
               "accepts" a +/-3 at a stop without moving: FZ7C34FD at the close stop). Then this first
               -3 already took us one big step out: look here before jumping again. */
            uint32_t f1;
            if(!take(&f1,0))return -1;
            note(E_PROBE,-3);
            if(!above_bp(f1,f_start,-tol_bp)||above_bp(f1,f_start,tol_bp)){fm=f1;goto probed;}   /* fp stays: it reads like the start */
        }
        if(rp&&rm){rm=jump3(-1);if(rm<0)return -1;}      /* from +J back past the start to -J */
        if(rm){if(!take(&fm,0))return -1;note(E_PROBE,-3);}
probed:
        up_p=rp&&above_bp(fp,f_start,tol_bp);up_m=rm&&above_bp(fm,f_start,tol_bp);
        dn_p=rp&&!above_bp(fp,f_start,-tol_bp);dn_m=rm&&!above_bp(fm,f_start,-tol_bp);
        if(!rp&&!rm)return 0;
        if(dn_p&&dn_m)
        {   /* start is the best: the peak is between -J and +J */
            if(fp<divu(f_start,100u)*35u&&fm<divu(f_start,100u)*35u)
            {   /* both under 35% of the start: the hill is narrow compared with a +/-3 - jump back to about
                   the start and look there, instead of crawling all the way back from -J */
                r=jump3(1);if(r<0)return -1;
                *d=1;aim_fv=0;return 2;
            }
            *d=1;aim_fv=f_start;return 3;                 /* broad hill: climb through it from -J */
        }
        if(up_p&&(!up_m||fp>=fm))dir=1;
        else if(up_m)dir=-1;
        else if(!rp)dir=-1;                               /* + is an end stop */
        else if(!rm)dir=1;
        else if(dn_p)dir=-1;
        else if(dn_m)dir=1;
        else dir=fp>=fm?1:-1;                             /* flat: far out of focus, guess */
        best=f_start;aim_fv=0;
        if(dir>0&&rm)                                     /* we are at -J: go back to +J without re-measuring */
        {
            for(i=0;i<2;i++){r=jump3(1);if(r<0)return -1;if(r==0)break;}
            best=fp>f_start?fp:f_start;
        }
        else if(dir<0&&rm)best=fm>f_start?fm:f_start;
    }
    note(E_DIRECTION,dir);
    for(i=0;;)
    {
        int k,moved=0,hit=0;
        if(jumps+per>JUMPS_MAX)                           /* out of big steps: carry on with +/-1 */
        {
            if(rises){*d=dir;aim_fv=0;return 1;}
            return 0;
        }
        for(k=0;k<per;k++){r=jump3(dir);if(r<0)return -1;if(r==0){hit=1;break;}moved++;i++;}
        if(hit)
        {   /* ANY refusal = end stop (the lens sometimes "accepts" a +/-3 at the stop and refuses the next) */
            if(moved)
            {
                if(!take(&f,0))return -1;
                if(above_bp(f,best,tol_bp)){best=f;rises++;aim_fv=best;note(E_NEW_BEST,3);}
            }
            if(rises){*d=-dir;return 1;}                  /* the hill is between here and the stop */
            if(turned)return 0;
            dir=-dir;turned=1;per=1;note(E_DIRECTION,dir);continue;
        }
        if(!take(&f,0))return -1;
        since_best+=moved;
        if(above_bp(f,best,tol_bp)){best=f;rises++;flats=0;cdrops=0;aim_fv=best;since_best=0;note(E_NEW_BEST,3);}
        else if(!above_bp(f,best,-tol_bp))
        {
            cdrops++;
            if(rises||(dir>0?up_p:up_m))
            {   /* passed the top - but on a long gentle hill one noisy dip is not proof (r3):
                   a big drop counts at once, a small one needs a second in a row */
                if(cdrops>=2||!above_bp(f,best,-3*tol_bp))
                {
                    note(E_DROP,3);*d=-dir;if(!aim_fv)aim_fv=best;
                    if(use_cfd&&rises&&since_best>0&&since_best<=4)
                    {   /* r8: jump back to where the best value was seen and scan finely there (caller: ar 4) */
                        int k,back=0;
                        for(k=0;k<since_best;k++){r=jump3(-dir);if(r<0)return -1;if(r==0)break;back++;}
                        if(back)return 4;
                    }
                    return 1;
                }
                continue;
            }
            if(turned)return 0;
            dir=-dir;turned=1;best=f;cdrops=0;note(E_DIRECTION,dir);   /* wrong way: turn round once */
        }
        else
        {
            flats++;cdrops=0;if(f>best)best=f;
            if(!rises&&per<4)per*=2;                      /* nothing yet: cover ground faster */
            if(flats>=6&&!rises)return 0;
        }
    }
    return 0;
}
static int search_v17c(void)
{
    int dir=1,s=2,res,pass,b,T,r,i;
    uint32_t f,fp,fm,fref;
    prof_setup();
    note(E_START,0);
    {
        int g=gate();
        if(g)
        {
            abort_now(S_GATE);
            if(g&8)NotifyBox(3000,"V17C: turn OFF Canon " CAM_SERVO);
            else if(g&4)NotifyBox(3000,"V17C: set the lens switch to AF");
            else if(g&3)NotifyBox(3000,"V17C: needs Movie mode LiveView");
            else if(g&16)NotifyBox(3000,"V17C: no lens detected");
            else if(g&32)NotifyBox(3000,"V17C: lens busy, try again");
            return 0;
        }
    }

    /* r6: sharpness source for this run */
    if(source_setting&&!cfd_forbid&&cfd_seq)
    {   /* Canon data has been seen: give it up to 150 ms to show a fresh value (e.g. right after moving home) */
        uint32_t s0=cfd_seq,t0=get_ms_clock();
        while(cfd_seq==s0&&(int)(get_ms_clock()-t0)<150)msleep(5);
    }
    use_cfd=source_setting&&!cfd_forbid&&cfd_fresh();
    cfd_ref_v1=0;cfd_used=cfd_seq;run_max=run_min=0;
    if(!restarts)first_source=use_cfd;
    note(E_SOURCE,use_cfd);

    /* 1. baseline */
    phase=P_BASE;
    if(!baseline(&f_start))goto fail;
    best_offset=0;

    /* 2a. V17C r2: first a small, exact look around the start (+/-4 units).
          Start already the sharpest -> fine-tune right here, never leaving the exact frame.
          A clear slope -> big steps straight that way. Flat -> big steps look further. */
    if(big_setting)
    {
        int ad=1,ar,hint=0,sp=4;uint32_t fh=0;
        /* small look only where it pays: long focal lengths (narrow hill, small +/-3).
           At the wide end a +/-3 is ~25 units and the hill is broad - big steps first is faster. */
        int small_probe=narrow_peak()||use_cfd;   /* r7: always with Canon data - never jump away from a sharp start */
        if(use_cfd)sp=3;
        phase=P_PROBE;
        for(;small_probe;)
        {
            int up_p,up_m,dn_p,dn_m,wall_p,wall_m;
            if(moves(1,sp-offset_units)<0)goto fail;
            wall_p=(at_stop==1);
            if(!take(&fp,0))goto fail;
            note(E_PROBE,sp);
            if(moves(-1,offset_units+sp)<0)goto fail;
            wall_m=(at_stop==-1);
            if(!take(&fm,0))goto fail;
            note(E_PROBE,-sp);
            up_p=!wall_p&&above_bp(fp,f_start,tol_bp);up_m=!wall_m&&above_bp(fm,f_start,tol_bp);
            dn_p=!above_bp(fp,f_start,-tol_bp);dn_m=!above_bp(fm,f_start,-tol_bp);
            if(up_p||up_m){hint=(up_p&&(!up_m||fp>=fm))?1:-1;fh=hint>0?fp:fm;break;}
            if(dn_p&&dn_m)
            {
                phase=P_FINE;aim_fv=0;
                if(goto_pos(-sp-1,1)<0)goto fail;
                res=climb(1,2,2*sp+8);
                goto have_climb;
            }
            if(wall_p&&!wall_m){hint=-1;fh=fm;break;}
            if(wall_m&&!wall_p){hint=1;fh=fp;break;}
            /* r7: Canon, flat at +/-3 (broad hill at the wide end, or far out of focus): look once more at +/-6
               before any big step, so an in-focus start on a broad hill is not thrown away either */
            if(use_cfd&&sp==3){if(moves(1,-offset_units)<0)goto fail;sp=6;continue;}
            break;                                       /* flat: let the big steps look further */
        }
        /* the big steps must start from the sharper side of the small probe (we are at -sp now) */
        if(hint>0&&moves(1,sp-offset_units)<0)goto fail;
        /* 2b. big steps: get near the peak fast; their size is never trusted */
        phase=P_COARSE;note(E_COARSE,hint);
        off_c0=offset_units;
        ar=approach_big(hint,fh,&ad);
        if(ar<0)goto fail;
        off_c1=offset_units;
        if(ar==2)
        {   /* back at about the start (narrow hill): scan through it from 4 units below */
            phase=P_FINE;
            if(goto_pos(offset_units-4,1)<0)goto fail;
            res=climb(1,2,FINE_REACH);
            if(res==C_STOP&&sn<2)res=climb(-1,2,FINE_REACH);
            goto have_climb;
        }
        if(ar==4)
        {   /* r8: back near the best big-step sample: scan across it with fine strides from 10 units below */
            phase=P_FINE;aim_fv=0;
            if(goto_pos(offset_units-10,1)<0)goto fail;
            res=climb(1,narrow_peak()?1:2,30);
            if(res==C_STOP&&sn<2)res=climb(-1,2,30);
            goto have_climb;
        }
        if(ar==1||ar==3)
        {
            phase=ar==3?P_FINE:P_CLIMB;
            res=climb(ad,2,FINE_REACH+30);
            if(res==C_STOP&&sn<2){ad=-ad;res=climb(ad,2,FINE_REACH+30);}
            aim_fv=0;
            goto have_climb;
        }
        /* nothing seen with big steps: fall through to the +/-1 search from here */
    }

    /* 2. direction probe at +/-2, widening to +/-4 and +/-8 while flat */
    phase=P_PROBE;
    for(;;)
    {
        int up_p,up_m,dn_p,dn_m;
        int wall_p,wall_m;
        if(moves(1,s-offset_units)<0)goto fail;
        wall_p=(at_stop==1);
        if(!take(&fp,0))goto fail;
        note(E_PROBE,s);
        if(moves(-1,offset_units+s)<0)goto fail;
        wall_m=(at_stop==-1);
        if(!take(&fm,0))goto fail;
        note(E_PROBE,-s);
        if(wall_p&&wall_m){abort_now(S_LIMIT);goto fail;}
        if(wall_m){dir=1;res=0;break;}          /* against a stop: the hill can only be the other way */
        if(wall_p){dir=-1;res=0;break;}
        up_p=above_bp(fp,f_start,tol_bp);up_m=above_bp(fm,f_start,tol_bp);
        dn_p=!above_bp(fp,f_start,-tol_bp);dn_m=!above_bp(fm,f_start,-tol_bp);
        if(up_p||up_m){dir=(up_p&&(!up_m||fp>=fm))?1:-1;res=0;break;}
        if(dn_p&&dn_m){res=2;break;}                 /* start is the best: peak inside (-s,s) */
        if(dn_p){dir=-1;res=0;break;}
        if(dn_m){dir=1;res=0;break;}
        if(s>=8){dir=fp>=fm?1:-1;res=1;break;}       /* flat everywhere within +/-8 */
        s*=2;
    }
    note(E_DIRECTION,dir);

    /* 3. climb (or a fine scan across the start) */
    if(res==2){phase=P_FINE;res=climb(1,1,2*s+6);}
    else
    {
        phase=P_CLIMB;
        res=climb(dir,s,FINE_REACH);
        if(res==C_STOP&&sn<2){dir=-dir;note(E_DIRECTION,dir);res=climb(dir,s,FINE_REACH);}   /* walked into a stop */
        if(res==C_FLAT)
        {
            if(big_setting&&!jumps)
            {
                phase=P_COARSE;note(E_COARSE,dir);
                off_c0=offset_units;
                res=coarse(dir);
                off_c1=offset_units;
                if(res==C_PASSED){phase=P_CLIMB;res=climb(-last_direction,2,FINE_REACH+24);}
            }
            else {phase=P_CLIMB;res=climb(-dir,4,2*FINE_REACH+8);}
        }
    }
have_climb:
    if(res==C_ABORT)goto fail;
    if(res==C_FLAT||sn<2){abort_now(S_NO_HILL);note(E_NO_HILL,0);goto fail;}

    /* 4. refine: re-scan back across the peak with half the stride until it is <= 2 (or the hill is wide) */
    phase=P_REFINE;
    for(pass=0;;pass++)
    {
        int sb;
        b=scan_best();sb=stride_at(b);
        note(E_BRACKET,sb);
        if(res==C_STOP&&b==sn-1){target10=sx[b]*10;arrive_dir=sdir;break;}   /* peak at the end stop */
        if(b>0&&b<sn-1&&(sb<=2||wide_vs_stride(b))){target10=vertex10(b);arrive_dir=sdir;break;}
        if(pass>=4){target10=sx[b]*10;arrive_dir=sdir;break;}
        {
            int fs=sb/2,rd=-sdir,st;if(fs<1)fs=1;
            /* start just before the peak (seen from the new direction), already travelling that way,
               so the backlash take-up cannot carry the first sample past it */
            st=sx[b]-rd*(sb+fs);
            if(goto_pos(st,rd)<0)goto fail;
            r=4*sb+2*fs+12;
            no_double=1;res=climb(rd,fs,r);no_double=0;
            if(res==C_ABORT)goto fail;
            if(res==C_FLAT&&sn>=3)
            {   /* noisy, broad top: no drop beyond the noise threshold, but lower samples on both sides */
                int b2=scan_best();
                if(b2>0&&b2<sn-1)res=C_PASSED;
            }
            if(res==C_FLAT||sn<2){abort_now(S_NO_BRACKET);goto fail;}
        }
    }
    b=scan_best();fref=sf[b];
    {   /* RAW and WIDE should peak in the same place on a real focus hill (V4.8 idea; log only) */
        int i2,br=0,bw=0;
        for(i2=1;i2<sn;i2++){if(sr[i2]>sr[br])br=i2;if(sw[i2]>sw[bw])bw=i2;}
        if(absi(sx[br]-sx[bw])>2*stride_at(b)){rw_disagree=1;note(E_RW_DISAGREE,sx[br]-sx[bw]);}
    }
    T=divs(target10,10);
    note(E_REFINE,target10);

    /* 5. land (arriving the way the samples were taken), verify against the best sample, polish */
    phase=P_LAND;
    if(land_measure(T,arrive_dir,&f)<0)goto fail;
    final_fv=f;
    /* r6: with Canon data always check one unit either side: its peak is about twice as narrow, so a parabola
       through samples 2 units apart can round to the wrong unit (replay 50 mm: landed 1 unit off = 92 pct) */
    if(!above_bp(f,fref,-tol_bp)||speed_setting>=2||use_cfd)
    {
        int cand[3],bt=T,nc=0;uint32_t bf=f,g;
        phase=P_POLISH;polished=1;note(E_POLISH,T);
        cand[nc++]=T-1;cand[nc++]=T+1;
        if(sx[b]!=T&&sx[b]!=T-1&&sx[b]!=T+1)cand[nc++]=sx[b];
        for(i=0;i<nc;i++)
        {
            if(land_measure(cand[i],arrive_dir,&g)<0)goto fail;
            if(g>bf){bf=g;bt=cand[i];}
        }
        if(bt!=offset_units||last_direction!=arrive_dir)
        {
            if(land_measure(bt,arrive_dir,&g)<0)goto fail;
            bf=g;
        }
        T=bt;final_fv=bf;
    }
    best_offset=T;
    /* never leave the user worse off than they started, if the start is still reachable exactly */
    if(home_known&&!above_bp(final_fv,f_start,-2*tol_bp))
    {
        note(E_WORSE,0);
        phase=P_RESTORE;
        if(goto_pos(0,last_direction?last_direction:1)>=0)restored=1;
        stop_code=S_WORSE;return 0;
    }
    /* r6: Canon values are flat far out of focus (only noise): a "peak" found there is a noise bump. Canon's
       real hills are 11-14x high (CFD39301). No real hill seen (best < 1.3x lowest) and not clearly sharper
       than the start = no hill: go home instead of claiming focus. */
    if(use_cfd&&run_min&&run_max<run_min+divu(run_min,10u)*3u&&!above_bp(final_fv,f_start,3*tol_bp))
    {
        note(E_NO_HILL,0);
        phase=P_RESTORE;
        if(home_known&&goto_pos(0,last_direction?last_direction:1)>=0)restored=1;
        stop_code=S_NO_HILL;return 0;
    }
    /* r6: the landing is far below the best Canon value this run has already seen: we are on the flat floor
       next to the hill, not on its top (replay 19 mm: a +/-3 of ~25 units jumped past the hill, the +/-1 climb
       then "found" a noise bump). Treat as a failed search: undo the moves back to the start. */
    if(use_cfd&&run_max&&divu(final_fv,10u)*10u<divu(run_max,10u)*7u)
    {
        note(E_NO_HILL,1);abort_now(S_NO_HILL);goto fail;
    }
    confidence=rw_disagree?2:1;stop_code=S_OK;
    note(E_ACCEPT,T);
    return 1;

fail:
    /* go back to where the user left focus: exactly if no +/-3 was used, else undo the +/-3s */
    phase=P_RESTORE;
    if(stop_code==S_GATE||stop_code==S_CANCEL)return 0;
    if(home_known){if(offset_units&&goto_pos(0,last_direction?last_direction:1)>=0)restored=1;}
    else
    {
        /* undo the +/-1 moves made after the +/-3 search, then the +/-3s, then the +/-1s before it */
        int k=absi(net3),d=net3>0?-1:1;
        if(goto_pos(off_c1,last_direction?last_direction:1)<0)return 0;
        for(i=0;i<k;i++){if(gate())break;if(!focus_cmd(d,3,i?10:60))break;last_direction=d;net3+=d;note(E_RESTORE,d*3);}
        offset_units=off_c0;
        if(net3==0&&goto_pos(0,last_direction?last_direction:1)>=0)restored=2;
    }
    return 0;
}

/* All CSV writing happens AFTER motion ends; no per-frame SD writes. */
static int output_handle=0;static char output_buf[512];static int output_len=0;
static void flush(void)
{
    if(output_len&&output_handle>0)FIO_WriteFile(output_handle,output_buf,(unsigned)output_len);
    output_len=0;
}
static void ch(char c)
{
    if(output_len>450)flush();output_buf[output_len++]=c;
}
static void txt(const char *s){while(*s)ch(*s++);}
static void num(uint32_t n)
{
    char b[12];int i=0;if(!n){ch('0');return;}
    while(n&&i<11){b[i++]=(char)('0'+n%10u);n=divu(n,10);}
    while(i)ch(b[--i]);
}
static void snum(int n){if(n<0){ch('-');num((uint32_t)(-(int64_t)n));}else num((uint32_t)n);}
static void comma(void){ch(',');}
static void iout(int n){snum(n);comma();}
static void uout(uint32_t n){num(n);comma();}
static void save_trace(void)
{
    char path[20]="ML/FZ7C0000.CSV";
    uint32_t v;int i;
    static const char hx[]="0123456789ABCDEF";
    if(!log_serial)log_serial=(run_start&0xFFFFu);
    else log_serial++;
    v=log_serial;
    for(i=0;i<4;i++){path[10-i]=hx[v&15u];v>>=4;}
    output_handle=FIO_CreateFile(path);
    if(output_handle<=0){output_handle=FIO_CreateFile("FZ7CLOG.CSV");}
    if(output_handle<=0)return;
    txt("# Canon" CAM_MODEL " V17C r8 hybrid contrast AF: +/-3 jumps to get close, exact +/-1 finish; focus motor, not zoom.\n");
    txt("# lens_id,");num(lens_info.lens_id);txt(",focal_mm,");num(lens_info.focal_len);txt(",focus_region,");num((uint32_t)focus_region);
    txt(",speed_setting,");num((uint32_t)speed_setting);txt(",comp_units,");num((uint32_t)comp_units());txt(",big_steps,");num((uint32_t)big_setting);
    txt(",profile,");num((uint32_t)(prof?(prof_near?2:1):0));
    if(prof){txt(",prof_focal,");snum(prof->focal);txt(",prof_backlash_x10,");snum(prof->back10);txt(",prof_fwhm_x10,");snum(prof->fwhm10);txt(",prof_w70_x10,");snum(prof->w70_10);}
    txt(",narrow,");num((uint32_t)narrow_peak());
    txt(",trigger,");txt(hs_run?"halfshutter":"menu");txt(",released_early,");num((uint32_t)hs_released);
    txt(",source_setting,");num((uint32_t)source_setting);txt(",source_first,");txt(first_source?"canon":"yuv");txt(",source_last,");txt(use_cfd?"canon":"yuv");
    txt(",restarts,");num((uint32_t)restarts);txt(",canon_events,");num(cfd_seq-cfd_seq0);txt(",canon_ref_v1,");num(cfd_ref_v1);ch('\n');
    txt("# off = +/-1 command count (exact while home_known=1); fv = Canon (v2+v3)<<5 when src=1 (PROP_LV_FOCUS_DATA), else YUV preview. NOT RAW recording.\n");
    txt("# stop 0 accepted,1 gate,2 motor,3 image,4 budget,5 no bracket,11 cancel,12 no hill,13 worse than start (went home),14 Canon scale changed (restarted),15 Canon data stopped (restarted with YUV).\n");
    txt("# event 1 begin,2 sample(span=frames; first=tol_bp),3 move(span=+/-units),4 +/-3 jump,5 probe,7 direction,8 new best,9 drop(peak passed),10 bracket(span=stride at best),11 target(span=pos x10),12 verify,13 accept,14 abort,30 end stop,34 undo +/-3,35 stride,36 big-step search,37 home lost,38 polish,39 landed,40 raw/wide disagree,41 worse than start,42 source (span 1 canon 0 yuv),43 restart (span=reason),17 retry (r8: span dir = +/-1 retried, dir*3 = +/-3 retried, dir*30 = refused +/-3 had moved).\n");
    txt("# phase 1 baseline,2 probe,3 climb,4 fine,5 big steps,6 refine,7 land,8 polish,9 restore.\n");
    txt("elapsed_ms,event,off,best_off,span,dir,units,moves,stop,reason,gate,motor_rc,raw,wide,luma,raw_t,raw_m,raw_w,wide_t,wide_m,wide_w,raw_noise,wide_noise,clip,dark,pixels,lens_focus_pos,lens_focus_dist,buf_addr,buf_w,buf_h,buf_pitch,phase,stride,home_known,jumps,fv,src,canon_ab,canon_v1,canon_events\n");
    for(i=0;i<trace_count;i++)
    {
        struct point *p=&trace[i];
        num(p->ms);comma();iout(p->event);iout(p->off);iout(p->best);
        iout(p->span);iout(p->dir);iout(p->units);iout(p->moves);
        iout(p->stop);iout(p->reason);iout(p->gate);iout(p->rc);
        uout(p->v.raw);uout(p->v.wide);uout(p->v.luma);
        uout(p->v.raw_t);uout(p->v.raw_m);uout(p->v.raw_w);
        uout(p->v.wide_t);uout(p->v.wide_m);uout(p->v.wide_w);
        uout(p->v.raw_noise);uout(p->v.wide_noise);
        uout(p->v.clipped);uout(p->v.dark);uout(p->v.samples);
        iout(p->lens_focus_pos);iout(p->lens_focus_dist);uout(p->buf_addr);
        iout(p->buf_w);iout(p->buf_h);iout(p->buf_pitch);
        iout(p->phase);iout(p->stride);iout(p->home);iout(p->jumps);uout(p->fv);iout(p->src);uout(p->cab);uout(p->cv1);num(p->cseq);ch('\n');
    }
    txt("# SUMMARY,stop,");num((uint32_t)stop_code);
    txt(",accepted,");num((uint32_t)confidence);
    txt(",target_x10,");snum(target10);
    txt(",final_off,");snum(best_offset);
    txt(",arrive_dir,");snum(arrive_dir);
    txt(",polished,");num((uint32_t)polished);
    txt(",home_known,");num((uint32_t)home_known);
    txt(",jumps,");num((uint32_t)jumps);
    txt(",restored,");num((uint32_t)restored);
    txt(",total_units,");num((uint32_t)total_units);
    txt(",moves,");num((uint32_t)move_count);
    txt(",tol_bp,");num((uint32_t)tol_bp);
    txt(",start_fv,");num(f_start);
    txt(",final_fv,");num(final_fv);
    txt(",rw_disagree,");num((uint32_t)rw_disagree);
    txt(",elapsed_ms,");num(get_ms_clock()-run_start);
    txt(",trace_dropped,");num((uint32_t)trace_dropped);ch('\n');
    flush();FIO_CloseFile(output_handle);output_handle=0;
}
/* r6: state for a second attempt in the same run (trace, budgets and last_direction are kept) */
static void restart_search_state(void)
{
    confidence=stop_code=0;offset_units=0;last_motor_rc=0;
    best_offset=0;phase=0;stride_now=0;home_known=1;net3=0;jumps=0;restored=0;
    target10=0;arrive_dir=0;polished=0;rw_disagree=0;off_c0=off_c1=0;f_start=final_fv=0;last_fv=0;at_stop=0;sn=0;no_double=0;aim_fv=0;
}
static void reset_trace(void)
{
    use_cfd=0;cfd_forbid=0;restarts=0;first_source=0;cfd_ref_v1=0;cfd_seq0=cfd_seq;
    clear_score(&current);trace_count=trace_dropped=confidence=stop_code=0;
    total_units=move_count=offset_units=last_direction=last_motor_rc=0;
    best_offset=0;phase=0;stride_now=0;home_known=1;net3=0;jumps=0;restored=0;
    target10=0;arrive_dir=0;polished=0;rw_disagree=0;off_c0=off_c1=0;f_start=final_fv=0;last_fv=0;at_stop=0;sn=0;no_double=0;aim_fv=0;
    last_buf_addr=0;last_buf_w=last_buf_h=last_buf_pitch=0;
    run_start=get_ms_clock();
}
static int af_btn_moved=0;
static void worker(void *unused)
{
    int hs_prev=1;          /* a half-press already held when the module starts does not count */
    (void)unused;
    while(!worker_exit)
    {
        int mode=0,hs=get_halfshutter_pressed();
        /* r5: in half-shutter mode Canon's own AF must not react to the half-press (it would fight us): ML moves
           it to the * button, as its trap focus / dot_tune do, and puts it back when the mode is switched off
           or the module is unloaded (ML also restores it at the next start-up if the camera dies meanwhile). */
        if(trigger_setting&&!af_btn_moved&&lv&&!hs){assign_af_button_to_star_button();af_btn_moved=1;}
        if(!trigger_setting&&af_btn_moved){restore_af_button_assignment();af_btn_moved=0;}
        if(trigger_setting&&hs&&!hs_prev){mode=1;hs_run=1;hs_released=0;msleep(150);}   /* let CAMF stop first */
        hs_prev=hs;
        if(!mode&&af_request){af_request=0;mode=1;hs_run=0;}
        else if(measure_request){measure_request=0;mode=2;}
        if(mode)
        {
            worker_busy=1;cancel_request=0;reset_trace();
            if(mode==1)
            {
                search_v17c();
                /* r6: Canon changed its scale (stop 14) or stopped sending (stop 15): the run went home; start again
                   once - same source with a fresh baseline after a scale change, the YUV metric if the data stopped */
                if((stop_code==S_SCALE||stop_code==S_LOST)&&!restarts&&!hs_released&&!cancel_request&&!worker_exit)
                {
                    if(stop_code==S_LOST)cfd_forbid=1;
                    restarts=1;note(E_RESTART,stop_code);
                    restart_search_state();
                    search_v17c();
                }
            }
            else
            {
                note(E_START,0);
                if(!gate()&&measure_optical(1))
                {confidence=1;note(E_MEASURE,0);}
                else if(!stop_code)abort_now(S_IMAGE);
            }
            save_trace();worker_busy=0;hs_run=0;
        }
        msleep(20);
    }
}
static struct menu_entry menu[] = {
    {.name="V17C Run Fast AF",.priv=&af_request,.max=1,
     .choices=CHOICES("OFF","RUN AF"),
     .help="Hybrid contrast AF: fast +/-3 approach, exact +/-1 finish, verify.",
     .help2="Returns to start on failure. Log ML/FZ7Cxxxx.CSV."},
    {.name="V17C Measure Focus",.priv=&measure_request,.max=1,
     .choices=CHOICES("OFF","MEASURE ONLY"),
     .help="Read-only 21-frame optical measurement. No lens commands.",
     .help2="Checks preview image buffer and optical quality; log ML/FZ7Cxxxx.CSV."},
    {.name="V17C Speed",.priv=&speed_setting,.max=2,
     .choices=CHOICES("FASTEST","BALANCED","CAREFUL"),
     .help="Frames per sample: 1, 2 or 3 (more = steadier, slower).",
     .help2="CAREFUL also always checks one unit either side of the landing."},
    {.name="V17C Backlash Comp",.priv=&comp_setting,.max=6,
     .choices=CHOICES("OFF","1 UNIT","2 UNITS","3 UNITS","4 UNITS","6 UNITS","AUTO (CAMCAL)"),
     .help="Approach the focus point from the same side the samples were taken.",
     .help2="AUTO: CAMCAL's measured backlash +1 unit, min 2 (ML/LPxxxx.TXT); 3 units without a profile."},
    {.name="V17C Approach",.priv=&big_setting,.max=1,
     .choices=CHOICES("SMALL STEPS","BIG STEPS"),
     .help="BIG STEPS: +/-3 jumps to get near the peak fast (V17A speed), then exact +/-1 finish.",
     .help2="SMALL STEPS: +/-1 only all the way (V17B): slower, always returns exactly to start on failure."},
    {.name="V17C Focus Region",.priv=&focus_region,.max=1,
     .choices=CHOICES("CENTRE 55%","BALANCED 25%"),
     .help="Emphasise the centre target instead of a detailed background.",
     .help2="CENTRE: 55% tight,30% medium,15% wide. BALANCED: original 25%,35%,40%."},
    {.name="V17C Trigger",.priv=&trigger_setting,.max=1,
     .choices=CHOICES("MENU ONLY","HALF-SHUTTER"),
     .help="HALF-SHUTTER: press and hold = fast AF; let go = stop. CAMF pauses while you hold it.",
     .help2="Canon AF is moved to the * button while this is on (restored when OFF / module unloaded)."},
    {.name="V17C Sharpness",.priv=&source_setting,.max=1,
     .choices=CHOICES("YUV PREVIEW","CANON AF DATA"),
     .help="CANON AF DATA: Canon's own focus measurement (Magic Zoom's green; 5D3). Faster, sharper peak.",
     .help2="Used when Canon sends it (5D3); otherwise, and on the 70D, the YUV preview metric."},
    {.name="V17C Stop AF",.priv=&cancel_request,.max=1,
     .choices=CHOICES("OFF","STOP"),
     .help="Request an abort at the next safety check; does not interrupt current Canon motor call.",
     .help2="Use camera power switch if the camera misbehaves. Stop request is software-only."},
};
static unsigned int focus_init(void)
{
    if(is_camera(CAM_MODEL,CAM_FW))
    {
        af_request=measure_request=cancel_request=0;
        worker_exit=worker_busy=0;log_serial=0;
        menu_add("Focus",menu,9);
        task_create("fz17c",29,32768,worker,0);
    }
    return 0;
}
static unsigned int focus_deinit(void)
{
    worker_exit=1;cancel_request=1;af_request=measure_request=0;
    { int n; for(n=0;n<120 && worker_busy;n++)msleep(50); }
    if(worker_busy)return 1; /* refuse clean unload if a motor call is still active */
    if(af_btn_moved){restore_af_button_assignment();af_btn_moved=0;}
    menu_remove("Focus",menu,9);
    return 0;
}
MODULE_INFO_START()
  MODULE_INIT(focus_init)
  MODULE_DEINIT(focus_deinit)
  MODULE_LONGNAME("V17C r8 Fast Contrast AF")
MODULE_INFO_END()
MODULE_CBRS_START()
MODULE_CBRS_END()
MODULE_CONFIGS_START()
  MODULE_CONFIG(af_request)
  MODULE_CONFIG(measure_request)
  MODULE_CONFIG(focus_region)
  MODULE_CONFIG(speed_setting)
  MODULE_CONFIG(comp_setting)
  MODULE_CONFIG(big_setting)
  MODULE_CONFIG(trigger_setting)
  MODULE_CONFIG(source_setting)
MODULE_CONFIGS_END()
MODULE_STRINGS_START()
  MODULE_STRING("Name","V17C r8 Fast Contrast AF")
  MODULE_STRING("Author","experimental")
  MODULE_STRING("License","GPL")
  MODULE_STRING("Summary",CAM_MODEL " hybrid contrast autofocus: fast +/-3 approach, exact +/-1 finish")
  MODULE_STRING("Description","+/-3 probe and climb past the peak, then +/-1 climb back, re-scan, parabola, same-direction landing, verify against the best sample, return to start on failure.")
MODULE_STRINGS_END()
