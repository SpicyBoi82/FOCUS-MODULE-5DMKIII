/* Host simulation of CAMCAL. gcc -O2 -w -I SDK_COMPAT SIM_CAMCAL.c -o sim_camcal && ./sim_camcal
 * Model (assumptions, NOT a real lens): Lorentzian blur on a checkerboard, backlash = first N units after a reversal
 * move nothing, preview shows the lens position LAT frames ago, queued non-blocking moves execute at MOTOR_MS per unit
 * (queue depth 4 units), waited moves complete at once. Truth: FWHM of the contrast curve = 2*width. */
#define UNIT_TEST
#include "CAMCAL.c"
#include "../common/SIM_CARD.h"
#include "../common/REPLAY.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static uint8_t imagebuf[720*480*2];
static struct vram_info_probe mock={imagebuf,720,1440,480};
static uint32_t clk=1000,nrng=777;
int lv=1; struct lens_info_probe lens_info={0};
static int phys=0,tfocus=0,limit_lo=-400,limit_hi=400,backlash=0,slack=0,pdir=0,cmdsum=0,noise_pct=0,width=8,qn=0,q[256];
static int K2=2,K3=3,K3ASYM=0;   /* real +/-2 and +/-3 sizes in +/-1 units (logs: ~2 at 135mm, 7-25 at 18mm); K3ASYM: extra units when +/-3 goes - */
static int MOTOR_MS=22,LAT=1,FPMS=33,mrem=0,fno=0,physh[65536];
static int FLOOR=0,STALE=1;static uint32_t sim_servo_on=0,sim_servo_off=0;   /* C3: Movie Servo flips ON in this clock window (gate test) */   /* C2: FLOOR = blur floor in % of the peak contrast (CAMCAL912F ~48); STALE = new picture only every N vsyncs */
static int rnd(void){nrng=nrng*1664525u+1013904223u;return (int)((nrng>>16)&0x7fff);}
static void regenerate(int p){
    int x,y,blur=absi(p-tfocus),contrast,base=6+144*FLOOR/100;
    if(STALE>1&&fno>1&&fno%STALE)return;   /* picture not refreshed this tick (first picture always drawn) */
    contrast=base+((150-base)*width*width)/(width*width+blur*blur);
    if(rp_n)contrast=6+144*replay_frac1000(p-tfocus)/1000;     /* real curve from a camera log */
    if(noise_pct){int r=rnd()%2001-1000;contrast+=contrast*noise_pct*r/100000;}
    if(contrast<6)contrast=6;
    for(y=100;y<380;y++)for(x=150;x<570;x++){int sign=((x/7+y/9)&1)?1:-1;int v=120+sign*contrast/2;imagebuf[y*1440+x*2+1]=(uint8_t)v;}
    /* C2: a real sensor never gives two identical pictures - tiny per-frame grain on two sampled pixels */
    imagebuf[240*1440+(362+4*(fno&7))*2+1]+=(uint8_t)(1+(fno&1));
    imagebuf[244*1440+(366+4*((fno>>3)&7))*2+1]+=1;
}
static void apply_unit(int mv){
    int dir=mv>0?1:-1;
    if(backlash){ if(dir!=pdir){slack=backlash;pdir=dir;} if(slack>0){slack--;return;} } else pdir=dir;
    if(!((mv>0&&phys+mv>limit_hi)||(mv<0&&phys+mv<limit_lo)))phys+=mv;      /* physical end stops */
}
static void motor_advance(int ms){
    mrem+=ms;
    while(mrem>=MOTOR_MS&&qn){int mv=q[0],i;for(i=1;i<qn;i++)q[i-1]=q[i];qn--;apply_unit(mv);mrem-=MOTOR_MS;}
    if(!qn&&mrem>MOTOR_MS)mrem=MOTOR_MS;
}
/* C5: simulated Canon PROP_LV_FOCUS_DATA (env CFD=1): sent every CFDP vsyncs, CFDLAG frames late, a narrower
   Lorentzian (CFDW, default width/2) on a floor - a stand-in until real 5D3 data exists. CFD=0: never sent (70D). */
static int CFD=0,CFDP=1,CFDLAG=1,CFDW=0;
static void sim_cfd(void){
    uint32_t b[8]={0};int p=physh[fno>CFDLAG?fno-CFDLAG:0],bl=absi(p-tfocus),w=CFDW>0?CFDW:(width/2>0?width/2:1);
    uint32_t v=20000u+(uint32_t)(4000000.0*w*w/(w*w+bl*bl));
    if(noise_pct){int r=rnd()%2001-1000;v+=(uint32_t)((double)v*noise_pct*r/200000.0);}
    b[2]=v/2;b[3]=v-v/2;b[4]=v/3;b[0]=1;b[1]=fno;
    cfd_handler(PROP_LV_FOCUS_DATA,0,b,32);
}
void sim_vsync(void){
    fno++;if(fno>=65535)fno=65535;clk+=FPMS;motor_advance(FPMS);physh[fno]=phys;
    regenerate(physh[fno>LAT?fno-LAT:0]);
    if(CFD&&fno%CFDP==0)sim_cfd();
    vs_ms=clk;vs_seq++;
}
int is_camera(const char*m,const char*f){return 1;}
int is_movie_mode(void){return 1;} uint32_t get_ms_clock(void){return clk;}
void msleep(int ms){clk+=(uint32_t)ms;}
int task_create(const char*a,int b,int c,void(*d)(void*),void*e){return 1;}
void menu_add(const char*a,struct menu_entry*b,int c){}
void menu_remove(const char*a,struct menu_entry*b,int c){}
void powersave_prolong(void){} int bmp_printf(uint32_t f,int x,int y,const char*fmt,...){return 0;} void NotifyBox(int t,const char*f,...){}
int is_manual_focus(void){return 0;} int is_continuous_af(void){return sim_servo_on&&clk>=sim_servo_on&&clk<sim_servo_off;}
int gui_menu_shown(void){return 0;}
static int queued_dir(void){return qn?q[qn-1]:0;}
int lens_focus(int a,int b,int wait,int d){
    int n=absi(b),dir=b>0?1:-1,i,u;
    if(a!=1||!b||n>3)return 0;
    u=n==3?K3+(dir<0?K3ASYM:0):(n==2?K2:1);
    /* refuse only when already against the stop in that direction (queued moves included) */
    { int t=phys,k; for(k=0;k<qn;k++)t+=q[k]; if((dir>0&&t>=limit_hi)||(dir<0&&t<=limit_lo))return 0; }
    if(wait){ while(qn){int mv=q[0],k;for(k=1;k<qn;k++)q[k-1]=q[k];qn--;apply_unit(mv);} for(i=0;i<u;i++)apply_unit(dir); cmdsum+=b; clk+=50+d+(u>3?u*4:0); return 1; }
    if(u<=4?(qn+u>4):(qn>0))return 0;  /* busy: queue holds 4 units; a bigger move needs an idle motor */
    for(i=0;i<u;i++)q[qn++]=dir; cmdsum+=b; return 1;
}
struct vram_info_probe *get_yuv422_vram(void){return &mock;}
static void run(int start_off,int verbose){
    int r;
    phys=start_off;tfocus=0;pdir=1;slack=0;physh[0]=phys;lens_info.lens_exists=1;
    r=calibrate();recommend();write_profile();   /* profile only written when SIMCARD is set */
    printf("w=%2d B=%d LAT=%d motor=%2dms noise=%d%% start=%3d | err=%d settle=%d | B=%2d.%d rep=%2d.%d fwhm=%2d.%d(true %d) noise=%d.%d%% snr=%d.%d lag=%d.%d rate_acc=%3d step=%3d | rec fz(c%d s%d) camf(c%d s%d sens%d) max %du/s | s3=%s%d.%d(true %d) ra=%d land=%d%% | final err %d\n",
        width,backlash,LAT,MOTOR_MS,noise_pct,start_off,cal_err,R.settle,R.back10/10,absi(R.back10)%10,R.rep10<0?-1:R.rep10/10,R.rep10<0?0:R.rep10%10,R.width10/10,R.width10%10,2*width,
        R.noise_bp/100,(R.noise_bp%100)/10,R.snr10/10,R.snr10%10,R.lag10/10,R.lag10%10,R.rate_acc100,R.rate_step100,
        RC.fz_comp_units,RC.fz_speed,RC.camf_comp_units,RC.camf_speed,RC.camf_sens,RC.max_ups,R.step3_sat?">=":"",R.step3_10/10,R.step3_10%10,K3,R.reanchor,R.final_bp/100,absi(phys-tfocus));
    if(verbose)write_csv();
}
int main(int argc,char**argv){
    if(getenv("FLOOR"))FLOOR=atoi(getenv("FLOOR"));
    if(getenv("STALE"))STALE=atoi(getenv("STALE"));
    if(getenv("FPMS"))FPMS=atoi(getenv("FPMS"));
    if(getenv("CFD"))CFD=atoi(getenv("CFD"));
    if(getenv("CFDP"))CFDP=atoi(getenv("CFDP"));
    if(getenv("CFDLAG"))CFDLAG=atoi(getenv("CFDLAG"));
    if(getenv("CFDW"))CFDW=atoi(getenv("CFDW"));
    if(argc>1&&!strcmp(argv[1],"cfd")){
        /* C5: Canon focus data logging: sent every frame / every 2nd frame / never; CSV to stdout-adjacent file */
        int ps[3]={1,2,0},i;
        for(i=0;i<3;i++){pid_t pp;fflush(stdout);pp=fork();
            if(pp==0){limit_lo=-300;limit_hi=300;width=8;backlash=2;LAT=1;noise_pct=2;CFD=ps[i]>0;CFDP=ps[i]>0?ps[i]:1;
                cfd_seq=0;printf("[canon data every %d frames] ",ps[i]);
                {uint32_t c0=cfd_seq,t0=clk;run(0,0);R.c_events=(int)(cfd_seq-c0);R.c_ms=(int)(clk-t0);}
                printf("      canon events=%d noise_ab=%d noise_n=%d rate_x10=%d shift=%d\n",R.c_events,R.c_noise_ab,R.c_noise_n,R.c_rate10,cfd_sh_ab);
                if(getenv("CSVOUT")){char fn[256];snprintf(fn,sizeof fn,"%s_%d.CSV",getenv("CSVOUT"),ps[i]);setenv("LOGOUT",fn,1);write_csv();}
                fflush(stdout);_exit(0);}waitpid(pp,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"mon")){
        /* C5: the 20 s monitor with the lens still (a hand turning the ring is not modelled) */
        CFD=1;width=8;phys=5;physh[0]=5;mon_request=1;log_setting=1;lens_info.lens_exists=1;
        monitor();printf("monitor rows=%d events=%d last ab=%d\n",mon_n,mon_n?(int)mon_tab[mon_n-1][1]:0,mon_n?(int)(mon_tab[mon_n-1][4]+mon_tab[mon_n-1][5]):0);
        return 0;}
    if(argc>1&&!strcmp(argv[1],"c912")){
        /* first 4: closest fit to the real CAMCAL912F curve (Lorentzian w=26 on a 48% floor: 88% at 10 units,
           76% at 24, 60% at 48, 52% at 93 off the peak - measured 88/76/60/48%). */
        /* C2: the CAMCAL912F situation - 18-135 @64mm, very broad hill, blur floor ~48% of the peak, started
           in focus (Canon AF), Sweep Range 90; variants: started off focus, noisier, slow/stale pictures */
        struct{int w,fl,st,nz,cs,stale,fpms;}C[]={{26,48,0,1,1,1,33},{26,48,0,1,1,1,157},{26,48,4,2,1,1,33},{26,48,-30,1,1,1,33},{60,48,0,1,1,1,33},{60,48,0,1,1,1,157},{60,48,0,2,1,5,33},{60,48,15,1,1,1,33},
            {60,48,-15,1,1,1,33},{40,40,0,1,1,1,33},{80,55,0,1,1,1,33},{60,48,0,1,0,1,33},{60,48,30,1,1,1,33},{30,30,0,2,1,3,33}};
        int i;
        for(i=0;i<(int)(sizeof C/sizeof C[0]);i++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=-150;limit_hi=200;width=C[i].w;FLOOR=C[i].fl;backlash=2;LAT=1;MOTOR_MS=18;noise_pct=C[i].nz;cap_setting=C[i].cs;STALE=C[i].stale;FPMS=C[i].fpms;
                printf("[broad w=%d floor=%d%% range=%d stale=%d frame=%dms] ",C[i].w,C[i].fl,cap_units(),STALE,FPMS);run(C[i].st,0);
                printf("      edge_retry=%d probe_rev=%d broad_stops=%d range_hint=%d stale=%d kept=%d pic=%dms vsync=%dms sim_time=%us\n",R.edge_retry,R.probe_rev,R.broad,R.range_hint,R.stale,R.stale_kept,R.fp_ms,R.vs_ms,(clk-1000)/1000);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"retry")){
        /* C2: peak beyond what the first try can reach (start far off, small Sweep Range): edge retry */
        int sts[6]={-55,55,-80,80,-40,40},crs[6]={0,0,1,1,0,0},i;
        for(i=0;i<6;i++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=-300;limit_hi=300;width=8;backlash=2;LAT=1;MOTOR_MS=22;noise_pct=2;cap_setting=crs[i];
                printf("[retry range=%d] ",cap_units());run(sts[i],0);
                printf("      edge_retry=%d probe_rev=%d broad=%d\n",R.edge_retry,R.probe_rev,R.broad);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>2&&!strcmp(argv[1],"replay")){
        /* real sharpness curve (tests/curves): starts 0, +/-6, +/-15; Sweep Range 150. With SIMCARD=dir the last
           successful run's lens profile is written to dir/LPxxxx.TXT (start 0 runs last) */
        int sts[5]={15,-15,6,-6,0},i;
        replay_load(argv[2]);
        for(i=0;i<5;i++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=rp_lo>-100000?rp_lo:-150;limit_hi=rp_hi<100000?rp_hi:150;width=8;backlash=rp_backlash>=0?rp_backlash:2;
                K3=rp_k3>0?rp_k3:3;LAT=1;MOTOR_MS=20;noise_pct=rp_noise>=0?rp_noise:1;cap_setting=2;lens_info.focal_len=rp_focal;lens_info.lens_id=rp_lensid;
                printf("[replay %s] ",strrchr(argv[2],'/')?strrchr(argv[2],'/')+1:argv[2]);run(sts[i],0);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"gate")){
        /* C3: Movie Servo switched ON for 1 s mid-run (must ride through) and for 5 s (must stop: err 1, gate_bits 8) */
        int durs[2]={1000,5000},i;
        for(i=0;i<2;i++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=-300;limit_hi=300;width=8;backlash=2;LAT=1;noise_pct=2;sim_servo_on=8000;sim_servo_off=8000+durs[i];
                printf("[servo ON for %d ms at t=7 s] ",durs[i]);run(0,0);
                printf("      gate_bits=%d gate_blips=%d stage='%s'\n",fail_gate,R.gate_blips,fail_stage);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"frozen")){
        /* C2: preview frozen (mlv_lite Framing preview while recording): must stop with err 8, not report a curve */
        pid_t p;fflush(stdout);p=fork();
        if(p==0){limit_lo=-300;limit_hi=300;width=8;backlash=2;LAT=1;noise_pct=2;STALE=100000;printf("[frozen preview] ");run(0,0);fflush(stdout);_exit(0);}waitpid(p,0,0);
        return 0;}
    int ws[3]={4,8,14},bs[3]={0,2,4},lats[3]={0,1,3},mms[3]={15,22,60},w,b,l,m,st[3]={0,12,-25},s,nz[2]={0,3},z;
    if(argc>1&&!strcmp(argv[1],"one")){width=argc>3?atoi(argv[3]):8;backlash=argc>4?atoi(argv[4]):3;LAT=argc>5?atoi(argv[5]):1;MOTOR_MS=argc>6?atoi(argv[6]):22;noise_pct=argc>7?atoi(argv[7]):2;if(argc>8)FPMS=atoi(argv[8]);run(argc>2?atoi(argv[2]):10,1);return 0;}
    if(argc>1&&!strcmp(argv[1],"asym")){
        /* +/-3 that is a different size going out and coming back: the undo leaves a slip, re-anchor must catch it */
        struct{const char*n;int lo,hi,w,b,k3,as;}L[]={{"18-135 @135",-12,36,1,2,2,1},{"18-135 @135",-12,36,2,1,2,2},
            {"18-135 @18 ",-30,75,10,2,7,3},{"18-135 @18 ",-30,75,15,2,25,6},{"50 STM     ",-110,590,15,2,3,2}};
        int i,zz,nz3[2]={0,3};
        for(i=0;i<5;i++)for(zz=0;zz<2;zz++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=L[i].lo;limit_hi=L[i].hi;width=L[i].w;backlash=L[i].b;K3=getenv("K3")?atoi(getenv("K3")):L[i].k3;K3ASYM=L[i].as;LAT=1;MOTOR_MS=20;noise_pct=nz3[zz];
                if(width>=10)cap_setting=2;printf("[%s asym +%d] ",L[i].n,K3ASYM);run(0,0);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"lens")){
        /* profiles from the user's real lens-mapper logs (LMPxxxx.CSV): travel in waited +/-1 commands,
           far stop / near stop relative to a subject at ~2 m (or 0.5 m), backlash 0-2 commands */
        struct{const char*n;int lo,hi,w,b,mms,k3;}L[]={
            {"18-135 @135 subj 2m  ",-12,36,1,2,18,2},{"18-135 @135 subj 2m  ",-12,36,2,1,18,2},
            {"18-135 @135 subj 0.5m",-38,10,1,2,18,2},{"18-135 @135 subj 0.5m",-38,10,2,2,18,3},
            {"18-135 @64 subj 2m   ",-22,51,2,2,18,3},
            {"18-135 @18 subj 2m   ",-30,75,10,2,18,7},{"18-135 @18 subj 2m   ",-30,75,15,2,18,25},
            {"18-135 @18 subj 0.6m ",-75,30,10,1,18,25},
            {"17-55 @55 subj 2m    ",-25,66,3,1,21,3},{"17-55 @55 subj 2m    ",-25,66,2,0,21,6},
            {"50 STM subj 2m       ",-110,590,15,2,30,3},{"50 STM subj 2m       ",-110,590,25,3,30,6},
            {"50 STM subj 0.5m     ",-560,140,10,2,30,3}};
        int nz2[3]={0,3,6},st2[3]={0,2,-3},i,zz,ss;
        for(i=0;i<(int)(sizeof L/sizeof L[0]);i++)for(zz=0;zz<3;zz++)for(ss=0;ss<3;ss++){pid_t p;fflush(stdout);p=fork();
            if(p==0){limit_lo=L[i].lo;limit_hi=L[i].hi;width=L[i].w;backlash=L[i].b;K3=getenv("K3")?atoi(getenv("K3")):L[i].k3;LAT=1;MOTOR_MS=L[i].mms;noise_pct=nz2[zz];if(width>=20)cap_setting=2;if(width>=10&&L[i].lo>-200&&L[i].hi<200)cap_setting=2;
                int so=st2[ss]*(width>4?width:2); if(so<=limit_lo)so=limit_lo+1; if(so>=limit_hi)so=limit_hi-1;
                printf("[%s] ",L[i].n);run(so,0);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    if(argc>1&&!strcmp(argv[1],"edge")){
        int cases[6][5]={{-300,10,0,0,0},{-10,300,0,0,0},{-300,10,0,12,0},{-300,300,2000,0,0},{-300,300,8,0,10},{-300,300,8,25,6}};int c;
        for(c=0;c<6;c++){pid_t p;fflush(stdout);p=fork();if(p==0){limit_lo=cases[c][0];limit_hi=cases[c][1];width=cases[c][2]?cases[c][2]:8;backlash=2;LAT=1;MOTOR_MS=22;noise_pct=cases[c][4];
            printf("[limits %d..%d%s noise %d%% start %d] ",limit_lo,limit_hi,cases[c][2]==2000?" FLAT TARGET":"",noise_pct,cases[c][3]);run(cases[c][3],0);fflush(stdout);_exit(0);}waitpid(p,0,0);}
        return 0;}
    for(w=0;w<3;w++)for(b=0;b<3;b++)for(l=0;l<3;l++)for(m=0;m<3;m++)for(z=0;z<2;z++)for(s=0;s<3;s++){
        pid_t p;
        if(!(m==1||l==1)&&!(w==1&&b==1))continue;           /* trim: full grid only on the central values */
        fflush(stdout);p=fork();
        if(p==0){width=ws[w];backlash=bs[b];LAT=lats[l];MOTOR_MS=mms[m];noise_pct=nz[z];run(st[s],0);fflush(stdout);_exit(0);}
        waitpid(p,0,0);
    }
    return 0;
}
