[Handover note: this is the 70D user guide of this module. The same module is built for the 5D Mark III 1.1.3
 (see ../../5D3_QUICK_START.txt). Build everything with ../../build.sh - the per-module BUILD_*.sh scripts were
 replaced by it. On the 5D3 read "Movie Servo AF" as Canon continuous AF and "mode dial" as the Live View switch.
 Versions now: CAMCAL C5 (C4 + Canon focus data probe, below; C4 writes the lens profile ML/LPxxxx.TXT), V17C r5 (half-shutter trigger) and CAMF C3
 (pauses while half-pressed); Backlash Comp AUTO reads the profile. See ../../START_HERE_CHATGPT.md section 2.]

CAMCAL C5 (18 Oct 2026) - Canon focus data probe
 - Canon sends PROP_LV_FOCUS_DATA (8 ints) in LiveView on the 5D3 (Magic Zoom's green border uses
   buf[2]+buf[3]); the 70D never sends it. C5 registers a property handler for it (module table
   __module_prophandlers_camcal, no new import) and:
   * logs canon_ab = (buf[2]+buf[3])>>ab_shift and canon_c = buf[4]>>c_shift at every sweep position next to
     our sharpness (same two pictures), plus canon_new = events during that measurement;
   * "# CANON" line: event count, rate and noise at the final stationary point, and the SAME peak / backlash /
     FWHM / 70% width analysis run on canon_ab, canon_c and ours side by side;
   * menu "CAL Canon Focus Data" = MONITOR 20 S: no lens driving, one row per frame (all 8 ints, ours,
     focus_pos) -> ML/CFDxxxxx.CSV; screen shows rate and values live.
 - The calibration, its results and the lens profile still come ONLY from our own sharpness.
 - Sim (CFD=1, Canon curve half as wide): Canon FWHM 8.4-8.6 (true 8), backlash 2.0 (true 2); ours 16.6.
   All golden metrics unchanged. ./sim_camcal cfd / ./sim_camcal mon.

CAMCAL C3 - in-camera focus calibration for FZ17A / V17C / CAMF  (Canon 70D, fw 1.1.2, ML ABI 8)
Built 15 Oct 2026. Simulation tested (HOST_TEST_RESULTS.txt). NOT yet run to the end on a camera.

INSTALL  Copy CAMCAL.MO to ML/MODULES/ (replaces C2), restart. Menu: Focus tab -> CAL ...

YOUR SECOND RUN (CAMCAL73E6.CSV, C2)
 - err 1 = a safety check failed before the first picture was read: nothing was measured.
   C2 did not record WHICH check (C3 does). It is one of: LiveView off or paused (ML power saving
   "turn off LCD/sensor"), mode dial not on movie, lens AF/MF switch on MF, Canon Movie Servo AF
   on, no lens, camera busy taking/saving a photo.
 - Most likely MF: the old v2 instructions said "focus with Canon AF, then switch to MF". CAMCAL,
   FZ17A, V17C and CAMF all need the lens switch on AF - they drive the focus motor themselves.
 - Exposure: shutter value 30 (= 1/30 in movie mode), ISO 200 - so the slow 157 ms pictures of run 1
   were probably not a long-shutter LiveView (run 1 did not log exposure).

WHAT C3 ADDS
 - After the 6 s countdown it waits (up to 60 s) until the ML menu is closed and every check passes,
   showing what is wrong ("lens switch is on MF: set it to AF", "Canon Movie Servo AF is ON" ...).
   Fix it and the run starts 2 s later by itself.
 - A check that fails for less than 1.5 s mid-run (e.g. a short "camera busy") no longer stops it.
 - If it does stop: the screen lists the failed condition(s) and the step it was in; the CSV has
   gate_bits, gate_blips, start_wait_ms, menu_open_at_start, fail_stage.
 - Everything else is C2 (results identical in simulation).

YOUR FIRST RUN (CAMCAL912F.CSV, v2) - see C2 notes
 - It FAILED, but the file says "err 0": a C1/v2 bug wiped the error code. The real error was 4
   (focus peak not crossed). Ignore its RECOMMEND line - those are defaults, nothing was measured.
 - Why it failed: you started in focus (good). The first sweep went down and, because the focus hill
   at 64 mm on that target is very broad (sharpness only fell to 48% of the peak after 95 units),
   it never met its "past the peak" rule and ran the full 95 units. The sweep back up then ran out
   of its step budget at +3, just short of the peak. Both are fixed.
 - The CSV reported 157 ms per frame (normal is ~33 ms at 30p). Every position then takes ~1 s.
   C2 now measures this two ways (vsync_ms and picture_ms) and warns on screen. Please tell me what
   was on: FPS override? Global Draw / zebras / peaking? HDMI? ML or Canon menu open? 5x / crop?
 - Many identical values in the table were NOT frozen pictures: the sharpness value rounded the
   mean gradient down to a whole number. On soft or low-detail pictures that is a 15-40% step
   (your V17C logs: 85 mm tails had a mean gradient of 1.6-3.5). C2 keeps the fraction.
   -> FZ17A / V17C / CAMF have the same rounding (and CAMF still has the old >50% dark check).
      That is very likely part of the "flat, noisy tails" problem. Fix offered as V17C r4.
 - The two down sweeps disagree by ~7 units at the same command position, while the up sweep and
   the second down sweep agree. Most likely the lens hit an end stop near -90 and kept "accepting"
   commands without moving (seen before in V17C logs). C2 logs Canon's focus_pos and focus
   distance at every position so the next CSV will show it.

HOW TO RUN
 1. Target: CAMCAL_TARGET.png full screen on a monitor, filling the centre of the frame, camera
    square to it, no moire at 10x. Medium brightness, screen sleep off.
 2. Movie mode, LiveView, normal 30p/25p, FPS override OFF, Global Draw OFF (cleanest timing).
 3. Lens switch on AF (and leave it there), Movie Servo AF OFF. Focus once with Canon AF
    (half-press), let go, then run.
 4. CAL Sweep Range: 150 for this run (the 64 mm hill was wider than 90 allows).
 5. CAL Run Calibration -> RUN, close the menu within 6 s, don't touch the camera.
    1.5 - 3 minutes at 30p; much longer if the SLOW PICTURE warning appears.

WHAT CHANGED IN C2 (still in C3)
 - Real error code kept; on failure the lens is left at the sharpest point seen, and the screen
   says what went wrong (e.g. "focus hill wider than the Sweep Range: set 150").
 - Return sweep may travel back across the whole range (C1 stopped after cap+8 steps).
 - Broad-hill stop: 10+ units past the peak and under 65% (with 4+ units of flank under 70%).
 - If the peak was still not crossed and that end is not an end stop: one automatic restart
   from the sharp end, sweeping that way first (CSV edge_retry=1).
 - Peak positions of two sweeps are compared only over the range both covered (a sweep that
   started on a broad peak sees one side only - sim showed a false 23-unit "repeat" before).
 - Sharpness keeps its fraction (see above). Dark check >90% near-black (was >50%).
 - Waits for a picture that really changed (up to 300 ms); 12 unchanged in a row -> err 8
   "LiveView picture is not updating" (e.g. mlv_lite Framing preview while recording).
 - "+/-3 = X units" and "lag" are reported as "not measurable" when the 3-unit step changes the
   picture less than 4% (broad hill) instead of printing a wrong number.
 - Re-anchor tolerance uses the 70% width when the FWHM cannot be measured.

NEW CSV FIELDS (RESULT line, after final_sharp_bp)
 picture_ms   time between really new pictures      vsync_ms     time between ML vsync callbacks
 stale_ticks  ticks that still showed the old picture stale_kept  used anyway after 300 ms
 edge_retry   1 = restarted from the sharp end       probe_reversed 1 = first 3 steps said "wrong way"
 broad_stops  sweeps ended by the broad-hill rule    width70_x10  full width at 70% of the peak
 range_hint   1 = hill wider than the Sweep Range    run_ms       total run time
 lens line: + shutter_raw, iso_raw.  Table: pos,sweep1,sweep2,sweep3,focus_pos,focus_cm
 (sweep1 is the FIRST sweep - its direction is written in the line above the table; v2 called it
 "up1" even when it went down, as in 912F).

gate_bits (C3): 1 LiveView off/paused, 2 not movie mode, 4 lens on MF, 8 Movie Servo AF on,
16 no lens, 32 camera busy (job state).
Error codes: 0 ok, 1 gate (LiveView / movie mode / AF lens / Movie Servo OFF), 2 stopped,
3 no usable picture, 4 no peak (not crossed / too flat), 5 no response to a step, 6 lens did not
move, 7 no steep flank, 8 picture not updating.
Please send the CSV back after the run.
