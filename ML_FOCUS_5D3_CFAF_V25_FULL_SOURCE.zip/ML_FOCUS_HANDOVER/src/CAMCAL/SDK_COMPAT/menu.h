#ifndef _menu_h_
#define _menu_h_
#include <stdint.h>
#include <stdbool.h>
struct menu;
struct menu_entry;
struct menu_display_info;
typedef void (*menu_select_func)(void *,int);
typedef void (*menu_update_func)(struct menu_entry*,struct menu_display_info*);
struct menu_entry {
    struct menu_entry *next,*prev,*children,*parent;
    struct menu *parent_menu;
    const char *name; void *priv; int min,max; const char **choices;
    menu_select_func select,select_Q;menu_update_func update;
    unsigned selected:1,starred:1,hidden:1,jhidden:1,jstarred:1,shidden:1,placeholder:1,cust_loaded:1;
    unsigned advanced:1,edit_mode:8,unit:4,icon_type:4;
    const char *help,*help2;
    int16_t submenu_width,submenu_height;
    uint32_t depends_on,works_best_in;
    union { uint64_t usage_counters; struct {union{float usage_counter_long_term;uint32_t usage_counter_long_term_raw;};union{float usage_counter_short_term;uint32_t usage_counter_short_term_raw;};};};
};
#define CHOICES(...) (const char *[]) { __VA_ARGS__ }
#define IT_ACTION 5
#define DEP_LIVEVIEW (1u<<1)
#endif
extern void menu_add(const char *, struct menu_entry *, int);
