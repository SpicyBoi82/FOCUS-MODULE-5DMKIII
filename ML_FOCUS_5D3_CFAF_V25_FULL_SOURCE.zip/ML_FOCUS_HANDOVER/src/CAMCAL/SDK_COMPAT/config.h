#ifndef _config_h_
#define _config_h_
#include <stddef.h>
struct config_var;
typedef int (*config_var_change_func)(struct config_var *,int,int);
struct config_var {const char *name;int *value;int default_value;config_var_change_func change_cbr;};
#define CONFIG_INT(NAME,VAR,VALUE) int VAR=VALUE; static __attribute__((used,section(".config_vars"))) struct config_var __config_##VAR = { .name=NAME,.value=&VAR,.default_value=VALUE,.change_cbr=NULL }
#endif
