#ifndef _dryos_h_
#define _dryos_h_
#include <stdint.h>
#endif
