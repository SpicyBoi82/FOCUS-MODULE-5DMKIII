#!/usr/bin/env bash
# =====================================================================================================
# build.sh - builds the Magic Lantern modules (CAMCAL, FZ17C = "V17C", CAMF, CFAF = Canon-data AF) for one or both cameras.
#
#   ./build.sh            -> bin/5D3/*.MO  and  bin/70D/*.MO
#   ./build.sh 5D3        -> only the Canon 5D Mark III 1.1.3 builds
#   ./build.sh 70D        -> only the Canon 70D 1.1.2 builds
#
# Needs: clang (any recent version; it already contains the ARM back end), llvm-objcopy, llvm-readelf
#        (or binutils readelf). If they are not on PATH:  CLANG=/x/clang-17 OBJCOPY=/x/llvm-objcopy ./build.sh
# Reference compiler: clang 17 from ML70D_Parfocal_V7_Complete_Dev_Environment/toolchain (gives the
# sha256 values in bin/SHA256SUMS.txt). Any other clang works but gives different (equally valid) bytes.
#
# The build REFUSES to produce a module when any of these safety checks fails:
#   1. an imported symbol is not listed in ALLOWED_IMPORTS.txt   (unknown symbol = module won't load)
#   2. a relocation other than R_ARM_ABS32 appears              (ML's module loader handles only this)
#   3. a printf-style format string uses %% or %u                (Canon's vsnprintf mis-handles both)
#   4. the camera model / firmware strings for is_camera() are missing from the binary
# =====================================================================================================
set -euo pipefail
cd "$(dirname "$0")"
CLANG=${CLANG:-clang}
OBJCOPY=${OBJCOPY:-llvm-objcopy}
READELF=${READELF:-$(command -v llvm-readelf || command -v readelf || true)}
command -v "$CLANG"   >/dev/null || { echo "ERROR: clang not found (set CLANG=/path/to/clang)"; exit 1; }
command -v "$OBJCOPY" >/dev/null || { echo "ERROR: llvm-objcopy not found (set OBJCOPY=...)"; exit 1; }
[ -n "$READELF" ] || { echo "ERROR: llvm-readelf/readelf not found"; exit 1; }

CAMS=${1:-"5D3 70D"}
MODULES="CAMCAL FZ17C CAMF CFAF"
FAIL=0
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

for CAM in $CAMS; do
  case "$CAM" in
    5D3) DEF="-DCAM_5D3"; MODEL="5D3"; FW="1.1.3";;
    70D) DEF="";          MODEL="70D"; FW="1.1.2";;
    *) echo "ERROR: camera must be 5D3 or 70D (got '$CAM')"; exit 1;;
  esac
  mkdir -p "bin/$CAM"
  for M in $MODULES; do
    SRC="src/$M/$M.c"
    # check 3: format strings (only lines that call a printf-style function)
    if grep -nE '(bmp_printf|NotifyBox|snprintf)\(' "$SRC" | grep -E '"[^"]*(%%|%u)[^"]*"' ; then
      echo "FAIL $CAM/$M: %% or %u in a format string (see lines above). Write 'pct' and use %d." ; FAIL=1; continue
    fi
    "$CLANG" --target=arm-none-eabi -mcpu=arm946e-s -marm -mlong-calls -ffreestanding -fno-builtin \
      -fno-stack-protector -fno-unwind-tables -fno-asynchronous-unwind-tables -Os -Wall \
      -Wno-unused-function -Wno-unused-variable -Wno-missing-braces -Wno-misleading-indentation \
      $DEF -I "src/$M/SDK_COMPAT" -c "$SRC" -o "$TMP/$M.o"
    "$OBJCOPY" --remove-section=.ARM.exidx --remove-section=.rel.ARM.exidx \
      --remove-section=.llvm_addrsig --remove-section=.comment "$TMP/$M.o" "$TMP/$M.MO"
    # check 1: imports
    BAD=""
    for S in $("$READELF" -s "$TMP/$M.MO" | awk '/ UND / && $8!="" {print $8}' | sort -u); do
      grep -qx "$S" ALLOWED_IMPORTS.txt || BAD="$BAD $S"
    done
    if [ -n "$BAD" ]; then echo "FAIL $CAM/$M: imports not in ALLOWED_IMPORTS.txt:$BAD"; FAIL=1; continue; fi
    # check 2: relocations
    RELOC=$("$READELF" -r "$TMP/$M.MO" | awk '/R_ARM_/ {print $3}' | sort -u | tr '\n' ' ')
    if [ "$RELOC" != "R_ARM_ABS32 " ]; then echo "FAIL $CAM/$M: relocations '$RELOC' (only R_ARM_ABS32 allowed)"; FAIL=1; continue; fi
    # check 4: camera strings
    strings -n 3 "$TMP/$M.MO" > "$TMP/$M.str"
    if ! grep -qx "$MODEL" "$TMP/$M.str" || ! grep -qx "$FW" "$TMP/$M.str"; then
      echo "FAIL $CAM/$M: is_camera(\"$MODEL\",\"$FW\") strings not found"; FAIL=1; continue; fi
    cp "$TMP/$M.MO" "bin/$CAM/$M.MO"
    printf 'OK   %-4s %-7s %s\n' "$CAM" "$M" "$(sha256sum "bin/$CAM/$M.MO" | cut -c1-16)"
  done
done
( cd bin && find . -name '*.MO' | sort | xargs sha256sum > SHA256SUMS.txt )
[ $FAIL = 0 ] && echo "BUILD OK -> bin/<camera>/*.MO  (copy the .MO files to ML/MODULES/ on that camera's card)" || { echo "BUILD FAILED"; exit 1; }
