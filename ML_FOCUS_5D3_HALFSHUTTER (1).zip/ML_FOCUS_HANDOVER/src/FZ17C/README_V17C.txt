[Handover note: this is the 70D user guide of this module. The same module is built for the 5D Mark III 1.1.3
 (see ../../5D3_QUICK_START.txt). Build everything with ../../build.sh - the per-module BUILD_*.sh scripts were
 replaced by it. On the 5D3 read "Movie Servo AF" as Canon continuous AF and "mode dial" as the Live View switch.
 Versions now: CAMCAL C4 (writes the lens profile ML/LPxxxx.TXT), V17C r5 (half-shutter trigger) and CAMF C3
 (pauses while half-pressed); Backlash Comp AUTO reads the profile. See ../../START_HERE_CHATGPT.md section 2.]

FZ17C.MO - V17C r3 hybrid contrast AF   (Canon 70D fw 1.1.2, ML ABI 8)
Replace your FZ17C.MO with this one. Same menu, settings and log name (ML/FZ7Cxxxx.CSV);
menu and log header say "V17C r3". Not yet camera tested.

WHAT CHANGED (from your r2 test, FZ7C34FD / 34FE / 34FF / 3500)
1. 85mm and longer: strides are capped at 4 units. Your 85mm logs show the focus peak is only
   about 2 small steps wide; a stride of 8 on flat blur could step right over it.
2. Flat blur: when the picture has not got any sharper yet, one noisy dip no longer counts as
   "passed the peak" - it needs two drops in a row. Same in the big-step phase for small dips
   (a big drop still counts at once). Your 9.4 s 85mm run was thrown off by exactly such a dip.
3. Start at a stop: if the first big-step probe reads exactly like the start, it probably did
   not move (the lens "accepts" a big step at a stop without moving). Then V17C also looks
   after the first step back. In your 18mm run that skipped point was the focus itself, which
   is why it then crawled 37 units back. This costs one extra picture, only in that situation.

TRIED AND LEFT OUT
 Three ways of lengthening the stride during long climbs (for the 18mm crawl). None helped on
 average in the simulator and some made other lenses slower, so fix 3 addresses the cause instead.

SIMULATOR (source/SIM_AF.c, HOST_TEST_RESULTS.txt)
 18-135 and 17-55: still 100% of runs at >=95% of peak sharpness, including the "accepts at
 the stop" behaviour and any big-step size. 85mm (narrow peak): 3.8 -> 3.3 s and 4.5 -> 3.7 s.
 Elsewhere within ~0.25 s of r2. Accepted-but-soft landings across the whole test set: 2 -> 1
 (BALANCED) and 4 -> 1 (FASTEST), all on the 50mm STM starting very far out of focus.

PLEASE TEST
 Movie Servo AF OFF, lens on AF. Some runs at 85-135mm from blurry starts, a couple starting at
 the close-focus stop at 18mm, and a couple starting already in focus. Send the FZ7Cxxxx logs.
