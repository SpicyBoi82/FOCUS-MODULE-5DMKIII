/*
 * CAMCAL - Canon EOS 70D 1.1.2 and 5D Mark III 1.1.3 - lens focus calibration (C4, 16 Oct 2026).
 * C4: after a successful run writes the lens profile ML/LPxxxx.TXT (src/common/LENS_PROFILE.h) that V17C r4 and
 *     CAMF C2 use for their AUTO settings; the result screen says so.
 * C3.1: camera profile (-DCAM_5D3), on-screen texts without "%%" and "%u" (Canon vsnprintf mis-handles them).
 * C3 (after CAMCAL73E6 stopped with a bare "err 1"): names the safety condition that failed (screen + CSV
 * gate_bits / fail_stage), waits at the start until it is fixed and the ML menu is closed, and rides through
 * blips shorter than 1.5 s.
 * C2 changes after the first camera run (CAMCAL912F): real error code kept (C1 reported err 0 on failure);
 * return sweep no longer runs out of steps; broad-hill stop; restart from the sharp end once if the peak was
 * not crossed; sharpness keeps its fraction (FZ17A rounded the mean gradient down to a whole number);
 * dark-frame check >90% (was >50%); waits for a really new picture; vsync / picture timing, focus_pos and
 * focus distance logged; on-screen warning when the picture updates slowly.
 * Point the camera at a high-contrast, flat target (a monitor showing CAMCAL_TARGET.png works), focus roughly
 * with Canon AF, then run "CAL Run Calibration". It measures, with the same sharpness metric the FZ17A and
 * CAMF modules use:
 *   noise            - stationary frame-to-frame sharpness variation
 *   hill shape       - sharpness vs focus-command position, swept up, down, up
 *   backlash         - difference between the up-sweep and down-sweep peak positions
 *   repeatability    - peak position scatter between the two up-sweeps
 *   peak width       - full width at half maximum, in command units
 *   image lag        - frames between a focus command and the picture changing
 *   motor speed      - non-blocking 1-unit-per-frame acceptance and 3-unit step response
 *   end stops        - where the lens refuses further steps
 * and then prints recommended settings for FZ17A and CAMF, writes ML/CAMCALxxxx.CSV with every raw point.
 * Command units are NOT encoder counts. Not camera tested.
 */
#define MODULE
#define MODULE_NAME camcal
#include <stdint.h>
#include "module.h"
#include "dryos.h"
#include "menu.h"
#include "config.h"


/* ===================== CAMERA PROFILE (the ONLY camera-specific part of this file) =====================
 * Default build = Canon EOS 70D fw 1.1.2.   Build with -DCAM_5D3 = Canon EOS 5D Mark III fw 1.1.3.
 * Both: Magic Lantern module API 8, DIGIC 5, LiveView YUV422 preview, CBR_VSYNC once per LiveView frame.
 * Only text and the is_camera() check differ. Keep the 70D strings byte-identical (proves 70D unchanged). */
#if defined(CAM_5D3)
#define CAM_MODEL        "5D3"
#define CAM_FW           "1.1.3"
#define CAM_CSV_TAG      " [5D3 1.1.3]"
#define CAM_SERVO        "continuous AF"          /* 5D3 has no Movie Servo AF; ML reports none in movie mode */
#define CAM_SERVO_MUST   "Canon continuous AF must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (Live View switch to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, lens on AF, continuous AF OFF"
#else   /* default: 70D */
#define CAM_MODEL        "70D"
#define CAM_FW           "1.1.2"
#define CAM_CSV_TAG      ""
#define CAM_SERVO        "Movie Servo AF"
#define CAM_SERVO_MUST   "Movie Servo must be OFF."
#define CAM_MOVIE_HOWTO  "camera is not in movie mode (mode dial to the movie camera)"
#define CAM_GATE_SHORT   "stopped: needs LiveView, movie mode, AF lens, Movie Servo OFF"
#endif
/* ======================================================================================================== */
extern int is_camera(const char*,const char*);
extern int is_movie_mode(void);
extern uint32_t get_ms_clock(void);
extern void msleep(int);
extern int task_create(const char*,int,int,void(*)(void*),void*);
extern int FIO_CreateFile(const char*);
extern int FIO_WriteFile(int,const void*,unsigned);
extern int FIO_CloseFile(int);
extern void menu_remove(const char*,struct menu_entry*,int);
extern int lv;
extern int is_manual_focus(void);
extern int is_continuous_af(void);
extern int lens_focus(int,int,int,int);
struct vram_info_probe { uint8_t *vram; int width,pitch,height; };
extern struct vram_info_probe *get_yuv422_vram(void);
struct lens_info_probe
{
    void *token;
    char name[32];
    unsigned focal_len;
    unsigned focus_dist;
    unsigned IS;
    unsigned aperture;
    int ae;
    unsigned shutter;
    unsigned iso;
    unsigned iso_auto;
    unsigned iso_analog_raw;
    int iso_digital_ev;
    unsigned iso_equiv_raw;
    unsigned hyperfocal;
    unsigned dof_near;
    unsigned dof_far;
    unsigned job_state;
    unsigned wb_mode;
    unsigned kelvin;
    unsigned WBGain_R;
    unsigned WBGain_G;
    unsigned WBGain_B;
    int8_t wbs_gm;
    int8_t wbs_ba;
    unsigned picstyle;
    uint8_t raw_aperture;
    uint8_t raw_shutter;
    uint8_t raw_iso;
    uint8_t raw_iso_auto;
    uint8_t raw_picstyle;
    uint8_t raw_aperture_min;
    uint8_t raw_aperture_max;
    int flash_ae;
    uint16_t lens_id;
    uint16_t dof_flags;
    int dof_diffraction_blur;
    int focus_pos;
    uint8_t lens_exists;
};
extern struct lens_info_probe lens_info;
#include "../common/LENS_PROFILE.h"      /* C4: writes the per-lens profile read by V17C and CAMF */
#define TIGHT_W 80
#define TIGHT_H 60
#define MED_W 120
#define MED_H 80
#define WIDE_W 180
#define WIDE_H 120
#define TIGHT_SAMPLES 1200u
#define TIGHT_PAIRS 2400u
struct score {
    uint32_t raw,wide,luma,raw_t,raw_m,raw_w,wide_t,wide_m,wide_w;
    uint32_t raw_noise,wide_noise;
    uint32_t clipped,dark,samples;
};
static struct score current;
static int absi(int v) { return v<0?-v:v; }
static uint32_t maxu(uint32_t a,uint32_t b) { return a>b?a:b; }
static uint32_t divu(uint32_t n,uint32_t d)
{
    uint32_t q=0,b=1;
    if (!d) return 0;
    while (d<n && !(d&0x80000000u)) {d<<=1;b<<=1;}
    while (b) {if(n>=d){n-=d;q|=b;}d>>=1;b>>=1;}
    return q;
}
#ifdef UNIT_TEST
static int valid_addr(uint32_t a){return a!=0;}
#else
static int valid_addr(uint32_t a){return a>=0x1000u && a<0x80000000u && !(a&3u);}
#endif

static int image_reason=0;
static int last_buf_w,last_buf_h,last_buf_pitch;
static uint32_t last_buf_addr;
enum { I_OK=0,I_NO_DESC=1,I_NULL_PTR=2,I_BAD_ADDR=3,I_BAD_GEOM=4,I_EMPTY=5,I_TOO_DARK=6,I_TOO_BRIGHT=7,I_NO_CONTRAST=9 };


static CONFIG_INT("camcal.region",focus_region,0);
static int sample_frame(struct score *v)
{
    struct vram_info_probe *vi=get_yuv422_vram();
    uint8_t *buf;
    uint32_t raw[3]={0,0,0},wg[3]={0,0,0},lum[3]={0,0,0};
    uint32_t count[3]={0,0,0},pairs[3]={0,0,0};
    uint32_t normal_raw[3],normal_wide[3];
    int x,y,cx,cy,x0,x1,y0,y1,w,h,pitch,k;
    v->raw=v->wide=v->luma=0;
    v->raw_t=v->raw_m=v->raw_w=0;
    v->wide_t=v->wide_m=v->wide_w=0;
    v->raw_noise=v->wide_noise=0;
    v->clipped=v->dark=v->samples=0;
    image_reason=I_OK;
    if (!vi){image_reason=I_NO_DESC;return 0;}
    buf=vi->vram;w=vi->width;h=vi->height;pitch=vi->pitch;
    last_buf_addr=(uint32_t)buf;last_buf_w=w;last_buf_h=h;last_buf_pitch=pitch;
    if (!buf){image_reason=I_NULL_PTR;return 0;}
    if (!valid_addr((uint32_t)buf)){image_reason=I_BAD_ADDR;return 0;}
    if(w<240 || h<180 || pitch<w*2 || pitch>8192){image_reason=I_BAD_GEOM;return 0;}
    cx=w/2;cy=h/2;
    x0=cx-WIDE_W;x1=cx+WIDE_W;y0=cy-WIDE_H;y1=cy+WIDE_H;
    if(x0<8)x0=8;if(y0<8)y0=8;
    if(x1>w-9)x1=w-9;if(y1>h-9)y1=h-9;
    for(y=y0;y<y1;y+=4)
    {
        uint8_t *r=buf+y*pitch,*up=buf+(y-2)*pitch,*dn=buf+(y+2)*pitch;
        uint8_t *wu=buf+(y-6)*pitch,*wd=buf+(y+6)*pitch;
        for(x=x0;x<x1;x+=4)
        {
            int off=(x<<1)+1;
            int yc=r[off],yl=r[((x-2)<<1)+1],yr=r[((x+2)<<1)+1];
            int yu=up[off],yd=dn[off];
            int wl=r[((x-6)<<1)+1],wr=r[((x+6)<<1)+1];
            int vw=wu[off],vx=wd[off];
            uint32_t g=(uint32_t)(absi(yr-yl)+absi(yd-yu));
            uint32_t gw=0,ng=0;
            if(wl>3&&wl<252&&wr>3&&wr<252){gw+=(uint32_t)absi(wr-wl);ng++;}
            if(vw>3&&vw<252&&vx>3&&vx<252){gw+=(uint32_t)absi(vx-vw);ng++;}
            /* 0 wide, 1 medium, 2 tight: nested region statistics. */
            for(k=0;k<3;k++)
            {
                if(k==1 && (x<cx-MED_W||x>=cx+MED_W||y<cy-MED_H||y>=cy+MED_H)) continue;
                if(k==2 && (x<cx-TIGHT_W||x>=cx+TIGHT_W||y<cy-TIGHT_H||y>=cy+TIGHT_H)) continue;
                raw[k]+=g;wg[k]+=gw;lum[k]+=(uint32_t)yc;
                count[k]++;pairs[k]+=ng;
            }
            if(x>=cx-TIGHT_W&&x<cx+TIGHT_W&&y>=cy-TIGHT_H&&y<cy+TIGHT_H)
            {
                v->samples++;if(yc<=16)v->dark++;if(yc>=235)v->clipped++;
            }
        }
    }
    if (!count[2]||!pairs[2]){image_reason=I_EMPTY;return 0;}
    for(k=0;k<3;k++)
    {
        uint32_t mean=count[k]?divu(lum[k],count[k]):1u;
        /* C2: keep the fraction. FZ17A did divu(raw,count)*1200: the mean gradient was rounded DOWN to a
           whole number first - on soft/low-detail pictures (mean gradient 2-6) that is a 15-40% step, and it
           made CAMCAL912F show the same value at many positions. Now 1/256 resolution (no overflow:
           raw < 2^22, so raw<<8 < 2^30). Same scale: raw*1200/count and wg*2400/pairs. */
        uint32_t rscore=count[k]?divu(divu(raw[k]<<8,count[k])*(TIGHT_SAMPLES/16u),16u):0;
        uint32_t wscore=pairs[k]?divu(divu(wg[k]<<8,pairs[k])*(TIGHT_PAIRS/16u),16u):0;
        normal_raw[k]=divu(rscore*256u,mean?mean:1u);
        normal_wide[k]=divu(wscore*256u,mean?mean:1u);
    }
    v->raw=raw[2];v->wide=wg[2];v->luma=divu(lum[2],count[2]);
    v->raw_t=normal_raw[2];v->raw_m=normal_raw[1];v->raw_w=normal_raw[0];
    v->wide_t=normal_wide[2];v->wide_m=normal_wide[1];v->wide_w=normal_wide[0];
    if (v->luma<12){image_reason=I_TOO_DARK;return 0;}
    if (v->luma>242){image_reason=I_TOO_BRIGHT;return 0;}
    if (v->dark > v->samples - v->samples/10){image_reason=I_TOO_DARK;return 0;}   /* C2: >90% (the >50% rule rejected in-focus frames on dark backgrounds) */
    if(!v->raw||!v->wide){image_reason=I_NO_CONTRAST;return 0;}
    return 1;
}
static int divs(int a,int b)
{
    int neg=0;uint32_t ua,ub,q;
    if(!b)return 0;
    if(a<0){a=-a;neg^=1;}
    if(b<0){b=-b;neg^=1;}
    ua=(uint32_t)a;ub=(uint32_t)b;
    q=divu(ua*2u+ub,ub*2u);
    return neg?-(int)q:(int)q;
}

static uint32_t fv_from(const struct score *v)
{
    uint32_t r,w;
    if(focus_region)
    {
        r=divu(v->raw_w*40u+v->raw_m*35u+v->raw_t*25u,100u);
        w=divu(v->wide_w*40u+v->wide_m*35u+v->wide_t*25u,100u);
    }
    else
    {
        r=divu(v->raw_w*15u+v->raw_m*30u+v->raw_t*55u,100u);
        w=divu(v->wide_w*15u+v->wide_m*30u+v->wide_t*55u,100u);
    }
    return r+w;
}
static int output_handle=0;static char output_buf[512];static int output_len=0;
static void flush(void)
{
    if(output_len&&output_handle>0)FIO_WriteFile(output_handle,output_buf,(unsigned)output_len);
    output_len=0;
}
static void ch(char c)
{
    if(output_len>450)flush();output_buf[output_len++]=c;
}
static void txt(const char *s){while(*s)ch(*s++);}
static void num(uint32_t n)
{
    char b[12];int i=0;if(!n){ch('0');return;}
    while(n&&i<11){b[i++]=(char)('0'+n%10u);n=divu(n,10);}
    while(i)ch(b[--i]);
}
static void snum(int n){if(n<0){ch('-');num((uint32_t)(-(int64_t)n));}else num((uint32_t)n);}
static void comma(void){ch(',');}
static void iout(int n){snum(n);comma();}
static void uout(uint32_t n){num(n);comma();}

/* ============================ calibration ============================ */
extern void powersave_prolong(void);
extern int bmp_printf(uint32_t fontspec,int x,int y,const char *fmt,...);
extern void NotifyBox(int timeout,const char *fmt,...);
extern int gui_menu_shown(void);
#define COLOR_WHITE 0x01u
#define COLOR_BLACK 0x02u
#define COLOR_YELLOW 0x0Fu
#define FONT_SMALL_WB ((0u<<16)|(COLOR_BLACK<<8)|COLOR_WHITE)
#define FONT_MED_YB   ((2u<<16)|(COLOR_BLACK<<8)|COLOR_YELLOW)

static CONFIG_INT("camcal.run",run_request,0);
static CONFIG_INT("camcal.stop",stop_request,0);
static CONFIG_INT("camcal.cap",cap_setting,1);      /* 0: 45, 1: 90, 2: 150 units each way */
static CONFIG_INT("camcal.log",log_setting,1);
static volatile int worker_exit=0,worker_busy=0;

static volatile uint32_t vs_seq=0,vs_ms=0;
static unsigned int on_vsync(unsigned int ctx){(void)ctx;vs_seq++;vs_ms=get_ms_clock();return 0;}

static int sgn(int v){return v>0?1:(v<0?-1:0);}
static int clampi(int v,int lo,int hi){return v<lo?lo:(v>hi?hi:v);}
static int rel_bp(uint32_t a,uint32_t b)
{
    uint32_t d,q;int neg;
    if(!b)return a?20000:0;
    while(b>(1u<<17)){a>>=1;b>>=1;}
    if(!b)return 0;
    neg=a<b;d=neg?b-a:a-b;
    if(d>(1u<<22))d=(1u<<22);
    q=divu(d<<8,b);
    if(q>3200u)q=3200u;
    q=(q*625u)>>4;
    if(q>20000u)q=20000u;
    return neg?-(int)q:(int)q;
}
/* a*p/100 for u32 without overflow (a up to ~4e9 not expected; sharpness values are < 2^24) */
static uint32_t pct(uint32_t a,uint32_t p){return divu(a*p,100u);}

enum { E_NONE=0,E_GATE=1,E_STOP=2,E_NOIMAGE=3,E_NOPEAK=4,E_NORESP=5,E_NOMOVE=6,E_WEAK=7,E_FROZEN=8 };
static int gate(void)
{
    int g=0;
    if(!lv)g|=1;
    if(!is_movie_mode())g|=2;
    if(is_manual_focus())g|=4;
    if(is_continuous_af())g|=8;
    if(!lens_info.lens_exists)g|=16;
    if(lens_info.job_state)g|=32;
    if(worker_exit)g|=64;
    return g;
}

#ifdef UNIT_TEST
extern void sim_vsync(void);
static int wait_vsync(void){sim_vsync();return 1;}
#else
static int wait_vsync(void)
{
    uint32_t s=vs_seq,t0=get_ms_clock();
    while(vs_seq==s){if((int)(get_ms_clock()-t0)>300)return 0;powersave_prolong();msleep(1);}
    return 1;
}
#endif

/* ---- results ---- */
struct cal {
    int err;
    int noise_bp;            /* mean |dFV|/FV, stationary, at the peak */
    int cup10,cdn10,back10;  /* peak centroids (command units x10) and backlash x10 */
    int rep10;               /* up-sweep to up-sweep scatter x10 */
    int width10;             /* FWHM x10, 0 = not found */
    int hi_reach,lo_reach;   /* farthest command positions reached from the start */
    int stop_hi,stop_lo;     /* lens refused further steps in that direction */
    int lag10,lag_n;         /* frames between command and picture change x10 (avg), samples */
    int rate_acc100;         /* accepted 1-unit commands per frame x100 */
    int rate_step100;        /* 3-unit step response, units per frame x100 */
    int fp_ms;               /* measured frame period */
    int snr10;               /* peak/floor x10 */
    int fvpk,fvfl;
    int settle;              /* frames discarded after a move during sweeps */
    int rej;
    int step3_10,step3_sat; /* size of ONE +/-3 command in +/-1 units x10 (0 unknown); sat=1: at least this */
    int reanchor;            /* units the position count was corrected by after the +/-3 tests */
    int final_bp;            /* sharpness where calibration finished, vs the sweep peak (10000 = peak) */
    int stale;               /* C2: frame ticks that still showed the previous picture (waited for a new one) */
    int stale_kept;          /* C2: pictures used although no new one came within ~300 ms */
    int edge_retry;          /* C2: 1 = first try never crossed the peak; restarted from that end */
    int probe_rev;           /* C2: 1 = the first 3-step probe said "wrong way" */
    int vs_ms;               /* C2: ms between ML vsync callbacks (should be ~33 at 30p) */
    int broad;               /* C2: sweeps stopped by the broad-hill rule */
    int w70_10;              /* C2: full width x10 at 70% of the peak (still measurable when the FWHM is not) */
    int range_hint;          /* C2: too little contrast change seen AND a sweep was stopped by the Sweep Range */
    int gate_blips;          /* C3: times a safety condition went bad for < 1.5 s and came back (run continued) */
};
static struct cal R;

/* ---- tables: 0 = up sweep 1, 1 = down sweep, 2 = up sweep 2 ---- */
#define CAP_MAX 150
#define TOFF 24
#define TN (2*CAP_MAX+2*TOFF+2)
static uint32_t tsum[3][TN];static uint8_t tcnt[3][TN];
static int tfp[TN];static unsigned tfd[TN];  /* C2: lens_info.focus_pos / focus_dist (cm) last seen at each position */
static int cpos=0,lastdir=0,cap=90,tmin_i=TN,tmax_i=0;
static uint32_t gmax=0,gmin=0xFFFFFFFFu;
static const char *stage="";

static int cap_units(void){return cap_setting>=2?150:(cap_setting==1?90:45);}
static int tidx(int pos){int i=pos+CAP_MAX+TOFF;return clampi(i,0,TN-1);}
static void tclear(void)
{
    int p,i;
    for(p=0;p<3;p++)for(i=0;i<TN;i++){tsum[p][i]=0;tcnt[p][i]=0;}
    gmax=0;gmin=0xFFFFFFFFu;tmin_i=TN;tmax_i=0;
    for(i=0;i<TN;i++){tfp[i]=0x7FFFFFFF;tfd[i]=0;}
}
static void trecord(int pass,uint32_t fv)
{
    int i=tidx(cpos);
    tfp[i]=lens_info.focus_pos;tfd[i]=lens_info.focus_dist;
    if(tcnt[pass][i]<255){tsum[pass][i]+=fv;tcnt[pass][i]++;}
    if(fv>gmax)gmax=fv;
    if(fv<gmin)gmin=fv;
    if(i<tmin_i)tmin_i=i;
    if(i>tmax_i)tmax_i=i;
}
/* mean of the given passes at index i; returns 0 if none */
static int tget(int passmask,int i,uint32_t *v)
{
    uint32_t s=0;int n=0,p;
    if(i<0||i>=TN)return 0;
    for(p=0;p<3;p++)if((passmask>>p)&1){s+=tsum[p][i];n+=tcnt[p][i];}
    if(!n)return 0;*v=divu(s,(uint32_t)n);return 1;
}

/* ---- screen ---- */
static char status_line[48];
static void status(const char *s)
{
    int i;stage=s;
    for(i=0;i<47&&s[i];i++)status_line[i]=s[i];
    status_line[i]=0;
#ifndef UNIT_TEST
    bmp_printf(FONT_MED_YB,8,8,"CAMCAL: %s",status_line);
    bmp_printf(FONT_SMALL_WB,8,40,"pos %d  max %d  min %d",cpos,(int)gmax,(int)(gmin==0xFFFFFFFFu?0:gmin));   /* no %u: Canon vsnprintf */
#endif
}

/* ---- frames and steps ---- */
static int cal_err=E_NONE;
/* C3: which safety condition stopped the run, and where (CAMCAL73E6 said only "err 1") */
static int fail_gate=0;static const char *fail_stage="";
static const char *gate_text(int bit)
{
    switch(bit){
    case 1:return "LiveView is off or paused (ML power saving: Turn off LCD/sensor?)";
    case 2:return CAM_MOVIE_HOWTO;
    case 4:return "lens switch is on MF: set it to AF (CAMCAL drives the focus itself)";
    case 8:return "Canon " CAM_SERVO " is ON: turn it OFF";
    case 16:return "no lens detected";
    case 32:return "camera busy (photo being taken / saved)";
    case 64:return "module is being unloaded";
    }
    return "";
}
static int abort_check(void)
{
    int g,t;
    if(stop_request){cal_err=E_STOP;return 1;}
    g=gate();
    if(!g)return 0;
    /* C3: a short blip (job state, display/LV hiccup) no longer kills the run: wait up to 1.5 s for it to clear */
    for(t=0;t<15&&g&&!(g&64)&&!stop_request;t++){msleep(100);g=gate();}
    if(stop_request){cal_err=E_STOP;return 1;}
    if(!g){R.gate_blips++;return 0;}
    cal_err=E_GATE;fail_gate=g;fail_stage=stage;return 1;
}
/* 1 valid frame in *fv, 0 unusable frame, -1 abort.
   C2: a frame tick does not guarantee a new picture (CAMCAL912F: ~1 in 10 positions read exactly the
   same value as the one before, frame period 157 ms). Wait - up to ~300 ms - until the picture really
   changes; real pictures always differ a little (sensor noise). */
static uint32_t last_sig=0;static int stale_run=0;
static int cal_frame(uint32_t *fv)
{
    struct score f;uint32_t t0=get_ms_clock(),sig;
    if(abort_check())return -1;
    for(;;)
    {
        if(!wait_vsync())return 0;
        if(!sample_frame(&f))return 0;
        sig=f.raw*2654435761u^f.wide*40503u^f.luma^(f.raw_t<<7);
        if(sig!=last_sig||!last_sig)break;
        R.stale++;
        if((int)(get_ms_clock()-t0)>300){R.stale_kept++;stale_run++;break;}
        if(abort_check())return -1;
    }
    if(sig!=last_sig)stale_run=0;
    last_sig=sig;
    if(stale_run>=12){cal_err=E_FROZEN;return -1;}   /* picture not updating at all (frozen preview?) */
    *fv=fv_from(&f);return 1;
}
static int get_fv(uint32_t *fv)
{
    int i,r;
    for(i=0;i<8;i++){r=cal_frame(fv);if(r)return r;}
    cal_err=E_NOIMAGE;return -1;
}
static int settle_frames(int n)
{
    uint32_t v;int i;
    for(i=0;i<n;i++)if(cal_frame(&v)<0)return -1;
    return 0;
}
/* settle, then average two valid frames */
static int measure(uint32_t *out)
{
    uint32_t a,b;
    if(settle_frames(R.settle)<0)return -1;
    if(get_fv(&a)<0)return -1;
    if(get_fv(&b)<0)return -1;
    *out=(a>>1)+(b>>1);return 1;
}
static int do_step(int dir)       /* ONE waited unit; 0 = lens refused (end stop) */
{
    int rc;
    if(abort_check())return -1;
    rc=lens_focus(1,dir,1,(lastdir&&dir!=lastdir)?120:10);
    if(!rc){if(dir>0)R.stop_hi=1;else R.stop_lo=1;return 0;}
    cpos+=dir;lastdir=dir;
    if(cpos>R.hi_reach)R.hi_reach=cpos;
    if(cpos<R.lo_reach)R.lo_reach=cpos;
    return 1;
}

/* ---- sweep: step, settle, measure until the hill has been crossed ---- */
static int pass_peak_pos[3];static uint32_t pass_peak_val[3];
static uint32_t start_fv=0;
static int sweep(int dir,int pass,int mirror,int probe)
{
    uint32_t fv,pmax=0;int pp=cpos,moved=0,r,k,p70=0x7FFF;
    status(pass==1?"sweep down":(pass==0?"sweep up 1":"sweep up 2"));
    while(moved<2*cap+16)                 /* C2: was cap+8 - the return sweep could not get back past the start
                                             (CAMCAL912F: down to -95, back up only to +3, peak not crossed).
                                             The position limits below still keep every sweep inside +/-(cap+6). */
    {
        if(cpos+dir>cap+6||cpos+dir<-cap-6)break;
        k=do_step(dir);
        if(k<0)return -1;
        if(!k)break;
        moved++;
        r=measure(&fv);
        if(r<0)return -1;
        trecord(pass,fv);
        if(fv>pmax){pmax=fv;pp=cpos;p70=0x7FFF;}
        else if(p70==0x7FFF&&fv<pct(pmax,70))p70=cpos;   /* first point past the peak under 70% */
        if(probe && moved==3 && rel_bp(fv,start_fv)<-300)return 2;      /* wrong way: let the caller reverse */
        if(pmax>=pct(gmax,80) && absi(cpos-pp)>=6)
        {
            if(fv<pct(gmax,45))break;
            if(mirror>0 && absi(cpos-pp)>=mirror)break;
            /* C2 broad hill / low contrast: 45% of the peak may lie below the blur floor (CAMCAL912F: floor 48%
               of the peak, so the sweep ran the full 95 units). 10+ units past the peak, under 65%, and 4+ units
               of flank under 70% (the flank tests need them) is enough. */
            if(absi(cpos-pp)>=10 && fv<pct(pmax,65) && p70!=0x7FFF && absi(cpos-p70)>=4){R.broad++;break;}
        }
    }
    pass_peak_pos[pass]=pp;pass_peak_val[pass]=pmax;
    return 0;
}

/* ---- analysis helpers ---- */
static int peak_index(int mask)                  /* argmax of the 3-wide mean */
{
    int i,ib=-1;uint32_t bv=0,v,s;int n,k;
    for(i=0;i<TN;i++)
    {
        if(!tget(mask,i,&v))continue;
        s=0;n=0;
        for(k=-1;k<=1;k++)if(tget(mask,i+k,&v)){s+=v;n++;}
        s=divu(s,(uint32_t)n);
        if(s>bv){bv=s;ib=i;}
    }
    return ib;
}
static uint32_t mask_max(int mask)
{
    int i;uint32_t m=0,v;
    for(i=0;i<TN;i++)if(tget(mask,i,&v)&&v>m)m=v;
    return m;
}
/* C2: index range covered by the given passes */
static void cover(int mask,int *lo,int *hi)
{
    int i;uint32_t v;*lo=TN;*hi=-1;
    for(i=0;i<TN;i++)if(tget(mask,i,&v)){if(i<*lo)*lo=i;*hi=i;}
}
/* centroid of the top 30% of the hill inside index range lo..hi, command units x10; 0x7FFFFFFF when no data.
   C2: two centroids are only compared over the range BOTH sweeps covered - a sweep that started on the
   peak sees only one side of a broad hill and its centroid moves (simulated: "repeat" 23 units, true 0). */
static int centroid10r(int mask,int lo,int hi)
{
    uint32_t pk=mask_max(mask),thr,v;int i,num=0,den=0,w;
    if(!pk)return 0x7FFFFFFF;
    thr=pct(pk,70);
    if(lo<0)lo=0;if(hi>TN-1)hi=TN-1;
    for(i=lo;i<=hi;i++)
        if(tget(mask,i,&v)&&v>thr)
        {
            w=(int)((v-thr)>>4);
            num+=(i-CAP_MAX-TOFF)*w;den+=w;
        }
    if(!den)return 0x7FFFFFFF;
    return divs(num*10,den);
}
static int centroid10(int mask){return centroid10r(mask,0,TN-1);}
static int centroid_pair(int ma,int mb,int *ca,int *cb)
{
    int la,ha,lb,hb,lo,hi;
    cover(ma,&la,&ha);cover(mb,&lb,&hb);
    lo=la>lb?la:lb;hi=ha<hb?ha:hb;
    if(hi-lo<3){lo=0;hi=TN-1;}
    *ca=centroid10r(ma,lo,hi);*cb=centroid10r(mb,lo,hi);
    return (*ca!=0x7FFFFFFF&&*cb!=0x7FFFFFFF);
}
/* full width x10 at `level` % of the maximum over the given passes; 0 when an edge was not reached */
static int fwlevel10(int mask,int level)
{
    int ip=peak_index(mask),i,lo=-1,hi=-1;uint32_t pk=mask_max(mask),h,v,vn;
    int left10,right10;
    if(ip<0||!pk)return 0;
    h=pct(pk,(uint32_t)level);
    for(i=ip;i>0;i--)if(tget(mask,i,&v)&&v<h){lo=i;break;}
    for(i=ip;i<TN-1;i++)if(tget(mask,i,&v)&&v<h){hi=i;break;}
    if(lo<0||hi<0)return 0;
    /* interpolate the crossing between lo and lo+1, hi-1 and hi */
    left10=lo*10;
    if(tget(mask,lo,&v)&&tget(mask,lo+1,&vn)&&vn>v)left10=lo*10+(int)divu((h-v)*10u,vn-v);
    right10=hi*10;
    if(tget(mask,hi,&v)&&tget(mask,hi-1,&vn)&&vn>v)right10=hi*10-(int)divu((h-v)*10u,vn-v);
    return right10>left10?right10-left10:0;
}
static int fwhm10(int mask){return fwlevel10(mask,50);}

static void goto_pos(int tgt,int adir)             /* waited moves, arriving travelling in direction adir */
{
    int pad=((R.back10>0?R.back10:0)+9)/10+2;
    int pre=tgt-adir*pad;
    while(cpos!=pre){ int k=do_step(cpos<pre?1:-1); if(k<=0)return; }
    while(cpos!=tgt){ int k=do_step(adir>0?(cpos<tgt?1:-1):(cpos>tgt?-1:1)); if(k<=0)return; }
}

/* ---- stationary noise ---- */
static int stationary(int n,uint32_t *mean,int *noise_bp,int *fp_ms)
{
    uint32_t v,prev=0,sum=0;int i,cnt=0,acc=0;uint32_t t0=0,t1=0;
    for(i=0;i<n;i++)
    {
        int r=cal_frame(&v);
        if(r<0)return -1;
        if(i==0)t0=get_ms_clock();
        t1=get_ms_clock();                       /* C2: time between real (changed) pictures */
        if(!r)continue;
        sum+=v;cnt++;
        if(prev){acc+=absi(rel_bp(v,prev));}
        prev=v;
    }
    if(cnt<n/2){cal_err=E_NOIMAGE;return -1;}
    *mean=divu(sum,(uint32_t)cnt);
    *noise_bp=cnt>1?divs(acc,cnt-1):0;
    if(fp_ms&&n>1)*fp_ms=(int)divu(t1-t0,(uint32_t)(n-1));
    return 0;
}

/* ---- non-blocking tests at the steep flank ---- */
#define RK 72
static uint32_t rf[RK];static int rf_n=0,rf_cmd_k=0;
static uint32_t base_mean;static int base_thr;
static int baseline_here(void)
{
    uint32_t m;int nz,t;
    if(settle_frames(R.settle+2)<0)return -1;
    if(stationary(6,&m,&nz,0)<0)return -1;
    base_mean=m;
    t=nz*3;if(t<200)t=200;if(t>800)t=800;
    base_thr=(int)divu(m*(uint32_t)t,10000u);
    if(base_thr<1)base_thr=1;
    return 0;
}
/* capture K frames after issuing `cmds` non-blocking commands of `mag` units, one per frame. */
static int burst_attempts=0;
static int burst(int dir,int mag,int cmds,int K,int *acc,int *rej)
{
    int k,a=0,j=0,last_ok=-1;uint32_t v,last=base_mean;
    rf_n=0;
    for(k=0;k<K&&k<RK;k++)
    {
        int r=cal_frame(&v);
        if(r<0)return -1;
        if(r)last=v;
        rf[rf_n++]=last;
        if(k<cmds)
        {
            int rc=lens_focus(1,dir*mag,0,0);
            if(rc){a++;last_ok=k;if(mag==1)cpos+=dir;lastdir=dir;if(a==1)rf_cmd_k=k;}else j++;   /* a +/-2/3 command is NOT 2/3 units: never counted */
        }
    }
    /* a run of 3+ refusals at the end is an end stop, not a slow motor: do not count it as busy */
    burst_attempts=cmds;
    if(cmds-1-last_ok>=3){burst_attempts=last_ok+1;if(dir>0)R.stop_hi=1;else R.stop_lo=1;}
    *acc=a;*rej=j;
    return 0;
}
/* Step-response timing from rf[]: the time (frames x100) at which the signed change from the baseline first reaches
 * `frac` percent of the final change and stays beyond it. -1 when never. */

/* ---- +/-3 commands: real logs show one +/-3 is NOT three +/-1 (about 2x at 135mm, 7-25x at 18mm on the
   18-135). So their size is measured from the picture, they are undone with the same command, and the
   unit count is re-anchored on the peak afterwards. ---- */
static void undo_big(int dir,int mag,int n)
{
    int i;
    if(settle_frames(2)<0)return;
    for(i=0;i<n;i++){ if(abort_check())return; if(!lens_focus(1,-dir*mag,1,i?10:120))break; }
    lastdir=-dir;
}
/* distance x10 from `from` (walking dir) to where the sweep curve falls to v; negative = left the curve */
static int flank_dist10(int mask,int from,int dir,uint32_t v)
{
    uint32_t prev,b;int k,pk=0,j;
    if(!tget(mask,tidx(from),&prev))return 0;
    if(v>=prev)return 0;
    for(k=1;k<=2*CAP_MAX;k++)
    {
        j=from+dir*k;
        if(j<-CAP_MAX-TOFF||j>CAP_MAX+TOFF)break;
        if(!tget(mask,tidx(j),&b))continue;
        if(b<=v)
        {
            if(prev<=b)return k*10;
            return pk*10+(int)divu((prev-v)*(uint32_t)(10*(k-pk)),prev-b);
        }
        prev=b;pk=k;
    }
    return -(pk*10);
}
/* climb with single units in dir until the picture has clearly passed a peak.
   *pk10 = peak command position x10 (current count, travelling dir); returns steps taken, -1 abort.
   *improved = 0 if it never got sharper than where it started. */
#define RA_MAX 330
static uint32_t ra_v[RA_MAX];
static int climb(int dir,int lim,int *pk10,int *improved)
{
    uint32_t v,best;int n=0,bi=0,drops=0,thr,start=cpos,p10;
    thr=R.noise_bp*3;if(thr<400)thr=400;if(thr>1500)thr=1500;
    if(lim>RA_MAX-2)lim=RA_MAX-2;
    if(measure(&v)<0)return -1;
    ra_v[n++]=v;best=v;
    while(n<=lim)
    {
        int k=do_step(dir);
        if(k<0)return -1;
        if(k==0)break;
        if(measure(&v)<0)return -1;
        ra_v[n]=v;
        if(v>best){best=v;bi=n;drops=0;}
        else if(rel_bp(v,best)<-thr){if(++drops>=2){n++;break;}}
        n++;
    }
    p10=bi*10;
    if(bi>0&&bi<n-1)       /* 3-point parabola around the best sample */
    {
        int l=(int)(ra_v[bi-1]>>4),c=(int)(ra_v[bi]>>4),r=(int)(ra_v[bi+1]>>4),den=l-2*c+r;
        if(den<0){int off=divs(5*(l-r),den);if(off>5)off=5;if(off<-5)off=-5;p10+=off;}
    }
    *pk10=start*10+dir*p10;*improved=bi>0;
    return n-1;
}
/* re-centre the unit count on the peak the sweeps found (cup10 when travelling +, cdn10 when travelling -) */
static int reanchor(int toward,int lim)
{
    int pk10,imp,n,d=toward,ref10,sh10,sh;
    n=climb(d,lim,&pk10,&imp);
    if(n<0)return -1;
    if(!imp){d=-d;n=climb(d,lim+n+4,&pk10,&imp);if(n<0)return -1;}   /* started past the peak: climb back */
    if(!imp){R.reanchor=0;return 0;}
    ref10=d>0?R.cup10:R.cdn10;
    sh10=ref10-pk10;sh=(sh10+(sh10>=0?5:-5))/10;
    {   /* on a broad hill a noisy climb cannot place the peak to the unit: only correct real slips */
        int tol=R.width10/100;
        if(!R.width10)tol=R.w70_10/60;   /* C2: FWHM not measurable (very broad hill): use the 70% width */
        if(absi(sh)<=tol)sh=0;
    }
    cpos+=sh;R.reanchor=sh;
    return 0;
}
static int cross100(int frac,int sg,int delta)
{
    int k,level=(delta*frac)/100,d0,d1;
    for(k=rf_n-1;k>=0;k--)if(sg*((int)rf[k]-(int)base_mean)<level)break;
    if(k<0)return 0;
    if(k==rf_n-1)return -1;
    d0=sg*((int)rf[k]-(int)base_mean);d1=sg*((int)rf[k+1]-(int)base_mean);
    if(d1<=d0)return (k+1)*100;
    return k*100+(int)divu((uint32_t)(level-d0)*100u,(uint32_t)(d1-d0));
}
/* lag_f100: frames between the command and the start of the picture change (0 = the next frame already moves);
 * dur_f100: duration of the visible change. */
static int analyse_step(int *lag_f100,int *dur_f100)
{
    int k,cnt=0,sg,delta,t25,t75,s100;uint32_t fe=0;
    for(k=rf_n-5;k<rf_n;k++){fe+=rf[k];cnt++;}
    fe=divu(fe,(uint32_t)cnt);
    sg=(int)fe>=(int)base_mean?1:-1;
    delta=sg*((int)fe-(int)base_mean);
    if(delta*2<base_thr*5)return 0;                      /* change too small to time against the noise */
    t25=cross100(25,sg,delta);t75=cross100(75,sg,delta);
    if(t25<0||t75<0||t75<t25)return 0;
    s100=t25-(t75-t25)/2;
    *lag_f100=s100-100*(rf_cmd_k+1);
    *dur_f100=2*(t75-t25);if(*dur_f100<50)*dur_f100=50;
    return 1;
}

static int recommend_done=0;

/* ---- one complete calibration ---- */
static uint32_t lagtr[3][24];static int lagtr_n[3];static uint32_t ratetr[RK];static int ratetr_n=0;
static int pf_pos=0,pf_dir=1,pf_len=0,N_rate=0,A_dir=1;
static int force_dir=0,edge_dir=0,edge_pos=0;   /* C2: restart from the end where the peak must be */
static uint32_t t_start=0;static int start_wait_ms=0,menu_at_start=0;
static void clear_result(int settle)
{
    int *p=(int*)&R;unsigned i;
    for(i=0;i<sizeof(R)/sizeof(int);i++)p[i]=0;
    R.settle=settle;R.fvfl=0;
}
static int cal_once(void)
{
    uint32_t m;int nz=0,fp=0,i,ip,mir,ovs,c1,c3,cyc;
    cap=cap_units();cpos=0;lastdir=0;cal_err=E_NONE;tclear();
    status("checking the target");
    {   /* C2: also time the ML vsync callback itself (CAMCAL912F reported 157 ms per frame) */
        uint32_t s0=vs_seq,c0=get_ms_clock(),dv;
        if(stationary(10,&m,&nz,&fp)<0)return -1;
        dv=vs_seq-s0;if(dv)R.vs_ms=(int)divu(get_ms_clock()-c0,dv);
    }
    R.fp_ms=fp;gmax=m;gmin=m;
    start_fv=m;
    {
        int rr,dirA=1,p;
        if(force_dir)
        {   /* C2 retry: the peak lies past the end the first try barely explored - go straight that way */
            dirA=force_dir;
            if(sweep(dirA,0,0,0)<0)return -1;
        }
        else
        {
            rr=sweep(+1,0,0,1);
            if(rr<0)return -1;
            if(rr==2)
            {   /* the first 3 steps made it worse: the hill is the other way. Forget those points, sweep down first. */
                int ii;for(ii=0;ii<TN;ii++){tsum[0][ii]=0;tcnt[0][ii]=0;}
                dirA=-1;R.probe_rev=1;
                if(sweep(-1,0,0,0)<0)return -1;
            }
        }
        A_dir=dirA;
        ovs=absi(cpos-pass_peak_pos[0]);mir=2*ovs+12;
        if(sweep(-dirA,1,mir,0)<0)return -1;
        ovs=absi(cpos-pass_peak_pos[1]);mir=2*ovs+12;
        if(sweep(dirA,2,mir,0)<0)return -1;
        (void)p;
    }
    R.fvpk=(int)gmax;R.fvfl=(int)gmin;
    if(!gmin||gmax<pct(gmin,140))
    {
        cal_err=E_NOPEAK;
        R.range_hint=(R.hi_reach>=cap&&!R.stop_hi)||(R.lo_reach<=-cap&&!R.stop_lo);
        return -1;
    }
    R.snr10=(int)divu(gmax*10u,gmin);
    ip=peak_index(5);
    if(ip<0||ip<=tmin_i+1||ip>=tmax_i-1)          /* hill not crossed */
    {
        cal_err=E_NOPEAK;
        if(ip>=0&&!force_dir)
        {   /* C2: the sharpest point is at one end of what was explored and that end is not an end stop:
               the peak is beyond it. Let calibrate() restart from there, sweeping that way first. */
            edge_dir=(ip>=tmax_i-1)?1:-1;edge_pos=ip-(CAP_MAX+TOFF);
            if((edge_dir>0&&!R.stop_hi)||(edge_dir<0&&!R.stop_lo))return -2;
        }
        return -1;
    }
    {   /* cup10 = peak command position when travelling +, cdn10 = when travelling -  (phys = cmd for +, cmd+B for -) */
        int ca,cb;
        if(!centroid_pair(5,2,&ca,&cb)){cal_err=E_NOPEAK;return -1;}
        R.cup10=A_dir>0?ca:cb;R.cdn10=A_dir>0?cb:ca;
    }
    R.back10=R.cup10-R.cdn10;
    if(!centroid_pair(1,4,&c1,&c3)){c1=0x7FFFFFFF;}
    R.rep10=(c1!=0x7FFFFFFF&&c3!=0x7FFFFFFF&&pass_peak_val[0]>=pct(gmax,90))?absi(c1-c3):-1;
    {int wu=fwhm10(5),wd=fwhm10(2);R.width10=(wu&&wd)?(wu+wd)/2:(wu?wu:(wd?wd:fwhm10(7)));}
    {int wu=fwlevel10(5,70),wd=fwlevel10(2,70);R.w70_10=(wu&&wd)?(wu+wd)/2:(wu?wu:(wd?wd:fwlevel10(7,70)));}

    /* choose the steep flank (just under 70% of the peak) on a side with room to move away from the peak */
    pf_dir=0;pf_len=0;
    {
        int dirs[2]={1,-1},di;
        for(di=0;di<2&&!pf_dir;di++)
        {
            /* use only the sweeps that travelled d: the burst will travel d too, so with backlash
               the flank position is where it physically is for that direction */
            int d=dirs[di],md=(d==A_dir)?5:2,ipd=peak_index(md),j,a=-1,lastj;uint32_t v;
            uint32_t l70=pct(mask_max(md),70);
            if(ipd<0)ipd=ip;
            j=ipd;lastj=ipd;
            for(;j>0&&j<TN-1;j+=d)
            {
                if(!tget(md,j,&v))continue;
                lastj=j;
                if(a<0&&v<l70)a=j;
            }
            if(a>=0&&absi(lastj-a)>=3){pf_dir=d;pf_pos=a-(CAP_MAX+TOFF);pf_len=absi(lastj-a);}
        }
    }
    if(!pf_dir||pf_len<3){cal_err=E_WEAK;return -1;}

    /* ---- image lag and 3-unit step response (median of 3, bad samples discarded) ---- */
    status("lag / motor tests");
    {
        int lagv[3],spdv[3],nv=0,anyacc=0,s3v[3],ns3=0,s3sat=0;
        for(cyc=0;cyc<3;cyc++)
        {
            int acc=0,rej=0,lg=0,du=0,ncmd=(R.width10>=200)?2:1;
            goto_pos(pf_pos,pf_dir);
            if(cal_err)return -1;
            if(baseline_here()<0)return -1;
            if(burst(pf_dir,3,ncmd,26,&acc,&rej)<0)return -1;
            {int j;lagtr_n[cyc]=rf_n<24?rf_n:24;for(j=0;j<lagtr_n[cyc];j++)lagtr[cyc][j]=rf[j];}
            R.rej+=rej;
            if(acc)anyacc=1;
            if(acc&&analyse_step(&lg,&du)&&lg/10+10>=0&&lg/10+10<=90&&du>=30&&du<=1200)
            {
                lagv[nv]=lg/10+10;       /* +1 frame: the very next frame is the earliest a change can show */
                spdv[nv]=(int)divu((uint32_t)(3*acc)*10000u,(uint32_t)du);   /* provisional: rescaled by the real +/-3 size below */
                nv++;
            }
            if(acc)
            {   /* how far did the +/-3 really go? read the settled picture against the sweep curve */
                uint32_t m2,c0;int nz2,mask=(pf_dir==A_dir)?5:2;
                if(settle_frames(R.settle+2)<0)return -1;
                if(stationary(4,&m2,&nz2,0)<0)return -1;
                /* C2: only when the step changed the picture clearly (> 2x the noise threshold, >= 4%): on a very
                   broad hill 3 units barely change it and the size read off the curve is noise (sim: 5.0 for 3) */
                if(base_mean&&m2+2u*(uint32_t)base_thr<base_mean&&tget(mask,tidx(pf_pos),&c0))
                {
                    uint32_t pm=divu(m2*1000u,base_mean),vt;int d10;
                    if(pm>1000u)pm=1000u;
                    vt=divu(c0*pm,1000u);
                    d10=flank_dist10(mask,pf_pos,pf_dir,vt);
                    {   /* C4: landed in the bottom 15% of the hill (the blurred tail, often uneven): the size can only
                           be "at least as far as the tail starts" (replay of the real 85 mm curve read 3.0 for 15) */
                        uint32_t l15=gmin+pct(gmax-gmin,15);
                        if(vt<l15){int dd=flank_dist10(mask,pf_pos,pf_dir,l15);d10=dd>0?-dd:dd;}
                    }
                    if(d10>0&&ns3<3)s3v[ns3++]=divs(d10,acc);
                    else if(d10<0&&divs(-d10,acc)>s3sat)s3sat=divs(-d10,acc);
                }
                undo_big(pf_dir,3,acc);        /* same command back: the pair cancels whatever its size */
            }
        }
        if(!anyacc){cal_err=E_NOMOVE;return -1;}
        R.lag_n=nv;
        if(nv)
        {
            int a,b,t;
            for(a=1;a<nv;a++){t=lagv[a];for(b=a-1;b>=0&&lagv[b]>t;b--)lagv[b+1]=lagv[b];lagv[b+1]=t;}
            for(a=1;a<nv;a++){t=spdv[a];for(b=a-1;b>=0&&spdv[b]>t;b--)spdv[b+1]=spdv[b];spdv[b+1]=t;}
            R.lag10=lagv[nv/2];R.rate_step100=spdv[nv/2];
        }
        else {R.lag10=-1;R.rate_step100=0;}       /* too noisy to time: recommendations fall back to defaults */
        if(ns3)
        {
            int a,b,t;
            for(a=1;a<ns3;a++){t=s3v[a];for(b=a-1;b>=0&&s3v[b]>t;b--)s3v[b+1]=s3v[b];s3v[b+1]=t;}
            R.step3_10=s3v[ns3/2];R.step3_sat=0;
        }
        else if(s3sat){R.step3_10=s3sat;R.step3_sat=1;}
        if(R.step3_10>0&&R.rate_step100>0)R.rate_step100=(int)divu((uint32_t)R.rate_step100*(uint32_t)R.step3_10,30u);
        /* the unit count may be off after the +/-3 tests: climb back to the peak and re-anchor on it */
        status("re-anchor");
        {
            int lim=absi(pf_pos-R.cup10/10)+(R.width10>0?R.width10/10:20)+12;
            if(reanchor(-pf_dir,lim)<0)return -1;
        }
    }

    /* ---- sustained 1-unit-per-frame acceptance ---- */
    {
        int room=pf_dir>0?cap+6-pf_pos:pf_pos+cap+6;
        N_rate=room<20?room:20;
    }
    if(N_rate>=6)
    {
        int acc=0,rej=0,j;
        status("speed test");
        goto_pos(pf_pos,pf_dir);
        if(cal_err)return -1;
        if(baseline_here()<0)return -1;
        if(burst(pf_dir,1,N_rate,N_rate+30,&acc,&rej)<0)return -1;
        ratetr_n=rf_n;for(j=0;j<rf_n;j++)ratetr[j]=rf[j];
        R.rate_acc100=(int)divu((uint32_t)acc*100u,(uint32_t)(burst_attempts>0?burst_attempts:1));
        R.rej+=rej;
    }

    /* ---- return to focus (arrive travelling up) and measure noise there ---- */
    status("back to focus");
    goto_pos((R.cup10+(R.cup10>=0?5:-5))/10,1);
    if(cal_err)return -1;
    {   /* verify the landing; if clearly soft, try one unit either side (always arriving travelling +) */
        uint32_t v,w,pk=mask_max(7);int thr=R.noise_bp*3,c=cpos,bp;
        if(thr<800)thr=800;
        if(measure(&v)<0)return -1;
        R.final_bp=10000+rel_bp(v,pk);
        if(rel_bp(v,pk)<-thr)
        {
            bp=c;
            goto_pos(c-1,1);if(cal_err)return -1;if(measure(&w)<0)return -1;if(w>v){v=w;bp=c-1;}
            goto_pos(c+1,1);if(cal_err)return -1;if(measure(&w)<0)return -1;if(w>v){v=w;bp=c+1;}
            if(bp!=c+1){goto_pos(bp,1);if(cal_err)return -1;}
            R.final_bp=10000+rel_bp(v,pk);
        }
    }
    status("final noise");
    if(settle_frames(R.settle+2)<0)return -1;
    if(stationary(24,&m,&nz,&fp)<0)return -1;
    R.noise_bp=nz;
    if(fp)R.fp_ms=fp;
    return 0;
}

static int calibrate(void)
{
    int pass,lagf=0,r=0,retried=0;
    force_dir=0;
    for(pass=0;pass<2;pass++)
    {
        clear_result(pass?clampi(lagf+3,4,9):4);
        R.edge_retry=retried;
        r=cal_once();
        if(r==-2&&!retried)
        {   /* C2: peak beyond the end explored least - move there and start again sweeping that way */
            int e=edge_dir,p=edge_pos;
            retried=1;cal_err=E_NONE;
            status("peak is further on - restarting from there");
            goto_pos(p,e);
            if(cal_err==E_GATE||cal_err==E_STOP)return -1;
            force_dir=e;pass--;continue;
        }
        if(r<0)return -1;
        force_dir=0;
        lagf=R.lag10<0?0:(R.lag10+5)/10;
        if(lagf+2<=R.settle)break;           /* sweeps already settled long enough */
    }
    return 0;
}

/* ---- recommendations ---- */
struct rec { int fz_comp_units,fz_comp_setting,fz_speed,camf_comp_units,camf_comp_setting,camf_speed,camf_sens,max_ups; };
static struct rec RC;
static void recommend(void)
{
    int B=(R.back10+5)/10,fps_x10,cap100,cap_ups;
    RC.fz_comp_setting=B<2?0:(B<5?1:2);RC.fz_comp_units=RC.fz_comp_setting==0?0:(RC.fz_comp_setting==1?3:6);
    RC.camf_comp_setting=B<1?0:(B<3?1:2);RC.camf_comp_units=RC.camf_comp_setting==0?0:(RC.camf_comp_setting==1?2:4);
    if(R.lag10<0)RC.fz_speed=1;
    else {int lag_ms=(R.lag10*R.fp_ms+5)/10;RC.fz_speed=lag_ms<=40?0:(lag_ms<=60?1:2);}
    fps_x10=R.fp_ms>0?(int)divu(10000u,(uint32_t)R.fp_ms):300;
    cap100=R.rate_acc100?R.rate_acc100:100;
    if(R.rate_step100&&R.rate_step100<cap100)cap100=R.rate_step100;
    if(cap100>100)cap100=100;
    cap_ups=(int)divu((uint32_t)fps_x10*(uint32_t)cap100,1000u);        /* units per second */
    RC.max_ups=cap_ups;
    {int lim=(cap_ups*8)/10;RC.camf_speed=lim>=26?3:(lim>=16?2:(lim>=10?1:0));}
    RC.camf_sens=R.noise_bp*4<=700?2:(R.noise_bp*4<=1200?1:0);
}

/* ---- CSV ---- */
static int out_handle_dummy;
static uint32_t log_serial=0;
static void write_csv(void)
{
    char path[22]="ML/CAMCAL0000.CSV";
    uint32_t v;int i,j;static const char hx[]="0123456789ABCDEF";
    if(!log_setting)return;
    if(!log_serial)log_serial=(get_ms_clock()&0xFFFFu);else log_serial++;
    v=log_serial;
    for(i=0;i<4;i++){path[12-i]=hx[v&15u];v>>=4;}
    output_handle=FIO_CreateFile(path);
    if(output_handle<=0)return;
    txt("# CAMCAL lens focus calibration C4" CAM_CSV_TAG ". Command units are NOT encoder counts; sharpness = YUV preview (FZ17A fv, full precision).\n");
    txt("# err 0 ok,1 gate,2 stop,3 no image,4 no peak (hill not crossed / flat target),5 no response to step,6 no movement,7 no usable flank,8 picture not updating (frozen preview?)\n");
    txt("# gate_bits: 1 LiveView off/paused, 2 not movie mode, 4 lens on MF, 8 " CAM_SERVO " on, 16 no lens, 32 camera busy (job state), 64 unloading\n");
    txt("# RESULT,err,");snum(cal_err);
    txt(",settle_frames,");snum(R.settle);txt(",frame_ms,");snum(R.fp_ms);
    txt(",noise_bp,");snum(R.noise_bp);txt(",snr_x10,");snum(R.snr10);txt(",fv_peak,");snum(R.fvpk);txt(",fv_floor,");snum(R.fvfl);
    txt(",peak_up_x10,");snum(R.cup10);txt(",peak_down_x10,");snum(R.cdn10);txt(",backlash_x10,");snum(R.back10);txt(",repeat_x10,");snum(R.rep10);
    txt(",fwhm_x10,");snum(R.width10);txt(",reach_hi,");snum(R.hi_reach);txt(",reach_lo,");snum(R.lo_reach);
    txt(",stop_hi,");snum(R.stop_hi);txt(",stop_lo,");snum(R.stop_lo);
    txt(",lag_frames_x10,");snum(R.lag10);txt(",lag_samples,");snum(R.lag_n);
    txt(",flank_pos,");snum(pf_pos);txt(",flank_dir,");snum(pf_dir);txt(",flank_len,");snum(pf_len);txt(",rate_n,");snum(N_rate);txt(",rate_accept_x100,");snum(R.rate_acc100);txt(",rate_step_x100,");snum(R.rate_step100);txt(",rejects,");snum(R.rej);
    txt(",step3_units_x10,");snum(R.step3_10);txt(",step3_at_least,");snum(R.step3_sat);txt(",reanchor_units,");snum(R.reanchor);txt(",final_sharp_bp,");snum(R.final_bp);
    txt(",picture_ms,");snum(R.fp_ms);txt(",stale_ticks,");snum(R.stale);txt(",stale_kept,");snum(R.stale_kept);txt(",edge_retry,");snum(R.edge_retry);txt(",probe_reversed,");snum(R.probe_rev);
    txt(",vsync_ms,");snum(R.vs_ms);txt(",broad_stops,");snum(R.broad);txt(",width70_x10,");snum(R.w70_10);txt(",range_hint,");snum(R.range_hint);
    txt(",gate_bits,");snum(fail_gate);txt(",gate_blips,");snum(R.gate_blips);txt(",start_wait_ms,");snum(start_wait_ms);txt(",menu_open_at_start,");snum(menu_at_start);
    txt(",fail_stage,");if(cal_err)txt(fail_stage[0]?fail_stage:stage);txt(",run_ms,");num(get_ms_clock()-t_start);txt("\n");
    txt("# RECOMMEND,fz17a_comp_setting,");snum(RC.fz_comp_setting);txt(",fz17a_comp_units,");snum(RC.fz_comp_units);
    txt(",fz17a_speed_setting,");snum(RC.fz_speed);
    txt(",camf_comp_setting,");snum(RC.camf_comp_setting);txt(",camf_comp_units,");snum(RC.camf_comp_units);
    txt(",camf_speed_setting,");snum(RC.camf_speed);txt(",camf_sens_setting,");snum(RC.camf_sens);txt(",max_units_per_s,");snum(RC.max_ups);txt("\n");
    txt("# lens,id,");num(lens_info.lens_id);txt(",focal_mm,");num(lens_info.focal_len);txt(",aperture_x10,");num(lens_info.aperture);
    txt(",shutter_raw,");num(lens_info.shutter);txt(",iso_raw,");num(lens_info.iso);txt("\n");
    txt("# sweep1 = first sweep, travelling ");txt(A_dir>0?"UP (+)":"DOWN (-)");txt("; sweep2 = back the other way; sweep3 = same way as sweep1. focus_pos / focus_cm = lens_info.focus_pos / focus_dist when last there (Canon values: coarse and late, 65535 = infinity).\n");
    txt("pos,sweep1,sweep2,sweep3,focus_pos,focus_cm\n");
    for(i=tmin_i;i<=tmax_i&&i<TN;i++)
    {
        snum(i-CAP_MAX-TOFF);
        for(j=0;j<3;j++){uint32_t a=0;ch(',');if(tget(1<<j,i,&a))num(a);}
        ch(',');if(tfp[i]!=0x7FFFFFFF){snum(tfp[i]);ch(',');num(tfd[i]);}else ch(',');
        ch('\n');
    }
    for(j=0;j<3;j++){int k;txt("# STEP3 cycle ");snum(j+1);txt(" frames (cmd issued after frame 0):");for(k=0;k<lagtr_n[j];k++){ch(' ');num(lagtr[j][k]);}ch('\n');}
    {int k;txt("# RATE1 frames:");for(k=0;k<ratetr_n;k++){ch(' ');num(ratetr[k]);}ch('\n');}
    flush();FIO_CloseFile(output_handle);output_handle=0;
}

/* ---- C4: lens profile ML/LPxxxx.TXT (format: src/common/LENS_PROFILE.h). Only after a successful run. ---- */
static int prof_saved=0;
static void write_profile(void)
{
    char path[16];int i,j,f=(int)lens_info.focal_len;
    struct lprof e;
    prof_saved=0;
    if(cal_err||!lens_info.lens_exists||!lens_info.lens_id||f<=0)return;
    lp_load();
    e.focal=f;e.back10=R.back10;e.fwhm10=R.width10;e.w70_10=R.w70_10;e.step3_10=R.step3_10;e.step3_sat=R.step3_sat;
    e.noise_bp=R.noise_bp;e.lag10=R.lag10;e.fp_ms=R.fp_ms;e.rep10=R.rep10;e.serial=(int)(log_serial&0xFFFFu);
    for(i=0;i<lp_n;i++)if(lp_tab[i].focal==f)break;
    if(i==lp_n){if(lp_n<LP_MAXL)lp_n++;else i=lp_n-1;}
    lp_tab[i]=e;
    for(i=1;i<lp_n;i++){struct lprof t=lp_tab[i];for(j=i-1;j>=0&&lp_tab[j].focal>t.focal;j--)lp_tab[j+1]=lp_tab[j];lp_tab[j+1]=t;}
    lp_path(path);
    output_handle=FIO_CreateFile(path);
    if(output_handle<=0){output_handle=0;return;}
    txt("# CAMCAL lens profile for lens_id ");num(lens_info.lens_id);txt(", camera " CAM_MODEL ". Read by V17C and CAMF (AUTO settings).\n");
    txt("# One line per focal length, the latest successful CAMCAL run wins. Lines may be deleted by hand.\n");
    txt("focal_mm,backlash_x10,fwhm_x10,width70_x10,step3_x10,step3_sat,noise_bp,lag_x10,frame_ms,repeat_x10,serial\n");
    for(i=0;i<lp_n;i++)
    {
        const struct lprof *p=&lp_tab[i];
        snum(p->focal);ch(',');snum(p->back10);ch(',');snum(p->fwhm10);ch(',');snum(p->w70_10);ch(',');
        snum(p->step3_10);ch(',');snum(p->step3_sat);ch(',');snum(p->noise_bp);ch(',');snum(p->lag10);ch(',');
        snum(p->fp_ms);ch(',');snum(p->rep10);ch(',');snum(p->serial);ch('\n');
    }
    flush();FIO_CloseFile(output_handle);output_handle=0;
    prof_saved=lp_n;
}

/* ---- screen result ---- */
static const char *err_text(int e)
{
    switch(e){
    case E_GATE:return CAM_GATE_SHORT;
    case E_STOP:return "stopped";
    case E_NOIMAGE:return "no usable picture (too dark / bright / no contrast)";
    case E_NOPEAK:return "no focus peak found: roughly focus first / use a high-contrast flat target";
    case E_NORESP:return "lens did not respond to a 3-unit step";
    case E_NOMOVE:return "lens did not move";
    case E_WEAK:return "no steep flank found (target too flat)";
    case E_FROZEN:return "LiveView picture is not updating: close menus, use mlv_lite Real-time preview";
    }
    return "";
}
static void show_result(int ok)
{
    int t,i;
    for(t=0;t<80&&!worker_exit&&!stop_request;t++)
    {
#ifndef UNIT_TEST
        if(!ok)
        {
            bmp_printf(FONT_MED_YB,8,8,"CAMCAL FAILED (err %d)",cal_err);
            if(cal_err==E_GATE&&fail_gate)
            {   /* C3: name the condition(s) */
                int b,y=40;
                for(b=1;b<128&&y<=80;b<<=1)if(fail_gate&b){bmp_printf(FONT_SMALL_WB,8,y,"%s",gate_text(b));y+=20;}
            }
            else bmp_printf(FONT_SMALL_WB,8,40,"%s",err_text(cal_err));
            if(cal_err==E_GATE)bmp_printf(FONT_SMALL_WB,8,100,"stopped during: %s",fail_stage);
            else if(R.edge_retry)bmp_printf(FONT_SMALL_WB,8,60,"(also failed after restarting from the sharp end)");
            else if(cal_err==E_NOPEAK&&R.range_hint)bmp_printf(FONT_SMALL_WB,8,60,"focus hill wider than the Sweep Range: set CAL Sweep Range 150, or move closer");
            bmp_printf(FONT_SMALL_WB,8,80,"lens left at the sharpest point seen. CSV: ML/CAMCALxxxx.CSV");
        }
        else
        {
            bmp_printf(FONT_MED_YB,8,8,"CAMCAL RESULT (hold 40 s; menu STOP to leave)");
            if(R.width10)bmp_printf(FONT_SMALL_WB,8,40,"backlash %d.%d  repeat %d.%d  width %d.%d units",R.back10/10,absi(R.back10)%10,R.rep10<0?0:R.rep10/10,R.rep10<0?0:R.rep10%10,R.width10/10,R.width10%10);
            else bmp_printf(FONT_SMALL_WB,8,40,"backlash %d.%d  repeat %d.%d  width >%d units (70 pct width %d)",R.back10/10,absi(R.back10)%10,R.rep10<0?0:R.rep10/10,R.rep10<0?0:R.rep10%10,(R.hi_reach-R.lo_reach),R.w70_10/10);
            if(R.lag10>=0)bmp_printf(FONT_SMALL_WB,8,60,"noise %d.%d pct  contrast %d.%dx  lag %d.%d frames",R.noise_bp/100,(R.noise_bp%100)/10,R.snr10/10,R.snr10%10,R.lag10/10,R.lag10%10);
            else bmp_printf(FONT_SMALL_WB,8,60,"noise %d.%d pct  contrast %d.%dx  lag not measurable (flank too shallow)",R.noise_bp/100,(R.noise_bp%100)/10,R.snr10/10,R.snr10%10);
            bmp_printf(FONT_SMALL_WB,8,80,"1-unit/frame accepted %d pct  3-unit step %d pct  max about %d units/s",R.rate_acc100,R.rate_step100,RC.max_ups);
            if(R.step3_10>0)bmp_printf(FONT_SMALL_WB,8,100,"one +/-3 command = %s%d.%d units  (FZ17A assumes 3.0)%s",R.step3_sat?">=":"",R.step3_10/10,R.step3_10%10,
                       (R.step3_10>0&&(R.step3_10<22||R.step3_10>38))?"  MISMATCH":"");
            else bmp_printf(FONT_SMALL_WB,8,100,"one +/-3 command: not measurable here (hill too broad / flat)");
            bmp_printf(FONT_SMALL_WB,8,116,"FZ17A: Reversal Comp %d units, Speed %s",RC.fz_comp_units,RC.fz_speed==0?"FASTEST":(RC.fz_speed==1?"BALANCED":"CAREFUL"));
            bmp_printf(FONT_SMALL_WB,8,134,"CAMF : Backlash Comp %d units, Speed %s, Sensitivity %s",RC.camf_comp_units,RC.camf_speed==0?"CINEMATIC":(RC.camf_speed==1?"SLOW":(RC.camf_speed==2?"MEDIUM":"FAST")),RC.camf_sens==0?"LOW":(RC.camf_sens==1?"MEDIUM":"HIGH"));
            bmp_printf(FONT_SMALL_WB,8,156,"Landing sharpness %d pct of peak. Full data: ML/CAMCALxxxx.CSV",R.final_bp/100);
            if(prof_saved){char pp[16];lp_path(pp);bmp_printf(FONT_SMALL_WB,8,174,"Lens profile saved: %s (%d mm, %d focal lengths). V17C/CAMF AUTO use it.",pp+3,(int)lens_info.focal_len,prof_saved);}
        }
        if(R.fp_ms>60||R.vs_ms>60)   /* C2: CAMCAL912F saw 157 ms */
        {
            bmp_printf(FONT_SMALL_WB,8,196,"SLOW PICTURE: new picture every %d ms, vsync every %d ms (normal ~33)",R.fp_ms,R.vs_ms);
            bmp_printf(FONT_SMALL_WB,8,214,"Close menus; FPS override OFF; Global Draw OFF; no HDMI; then run again");
        }
#endif
        for(i=0;i<5;i++)msleep(100);
    }
}

static void worker(void *unused)
{
    (void)unused;
    while(!worker_exit)
    {
        if(run_request)
        {
            int r,k;
            run_request=0;stop_request=0;worker_busy=1;
            NotifyBox(4000,"CAMCAL: close the menu. Keep the camera still, target flat. Starting in 6 s");
            for(k=0;k<60&&!worker_exit&&!stop_request;k++)msleep(100);
            /* C3: do not start into a problem - say what is wrong and wait up to 60 s for it to be fixed */
            fail_gate=0;fail_stage="";start_wait_ms=0;menu_at_start=0;
            {
                uint32_t w0=get_ms_clock();int g=0,m=0,b;
                for(k=0;k<600&&!worker_exit&&!stop_request;k++)
                {
                    g=gate()&~64;m=gui_menu_shown();
                    if(!g&&!m)break;
                    if(k%10==0)
                    {
                        if(m)NotifyBox(1500,"CAMCAL: close the ML menu to start");
                        else for(b=1;b<64;b<<=1)if(g&b){NotifyBox(1500,"CAMCAL waiting: %s",gate_text(b));break;}
                    }
                    msleep(100);
                }
                start_wait_ms=(int)(get_ms_clock()-w0);menu_at_start=m;
                if(!g&&k)for(k=0;k<20&&!worker_exit&&!stop_request;k++)msleep(100);   /* fixed: 2 s to let go of the camera */
            }
            t_start=get_ms_clock();
            R.fp_ms=0;
            if(stop_request||worker_exit){worker_busy=0;continue;}
            r=calibrate();
            if(r<0)
            {   /* C2: keep the real error (C1 wiped it and reported "err 0"). If the lens can still be
                   driven, leave it on the sharpest point that was seen. */
                int e=cal_err;
                if(e!=E_GATE&&e!=E_STOP&&e!=E_FROZEN)
                {
                    int ib=peak_index(7);
                    stop_request=0;cal_err=E_NONE;
                    if(ib>=0)goto_pos(ib-(CAP_MAX+TOFF),1);
                }
                cal_err=e;
            }
            recommend();
            write_csv();
            write_profile();
            show_result(r>=0);
            stop_request=0;worker_busy=0;
        }
        msleep(100);
    }
}
static struct menu_entry menu[] = {
    {.name="CAL Run Calibration",.priv=&run_request,.max=1,
     .choices=CHOICES("OFF","RUN"),
     .help="Point at a flat high-contrast target (CAMCAL_TARGET.png on a monitor), focus roughly with Canon AF, then RUN.",
     .help2="About 1 minute. Measures backlash, peak width, noise, image lag and motor speed; shows recommended settings."},
    {.name="CAL Stop",.priv=&stop_request,.max=1,
     .choices=CHOICES("OFF","STOP"),
     .help="Abort the calibration at the next safety check."},
    {.name="CAL Sweep Range",.priv=&cap_setting,.max=2,
     .choices=CHOICES("45 UNITS","90 UNITS","150 UNITS"),
     .help="Farthest the sweeps may go from the starting focus, each way. Use more if the start is far from focus."},
    {.name="CAL Focus Region",.priv=&focus_region,.max=1,
     .choices=CHOICES("CENTRE 55%","BALANCED 25%"),
     .help="Same weighting choice as FZ17A / CAMF; calibrate with the one you will use."},
    {.name="CAL Log",.priv=&log_setting,.max=1,
     .choices=CHOICES("OFF","ON"),
     .help="Write ML/CAMCALxxxx.CSV with every measured point."},
};
static unsigned int cal_init(void)
{
    if(is_camera(CAM_MODEL,CAM_FW))
    {
        run_request=stop_request=0;worker_exit=worker_busy=0;log_serial=0;
        menu_add("Focus",menu,5);
        task_create("camcal",29,16384,worker,0);
    }
    return 0;
}
static unsigned int cal_deinit(void)
{
    int n;
    worker_exit=1;stop_request=1;run_request=0;
    for(n=0;n<120&&worker_busy;n++)msleep(50);
    msleep(150);
    if(worker_busy)return 1;
    menu_remove("Focus",menu,5);
    return 0;
}
MODULE_INFO_START()
  MODULE_INIT(cal_init)
  MODULE_DEINIT(cal_deinit)
  MODULE_LONGNAME("CAMCAL Lens Focus Calibration")
MODULE_INFO_END()
MODULE_CBRS_START()
  MODULE_CBR(CBR_VSYNC, on_vsync, 0)
MODULE_CBRS_END()
MODULE_CONFIGS_START()
  MODULE_CONFIG(focus_region)
  MODULE_CONFIG(cap_setting)
  MODULE_CONFIG(log_setting)
MODULE_CONFIGS_END()
MODULE_STRINGS_START()
  MODULE_STRING("Name","CAMCAL Lens Focus Calibration")
  MODULE_STRING("Author","experimental")
  MODULE_STRING("License","GPL")
  MODULE_STRING("Summary","Measures backlash, peak width, noise, image lag and motor speed for the " CAM_MODEL " focus modules")
  MODULE_STRING("Description","Sweeps the focus through a flat high-contrast target and recommends FZ17A and CAMF settings.")
MODULE_STRINGS_END()
