# Findings from real camera logs (Canon 70D 1.1.2, EF-S 18-135 IS USM, lens id 36912)

Only logs from these modules count. The user asked to ignore older data from a previous AI (lens-mapper
"LMP" logs, V16/V18 logs). The simulator lens profiles still use some numbers from those old logs. They
are test models, not facts.

## Lens and motor (lens_focus)
- **Units.** `lens_focus(1, ±1, wait, delay)` is the exact unit; "units" everywhere means these ±1 commands.
  A waited ±1 takes about 45 ms, including a 10 ms extra delay.
- **One ±3 is not 3 units.**
  - At 19 mm: one ±3 moved focus 2.7 m → 0.67 m, while 33 × ±1 moved ∞ → 0.92 m. So one ±3 is about 25 units there.
  - At 85 mm: one ±3 went 1.74 m → 0.40 m (close stop).
  - At 135 mm: about 2 units.
- **±2 after a direction change** is mostly swallowed by backlash. Use ±4 for a small probe.
- **End stops.** The lens sometimes "accepts" a ±3 at a stop without moving, and refuses others. A refused
  command is the reliable end-stop signal (V17C r2 treats any refused ±3 as the stop).
- **Canon `lens_info.focus_pos`** changes in steps of 256 and lags; it does track the motor.
  **`focus_dist`** is in cm, 65535 = infinity.

## Picture / sharpness
- **Metric.** Sharpness is computed from the LiveView YUV422 buffer (`get_yuv422_vram()`): centre boxes
  with gradients at 2 px and 6 px spacing, normalised by mean luma.
- **85 mm peak** (FZ7C3500): about 2 units FWHM. 237k at the peak, 53k and 127k one unit either side, about 20k on
  the flat tails.
- **64 mm, monitor target** (CAMCAL912F): very broad. Sharpness was still 48% of the peak 95 units away.
  The best fit is a Lorentzian with w ≈ 26 on a 48% floor. A 3-unit step changes the picture by only about 2%.
- **Dark-frame rule.** The old rule rejected a frame when more than 50% of the centre pixels were
  near-black, which threw away in-focus frames on dark backgrounds. Fixed to more than 90%;
  FZ7C34FF (luma 16, ~55% near-black) then focused fine. **CAMF still has the old rule.**
- **Rounding bug.** `divu(raw,count)*1200` rounds the mean gradient down to a whole number. The real logs
  have mean gradients of 1.6-3.5 on the 85 mm tails and 2.5-15 on the dark 34FF run, so each step is 7-40%.
  Fixed in CAMCAL C2 and later; **V17C r3 and CAMF C1 still round.**

## Camera state / gate
- **Gate.** The modules drive the lens only when all of these hold:
  - LiveView is on;
  - the camera is in movie mode;
  - the lens is on AF (not MF);
  - Canon continuous AF (70D: Movie Servo) is off;
  - a lens is attached;
  - `lens_info.job_state` = 0.

  ML's own `lens_focus()` refuses in the same cases.
- **CBR_VSYNC.** On the 70D and the 5D3 it comes from EVF_STATE evfReadOutDoneInterrupt (ML
  `CONFIG_EVF_STATE_SYNC`). It should arrive once per LiveView frame, about 33 ms at 30p. CAMCAL run 1 saw
  about 157 ms; the cause is unknown.
- **ML power saving** ("turn off LCD and sensor") pauses LiveView, and then `lv` = 0.

## Results so far
- **V17C r1** (logs FZ7C2B59-2B5E): 6/6 accepted at 18-19, 50 and 135 mm. 2-28× sharper, 4.2-5.8 s typical.
  The slowest runs were 8.4 s (ghost accepts at the infinity stop) and 10.8 s (in-focus start at 19 mm).
- **V17C r2** (logs FZ7C34FD-3500): 4/4 accepted (18 mm ×1, 85 mm ×3). 2.6-9.4× sharper, 4.8-9.4 s.
  - FZ7C34FD (18 mm) started at the close stop. A ghost-accepted +3 skipped the focus point, then V17C
    crawled 37 units back.
  - FZ7C3500 (85 mm): a noise dip on flat blur was taken as "peak passed".
  - r3 targets both cases. **r3 itself is NOT camera-tested.**
- **CAMCAL v2** (CAMCAL912F, 64 mm f/4.9): failed with err 4 (peak not crossed), but a bug wrote "err 0".
  - Cause: a broad hill, and the return sweep ran out of steps.
  - The two down sweeps differ by about 7 units. The likely cause is ghost accepts at an end stop near −90.
- **CAMCAL C2** (CAMCAL73E6): failed with err 1 (gate) before measuring; the gate bit wasn't logged. The
  most likely cause is the lens switch on MF (old instructions). C3 names the failed check and waits.
- **CAMF:** no camera data.

## Platform facts for the 5D3 (from ML source and the user's other 5D3 project)
- **Firmware.** 5D3.113 = firmware 1.1.3, `is_camera("5D3","1.1.3")`, DIGIC V, `CONFIG_EVF_STATE_SYNC`,
  `CONFIG_LV_FOCUS_INFO`.
- **Canon's vsnprintf.** `%%` consumes an argument and `%u` is unsupported. Use only `%d` and `%s`.
- **`struct lens_info`.** Its layout is the same for all cameras in ML API 8. The modules use a copy
  (`struct lens_info_probe`) that matches ML's `src/lens.h` up to `lens_exists`.
- **Lenses.** The 5D3 has no Movie Servo AF. ML's `is_continuous_af()` reads Canon's movie-servo
  setting, which the 5D3 lacks, so it should never block.

## Replay of the real curves (simulated, 16 Oct 2026)
- Curves in tests/curves were built from CAMCAL912F (64 mm) and the V17C logs FZ7C2B5A/2B5E (19/18 mm),
  2B5B (50 mm), 3500 (85 mm). One side of each peak is partly MIRRORED (not measured) - see each file's header.
- CAMCAL C4 on them measures the simulated backlash right in 24/24 successful runs and peak widths of
  ~3 (85 mm), ~10 (50 mm), ~8-9 (18-19 mm) units; the 64 mm hill is wider than its sweep.
- V17C on the REAL 85 mm curve: only 25% of runs reach >=95% of peak sharpness (the invented 85 mm lens model
  gave 100%). Main open problem.
- A lens with 4 units of backlash: fixed Backlash Comp 3 -> 24-26% of runs at >=95%; AUTO from the profile
  (backlash+1) -> 92-100%. Comp equal to the backlash (no margin) lands one unit short more often.
